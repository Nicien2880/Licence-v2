from datetime import date, datetime
from io import BytesIO
from pathlib import Path
import sqlite3
import re
import json
import uuid

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, PlainTextResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
try:
    from docx import Document
except Exception:  # python-docx may be installed after update
    Document = None
from sqlalchemy import inspect, or_, text
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .models import BackupObject, ChangeLog, DataProtectionPolicy, HardwareSupport, SoftwareLicense, User
from .settings import get_settings
from .auth import (
    ROLE_LABELS, SESSION_COOKIE, create_initial_admin_if_needed, create_session_token,
    get_current_user, hash_password, require_api_key, require_login, require_role,
    user_can, verify_password,
)

settings = get_settings()
app = FastAPI(title=settings.app_name)
BASE_DIR = Path(__file__).resolve().parent
Base.metadata.create_all(bind=engine)


def ensure_schema() -> None:
    """Мини-миграция для существующей SQLite-базы после обновления проекта."""
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    if "hardware_support" in tables:
        columns = {column["name"] for column in inspector.get_columns("hardware_support")}
        if "manufacturer" not in columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE hardware_support ADD COLUMN manufacturer VARCHAR(255)"))
    if "software_licenses" in tables:
        columns = {column["name"] for column in inspector.get_columns("software_licenses")}
        if "location" not in columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE software_licenses ADD COLUMN location VARCHAR(255)"))
        if "group_name" not in columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE software_licenses ADD COLUMN group_name VARCHAR(255)"))


ensure_schema()
with next(get_db()) as _db:
    create_initial_admin_if_needed(_db)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


BACKUP_FILENAME_RE = re.compile(r"^license_monitor_backup_\d{8}_\d{6}_[A-Za-z0-9_.-]+\.db$")


def get_sqlite_db_path() -> Path:
    """Возвращает путь к SQLite-файлу базы. Backup UI рассчитан именно на SQLite."""
    db_url = settings.database_url
    if not db_url.startswith("sqlite:///"):
        raise HTTPException(status_code=400, detail="UI backup supports only SQLite database_url")
    raw_path = db_url.replace("sqlite:///", "", 1)
    db_path = Path(raw_path)
    if not db_path.is_absolute():
        db_path = Path.cwd() / db_path
    return db_path.resolve()


def get_backup_dir() -> Path:
    backup_dir = Path(settings.backup_dir)
    if not backup_dir.is_absolute():
        backup_dir = Path.cwd() / backup_dir
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir.resolve()


def list_db_backups() -> list[dict]:
    backup_dir = get_backup_dir()
    rows = []
    for path in sorted(backup_dir.glob("license_monitor_backup_*.db"), reverse=True):
        stat = path.stat()
        rows.append({
            "name": path.name,
            "size_bytes": stat.st_size,
            "size_mb": round(stat.st_size / 1024 / 1024, 2),
            "created_at": datetime.fromtimestamp(stat.st_mtime),
        })
    return rows


def validate_backup_filename(filename: str) -> Path:
    if not BACKUP_FILENAME_RE.match(filename):
        raise HTTPException(status_code=400, detail="Invalid backup filename")
    path = get_backup_dir() / filename
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Backup not found")
    return path


def create_sqlite_backup(username: str) -> Path:
    db_path = get_sqlite_db_path()
    if not db_path.exists():
        raise HTTPException(status_code=404, detail=f"Database file not found: {db_path}")
    safe_user = re.sub(r"[^A-Za-z0-9_.-]", "_", username or "system")[:40]
    filename = f"license_monitor_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_user}.db"
    destination = get_backup_dir() / filename
    source_conn = sqlite3.connect(str(db_path))
    try:
        backup_conn = sqlite3.connect(str(destination))
        try:
            source_conn.backup(backup_conn)
        finally:
            backup_conn.close()
    finally:
        source_conn.close()
    return destination


def parse_date(value) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value).strip()[:10])


def parse_int(value, default=None):
    if value in (None, ""):
        return default
    try:
        return int(value)
    except Exception:
        return default


def parse_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "да", "истина", "on"}


def calc_status(days_left: int) -> str:
    if days_left < 0:
        return "expired"
    if days_left <= 7:
        return "urgent"
    if days_left <= 30:
        return "critical"
    if days_left <= 60:
        return "warning"
    return "active"


def update_status(item) -> None:
    item.status = calc_status(item.days_left(date.today()))




def normalize_serial(value: str | None) -> str:
    return re.sub(r"\s+", "", str(value or "")).strip().upper()


def hardware_serial_exists(db: Session, serial_number: str | None, exclude_id: int | None = None) -> bool:
    normalized = normalize_serial(serial_number)
    if not normalized:
        return False
    items = db.query(HardwareSupport).all()
    for item in items:
        if exclude_id is not None and item.id == exclude_id:
            continue
        if normalize_serial(item.serial_number) == normalized:
            return True
    return False



def log_change(db: Session, section: str, record_id: int | None, action: str, description: str, actor: str = "web") -> None:
    db.add(ChangeLog(section=section, record_id=record_id, action=action, description=description, actor=actor))


def hardware_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None, manufacturers: list[str] | None = None):
    query = db.query(HardwareSupport)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            HardwareSupport.manufacturer.ilike(pattern), HardwareSupport.dzo.ilike(pattern), HardwareSupport.serial_number.ilike(pattern),
            HardwareSupport.equipment_model.ilike(pattern), HardwareSupport.contract_number.ilike(pattern),
            HardwareSupport.contractor.ilike(pattern), HardwareSupport.responsible.ilike(pattern),
            HardwareSupport.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(HardwareSupport.status == status)
    if responsible:
        query = query.filter(HardwareSupport.responsible == responsible)
    if manufacturers:
        manufacturers = [m for m in manufacturers if m]
        if manufacturers:
            query = query.filter(HardwareSupport.manufacturer.in_(manufacturers))
    items = query.order_by(HardwareSupport.support_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def software_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None, groups: list[str] | None = None):
    query = db.query(SoftwareLicense)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            SoftwareLicense.group_name.ilike(pattern), SoftwareLicense.location.ilike(pattern), SoftwareLicense.code.ilike(pattern), SoftwareLicense.certificate_number.ilike(pattern),
            SoftwareLicense.contract_number.ilike(pattern), SoftwareLicense.contractor.ilike(pattern),
            SoftwareLicense.responsible.ilike(pattern), SoftwareLicense.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(SoftwareLicense.status == status)
    if responsible:
        query = query.filter(SoftwareLicense.responsible == responsible)
    if groups:
        groups = [g for g in groups if g]
        if groups:
            query = query.filter(SoftwareLicense.group_name.in_(groups))
    items = query.order_by(SoftwareLicense.cert_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def stats_for(items):
    today = date.today()
    return {
        "total": len(items),
        "expired": sum(1 for x in items if x.days_left(today) < 0),
        "urgent": sum(1 for x in items if 0 <= x.days_left(today) <= 7),
        "critical": sum(1 for x in items if 8 <= x.days_left(today) <= 30),
        "warning": sum(1 for x in items if 31 <= x.days_left(today) <= 60),
    }


def distinct_responsibles(db: Session, model):
    """Return unique responsible names for models with different field names.

HardwareSupport, SoftwareLicense and BackupObject use `responsible`;
DataProtectionPolicy uses `responsible_person`.
"""
    field = getattr(model, "responsible", None)
    if field is None:
        field = getattr(model, "responsible_person", None)
    if field is None:
        return []
    values = db.query(field).distinct().order_by(field).all()
    return [x[0] for x in values if x[0]]



def distinct_software_groups(db: Session) -> list[str]:
    values = db.query(SoftwareLicense.group_name).distinct().order_by(SoftwareLicense.group_name).all()
    return [x[0] for x in values if x[0]]


def distinct_hardware_manufacturers(db: Session) -> list[str]:
    values = db.query(HardwareSupport.manufacturer).distinct().order_by(HardwareSupport.manufacturer).all()
    return [x[0] for x in values if x[0]]





DP_TYPE_LABELS = {
    "filesystem": "Filesystem",
    "internal_database": "Internal Database",
    "ms_sql_server": "MS SQL Server",
    "virtual_environment": "Virtual Environment",
}


def normalize_backup_type(value: str | None) -> str:
    value = str(value or "filesystem").strip().lower().replace(" ", "_").replace("-", "_")
    aliases = {
        "mssql": "ms_sql_server",
        "ms_sql": "ms_sql_server",
        "sql_server": "ms_sql_server",
        "virtual": "virtual_environment",
        "vm": "virtual_environment",
        "internal_db": "internal_database",
        "database": "internal_database",
    }
    return aliases.get(value, value if value in DP_TYPE_LABELS else "filesystem")


def parse_volume_gb(value) -> int | None:
    if value in (None, ""):
        return None
    raw = str(value).strip().lower().replace(",", ".")
    multiplier = 1
    if "tb" in raw or "тб" in raw:
        multiplier = 1024
    raw = re.sub(r"[^0-9.]", "", raw)
    if not raw:
        return None
    try:
        return int(round(float(raw) * multiplier))
    except Exception:
        return None


def format_volume(value: int | None) -> str:
    if value is None:
        return ""
    if value >= 1024:
        tb = value / 1024
        return f"{tb:.2f} ТБ".replace(".00", "")
    return f"{value} ГБ"


def dp_query(db: Session, q: str | None = None, backup_type: str | None = None, responsible: str | None = None):
    query = db.query(DataProtectionPolicy)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            DataProtectionPolicy.system_name.ilike(pattern),
            DataProtectionPolicy.reserved_information.ilike(pattern),
            DataProtectionPolicy.procedure_frequency.ilike(pattern),
            DataProtectionPolicy.retention_period.ilike(pattern),
            DataProtectionPolicy.notes.ilike(pattern),
            DataProtectionPolicy.responsible_person.ilike(pattern),
        ))
    if backup_type:
        query = query.filter(DataProtectionPolicy.backup_type == normalize_backup_type(backup_type))
    if responsible:
        query = query.filter(DataProtectionPolicy.responsible_person == responsible)
    return query.order_by(DataProtectionPolicy.backup_type.asc(), DataProtectionPolicy.row_number.asc().nullslast(), DataProtectionPolicy.system_name.asc()).all()


def dp_grouped(items: list[DataProtectionPolicy]) -> list[dict]:
    result = {key: {"type": key, "label": label, "items": [], "count": 0, "volume_gb": 0, "volume_label": "0 ГБ"} for key, label in DP_TYPE_LABELS.items()}
    for item in items:
        key = normalize_backup_type(item.backup_type)
        row = result.setdefault(key, {"type": key, "label": DP_TYPE_LABELS.get(key, key), "items": [], "count": 0, "volume_gb": 0, "volume_label": "0 ГБ"})
        row["items"].append(item)
        row["count"] += 1
        row["volume_gb"] += item.max_volume_gb or 0
    for row in result.values():
        row["volume_label"] = format_volume(row["volume_gb"])
    return [row for row in result.values() if row["count"] > 0]


def dp_stats(items: list[DataProtectionPolicy]) -> dict:
    total = len(items)
    volume = sum(x.max_volume_gb or 0 for x in items)
    full_count = sum(1 for x in items if x.procedure_frequency and "full" in x.procedure_frequency.lower())
    incr_count = sum(1 for x in items if x.procedure_frequency and ("incr" in x.procedure_frequency.lower() or "increment" in x.procedure_frequency.lower() or "инкрем" in x.procedure_frequency.lower()))
    diff_count = sum(1 for x in items if x.procedure_frequency and ("diff" in x.procedure_frequency.lower() or "differential" in x.procedure_frequency.lower() or "дифф" in x.procedure_frequency.lower() or "дифференц" in x.procedure_frequency.lower()))
    no_responsible = sum(1 for x in items if not x.responsible_person)
    return {"total": total, "volume_gb": volume, "volume_label": format_volume(volume), "types": len({x.backup_type for x in items}) if items else 0, "full": full_count, "incremental": incr_count, "differential": diff_count, "no_responsible": no_responsible}


def dp_type_stats(items: list[DataProtectionPolicy]) -> list[dict]:
    rows = []
    for group in dp_grouped(items):
        rows.append({"type": group["type"], "label": group["label"], "count": group["count"], "volume_gb": group["volume_gb"], "volume_label": group["volume_label"]})
    rows.sort(key=lambda x: x["volume_gb"], reverse=True)
    return rows


def dp_schedule_stats(items: list[DataProtectionPolicy]) -> dict:
    """Data Protection schedule analytics from procedure_frequency.

    Builds:
    - day distribution;
    - cadence distribution;
    - Full / Incremental / Differential counters;
    - hour distribution;
    - heatmap: weekday x hour.
    """
    day_aliases = {
        "mon": ("Пн", ["понедельник", "понедельникам", "понедельниками", "пн", "monday", "mon"]),
        "tue": ("Вт", ["вторник", "вторникам", "вторниками", "вт", "tuesday", "tue"]),
        "wed": ("Ср", ["среда", "среду", "средам", "средами", "ср", "wednesday", "wed"]),
        "thu": ("Чт", ["четверг", "четвергам", "четвергами", "чт", "thursday", "thu"]),
        "fri": ("Пт", ["пятница", "пятницу", "пятницам", "пятницами", "пт", "friday", "fri"]),
        "sat": ("Сб", ["суббота", "субботу", "субботам", "субботами", "сб", "saturday", "sat"]),
        "sun": ("Вс", ["воскресенье", "воскресеньям", "воскресеньями", "вс", "sunday", "sun"]),
    }

    day_rows = {
        key: {"key": key, "label": label, "total": 0, "full": 0, "incremental": 0, "differential": 0, "other": 0}
        for key, (label, _) in day_aliases.items()
    }
    cadence = {
        "daily": {"label": "Ежедневно / через день", "count": 0},
        "weekly": {"label": "Еженедельно / каждые N недель", "count": 0},
        "monthly": {"label": "Ежемесячно", "count": 0},
        "multi_daily": {"label": "Несколько раз в день", "count": 0},
        "unknown": {"label": "Не распознано", "count": 0},
    }
    modes = {
        "full": {"label": "Full", "count": 0},
        "incremental": {"label": "Incremental", "count": 0},
        "differential": {"label": "Differential", "count": 0},
        "other": {"label": "Прочее", "count": 0},
    }
    hour_rows = {h: {"hour": f"{h:02d}:00", "count": 0} for h in range(24)}
    heatmap_matrix = {day: {h: 0 for h in range(24)} for day in day_aliases.keys()}
    unparsed = []

    def has_any(text: str, values: list[str]) -> bool:
        return any(x in text for x in values)

    def extract_hours(text: str) -> list[int]:
        result = []
        # 02:00, 2:00, 02.00, 8:00 PM, 1:09 AM
        for value, ampm in re.findall(r"\b((?:0?\d|1\d|2[0-3])[:.][0-5]\d)\s*(am|pm|a\.m\.|p\.m\.)?\b", text):
            hour_s, _minute_s = value.replace(".", ":").split(":")
            hour = int(hour_s)
            ampm = (ampm or "").replace(".", "")
            if ampm == "pm" and hour < 12:
                hour += 12
            if ampm == "am" and hour == 12:
                hour = 0
            result.append(hour)
        return result

    for item in items:
        raw = item.procedure_frequency or ""
        text = raw.lower().replace("ё", "е").replace("—", "-").replace("–", "-")
        reasons = []

        if not text.strip():
            cadence["unknown"]["count"] += 1
            modes["other"]["count"] += 1
            unparsed.append({
                "id": item.id,
                "row_number": item.row_number,
                "system_name": item.system_name,
                "backup_type": item.backup_type,
                "backup_type_label": DP_TYPE_LABELS.get(item.backup_type, item.backup_type),
                "procedure_frequency": raw,
                "reason": "пустое поле периодичности",
            })
            continue

        has_full = has_any(text, ["full", "полный", "полная"])
        has_incr = has_any(text, ["incr", "increment", "incremental", "инкрем", "инкремент"])
        has_diff = has_any(text, ["diff", "differential", "differ", "дифф", "дифференц", "разностн"])

        if has_full:
            modes["full"]["count"] += 1
        if has_incr:
            modes["incremental"]["count"] += 1
        if has_diff:
            modes["differential"]["count"] += 1
        if not has_full and not has_incr and not has_diff:
            modes["other"]["count"] += 1
            reasons.append("не найден тип Full/Incr/Diff")

        is_every_other_day = has_any(text, ["через день", "every other day"])
        is_multiweek = bool(re.search(r"(каждые|кажд[а-я]+|раз в)\s+[234]\s+недел", text))
        is_daily_like = is_every_other_day or has_any(text, ["ежеднев", "каждый день", "daily", "раз в день"])

        if has_any(text, ["2 раза в день", "два раза в день", "несколько раз в день"]):
            cadence["multi_daily"]["count"] += 1
        elif is_daily_like:
            cadence["daily"]["count"] += 1
        elif is_multiweek or has_any(text, ["еженед", "раз в неделю", "weekly", "каждую неделю"]):
            cadence["weekly"]["count"] += 1
        elif has_any(text, ["ежемесяч", "раз в месяц", "monthly", "каждый месяц"]):
            cadence["monthly"]["count"] += 1
        else:
            cadence["unknown"]["count"] += 1
            reasons.append("не распознана периодичность")

        matched_days = []
        for key, (_, aliases) in day_aliases.items():
            if any(alias in text for alias in aliases):
                matched_days.append(key)

        heatmap_days = matched_days[:]
        if not heatmap_days and is_daily_like:
            heatmap_days = list(day_aliases.keys())

        if not matched_days and not is_daily_like:
            reasons.append("не найден день недели")

        for key in matched_days:
            day_rows[key]["total"] += 1
            if has_full:
                day_rows[key]["full"] += 1
            if has_incr:
                day_rows[key]["incremental"] += 1
            if has_diff:
                day_rows[key]["differential"] += 1
            if not has_full and not has_incr and not has_diff:
                day_rows[key]["other"] += 1

        hours = extract_hours(text)
        if not hours:
            reasons.append("не найдено время запуска")

        for hour in hours:
            if hour in hour_rows:
                hour_rows[hour]["count"] += 1
            for day_key in heatmap_days:
                if day_key in heatmap_matrix and hour in heatmap_matrix[day_key]:
                    heatmap_matrix[day_key][hour] += 1

        if reasons:
            unparsed.append({
                "id": item.id,
                "row_number": item.row_number,
                "system_name": item.system_name,
                "backup_type": item.backup_type,
                "backup_type_label": DP_TYPE_LABELS.get(item.backup_type, item.backup_type),
                "procedure_frequency": raw,
                "reason": "; ".join(dict.fromkeys(reasons)),
            })

    max_day = max([row["total"] for row in day_rows.values()] + [1])
    max_hour = max([row["count"] for row in hour_rows.values()] + [1])
    max_heat = max([value for day in heatmap_matrix.values() for value in day.values()] + [1])

    for row in day_rows.values():
        row["percent"] = round(row["total"] / max_day * 100, 1) if max_day else 0

    for row in hour_rows.values():
        row["percent"] = round(row["count"] / max_hour * 100, 1) if max_hour else 0

    peak = {"label": "—", "hour": "—", "count": 0}
    heatmap = {
        "hours": [f"{h:02d}" for h in range(24)],
        "max": max_heat,
        "rows": [],
        "peak": peak,
    }
    for key, (label, _) in day_aliases.items():
        cells = []
        for h in range(24):
            count = heatmap_matrix[key][h]
            level = round(count / max_heat * 100, 1) if max_heat else 0
            if count == 0:
                bucket = "empty"
            elif count <= 5:
                bucket = "low"
            elif count <= 10:
                bucket = "medium"
            elif count <= 20:
                bucket = "high"
            else:
                bucket = "peak"

            if count > peak["count"]:
                peak.update({"label": label, "hour": f"{h:02d}:00", "count": count})

            cells.append({
                "hour": f"{h:02d}:00",
                "count": count,
                "level": level,
                "bucket": bucket,
            })
        heatmap["rows"].append({"key": key, "label": label, "cells": cells})

    return {
        "days": list(day_rows.values()),
        "cadence": [row for row in cadence.values()],
        "modes": [row for row in modes.values()],
        "hours": [row for row in hour_rows.values() if row["count"] > 0],
        "heatmap": heatmap,
        "unparsed": unparsed,
        "unparsed_count": len(unparsed),
    }

def dp_to_api(item: DataProtectionPolicy) -> dict:
    return {
        "id": item.id,
        "row_number": item.row_number,
        "backup_type": item.backup_type,
        "backup_type_label": DP_TYPE_LABELS.get(item.backup_type, item.backup_type),
        "system_name": item.system_name,
        "reserved_information": item.reserved_information,
        "max_volume_gb": item.max_volume_gb,
        "procedure_frequency": item.procedure_frequency,
        "retention_period": item.retention_period,
        "notes": item.notes,
        "responsible_person": item.responsible_person,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def backup_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None):
    query = db.query(BackupObject)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            BackupObject.object_name.ilike(pattern), BackupObject.object_type.ilike(pattern),
            BackupObject.platform.ilike(pattern), BackupObject.storage.ilike(pattern),
            BackupObject.policy_name.ilike(pattern), BackupObject.responsible.ilike(pattern),
            BackupObject.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(BackupObject.status == status)
    if responsible:
        query = query.filter(BackupObject.responsible == responsible)
    return query.order_by(BackupObject.last_backup_at.desc().nullslast(), BackupObject.object_name.asc()).all()


def backup_stats(items: list[BackupObject]) -> dict:
    total = len(items)
    success = sum(1 for x in items if x.status == "success")
    warning = sum(1 for x in items if x.status == "warning")
    failed = sum(1 for x in items if x.status == "failed")
    running = sum(1 for x in items if x.status == "running")
    unknown = sum(1 for x in items if x.status == "unknown")
    health = round((success / total) * 100, 1) if total else 0
    return {"total": total, "success": success, "warning": warning, "failed": failed, "running": running, "unknown": unknown, "health": health}


def backup_platform_stats(items: list[BackupObject]) -> list[dict]:
    result = {}
    for item in items:
        row = result.setdefault(item.platform or "manual", {"platform": item.platform or "manual", "total": 0, "success": 0, "warning": 0, "failed": 0, "running": 0, "unknown": 0})
        row["total"] += 1
        if item.status in row:
            row[item.status] += 1
    rows = list(result.values())
    for row in rows:
        row["success_percent"] = round(row["success"] / row["total"] * 100, 1) if row["total"] else 0
    rows.sort(key=lambda x: x["total"], reverse=True)
    return rows


def backup_type_stats(items: list[BackupObject]) -> list[dict]:
    result = {}
    for item in items:
        key = item.object_type or "other"
        result[key] = result.get(key, 0) + 1
    return [{"type": k, "count": v} for k, v in sorted(result.items(), key=lambda x: x[1], reverse=True)]


def parse_datetime_local(value) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    text_value = str(value).strip()
    if not text_value:
        return None
    # HTML datetime-local приходит как 2026-05-22T03:00
    return datetime.fromisoformat(text_value[:16])


def format_dt_for_input(value: datetime | None) -> str:
    return value.strftime("%Y-%m-%dT%H:%M") if value else ""


def backup_to_api(item: BackupObject) -> dict:
    return {
        "id": item.id,
        "object_name": item.object_name,
        "object_type": item.object_type,
        "platform": item.platform,
        "last_backup_at": item.last_backup_at,
        "next_backup_at": item.next_backup_at,
        "size_gb": item.size_gb,
        "storage": item.storage,
        "retention_days": item.retention_days,
        "duration_min": item.duration_min,
        "policy_name": item.policy_name,
        "responsible": item.responsible,
        "status": item.status,
        "comment": item.comment,
        "hours_since_backup": item.hours_since_backup(),
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }



@app.get("/admin/backups", response_class=HTMLResponse)
def backups_page(request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role("admin"))):
    return templates.TemplateResponse(
        request=request,
        name="backups.html",
        context={
            "app_name": settings.app_name,
            "backups": list_db_backups(),
            "backup_dir": str(get_backup_dir()),
            "database_path": str(get_sqlite_db_path()),
            "current_user": current_user,
        },
    )


@app.post("/admin/backups/create")
def create_backup(db: Session = Depends(get_db), current_user: User = Depends(require_role("admin"))):
    backup_path = create_sqlite_backup(current_user.username)
    log_change(db, "system", None, "backup", f"Создана резервная копия базы: {backup_path.name}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/admin/backups", status_code=303)


@app.get("/admin/backups/{filename}/download")
def download_backup(filename: str, current_user: User = Depends(require_role("admin"))):
    path = validate_backup_filename(filename)
    return FileResponse(path=str(path), media_type="application/octet-stream", filename=path.name)


@app.post("/admin/backups/{filename}/delete")
def delete_backup(filename: str, db: Session = Depends(get_db), current_user: User = Depends(require_role("admin"))):
    path = validate_backup_filename(filename)
    path.unlink()
    log_change(db, "system", None, "backup_delete", f"Удалена резервная копия базы: {filename}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/admin/backups", status_code=303)



@app.get("/backup-monitor", response_class=HTMLResponse)
def backup_monitor_page(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    current_user = get_current_user(request, db)
    if settings.auth_enabled and current_user is None:
        return RedirectResponse(url="/login", status_code=303)
    items = backup_query(db, q, status, responsible)
    all_items = backup_query(db)
    return templates.TemplateResponse(
        request=request,
        name="backup_monitor.html",
        context={
            "app_name": settings.app_name,
            "items": items,
            "all_items": all_items,
            "stats": backup_stats(all_items),
            "platform_stats": backup_platform_stats(all_items),
            "type_stats": backup_type_stats(all_items),
            "selected": {"q": q or "", "status": status or "", "responsible": responsible or "", "groups": selected_groups, "manufacturers": selected_manufacturers},
            "responsibles": distinct_responsibles(db, BackupObject),
            "statuses": ["success", "warning", "failed", "running", "unknown"],
            "current_user": current_user,
            "can_edit": user_can(current_user, "editor"),
            "can_manage": user_can(current_user, "manager"),
            "can_admin": user_can(current_user, "admin"),
            "format_dt_for_input": format_dt_for_input,
        },
    )


@app.post("/backup-monitor")
def create_backup_object(
    object_name: str = Form("-"), object_type: str = Form("vm"), platform: str = Form("manual"),
    last_backup_at: str | None = Form(None), next_backup_at: str | None = Form(None), size_gb: str | None = Form(None),
    storage: str | None = Form(None), retention_days: str | None = Form(None), duration_min: str | None = Form(None),
    policy_name: str | None = Form(None), responsible: str | None = Form(None), status: str = Form("success"),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = BackupObject(
        object_name=object_name or "-", object_type=object_type or "vm", platform=platform or "manual",
        last_backup_at=parse_datetime_local(last_backup_at), next_backup_at=parse_datetime_local(next_backup_at),
        size_gb=parse_int(size_gb), storage=storage or None, retention_days=parse_int(retention_days),
        duration_min=parse_int(duration_min), policy_name=policy_name or None, responsible=responsible or None,
        status=status or "success", comment=comment or None,
    )
    db.add(item)
    db.flush()
    log_change(db, "backup_monitor", item.id, "create", f"Добавлен объект резервного копирования: {item.object_name}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/backup-monitor", status_code=303)


@app.post("/backup-monitor/{item_id}/update")
def update_backup_object(
    item_id: int,
    object_name: str = Form("-"), object_type: str = Form("vm"), platform: str = Form("manual"),
    last_backup_at: str | None = Form(None), next_backup_at: str | None = Form(None), size_gb: str | None = Form(None),
    storage: str | None = Form(None), retention_days: str | None = Form(None), duration_min: str | None = Form(None),
    policy_name: str | None = Form(None), responsible: str | None = Form(None), status: str = Form("success"),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(BackupObject, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Backup object not found")
    item.object_name = object_name or "-"
    item.object_type = object_type or "vm"
    item.platform = platform or "manual"
    item.last_backup_at = parse_datetime_local(last_backup_at)
    item.next_backup_at = parse_datetime_local(next_backup_at)
    item.size_gb = parse_int(size_gb)
    item.storage = storage or None
    item.retention_days = parse_int(retention_days)
    item.duration_min = parse_int(duration_min)
    item.policy_name = policy_name or None
    item.responsible = responsible or None
    item.status = status or "success"
    item.comment = comment or None
    log_change(db, "backup_monitor", item.id, "update", f"Обновлён объект резервного копирования: {item.object_name}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/backup-monitor", status_code=303)


@app.post("/backup-monitor/{item_id}/delete")
def delete_backup_object(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(BackupObject, item_id)
    if item:
        log_change(db, "backup_monitor", item.id, "delete", f"Удалён объект резервного копирования: {item.object_name}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/backup-monitor", status_code=303)


@app.get("/api/backup-monitor")
def api_backup_monitor(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [backup_to_api(x) for x in backup_query(db, q, status, responsible)]


@app.get("/api/backup-monitor/summary")
def api_backup_monitor_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    items = backup_query(db)
    return {"stats": backup_stats(items), "platforms": backup_platform_stats(items), "types": backup_type_stats(items)}


@app.get("/data-protection", response_class=HTMLResponse)
def data_protection_page(request: Request, q: str | None = None, backup_type: str | None = None, responsible: str | None = None, preview: str | None = None, db: Session = Depends(get_db)):
    current_user = get_current_user(request, db)
    if settings.auth_enabled and current_user is None:
        return RedirectResponse(url="/login", status_code=303)
    items = dp_query(db, q, backup_type, responsible)
    all_items = dp_query(db)
    import_preview = load_import_preview(preview) if preview else None
    if import_preview:
        import_preview["stats"] = data_protection_import_stats(import_preview.get("rows", []))
    return templates.TemplateResponse(
        request=request,
        name="data_protection.html",
        context={
            "app_name": settings.app_name,
            "items": items,
            "all_items": all_items,
            "groups": dp_grouped(items),
            "stats": dp_stats(all_items),
            "type_stats": dp_type_stats(all_items),
            "schedule_stats": dp_schedule_stats(all_items),
            "backup_types": DP_TYPE_LABELS,
            "selected": {"q": q or "", "backup_type": backup_type or "", "responsible": responsible or ""},
            "responsibles": distinct_responsibles(db, DataProtectionPolicy),
            "current_user": current_user,
            "can_edit": user_can(current_user, "editor"),
            "can_manage": user_can(current_user, "manager"),
            "can_admin": user_can(current_user, "admin"),
            "format_volume": format_volume,
            "import_preview": import_preview,
        },
    )


@app.post("/data-protection")
def create_data_protection_policy(
    row_number: str | None = Form(None), backup_type: str = Form("filesystem"), system_name: str = Form("-"),
    reserved_information: str | None = Form(None), max_volume_gb: str | None = Form(None), procedure_frequency: str | None = Form(None),
    retention_period: str | None = Form(None), notes: str | None = Form(None), responsible_person: str | None = Form(None),
    db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = DataProtectionPolicy(
        row_number=parse_int(row_number), backup_type=normalize_backup_type(backup_type), system_name=system_name or "-",
        reserved_information=reserved_information or None, max_volume_gb=parse_volume_gb(max_volume_gb),
        procedure_frequency=procedure_frequency or None, retention_period=retention_period or None, notes=notes or None,
        responsible_person=responsible_person or None,
    )
    db.add(item)
    db.flush()
    log_change(db, "data_protection", item.id, "create", f"Добавлена политика резервирования: {item.system_name}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/data-protection", status_code=303)


@app.post("/data-protection/{item_id}/update")
def update_data_protection_policy(
    item_id: int, row_number: str | None = Form(None), backup_type: str = Form("filesystem"), system_name: str = Form("-"),
    reserved_information: str | None = Form(None), max_volume_gb: str | None = Form(None), procedure_frequency: str | None = Form(None),
    retention_period: str | None = Form(None), notes: str | None = Form(None), responsible_person: str | None = Form(None),
    db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(DataProtectionPolicy, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Data protection policy not found")
    item.row_number = parse_int(row_number)
    item.backup_type = normalize_backup_type(backup_type)
    item.system_name = system_name or "-"
    item.reserved_information = reserved_information or None
    item.max_volume_gb = parse_volume_gb(max_volume_gb)
    item.procedure_frequency = procedure_frequency or None
    item.retention_period = retention_period or None
    item.notes = notes or None
    item.responsible_person = responsible_person or None
    log_change(db, "data_protection", item.id, "update", f"Обновлена политика резервирования: {item.system_name}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/data-protection", status_code=303)


@app.post("/data-protection/{item_id}/delete")
def delete_data_protection_policy(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(DataProtectionPolicy, item_id)
    if item:
        log_change(db, "data_protection", item.id, "delete", f"Удалена политика резервирования: {item.system_name}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/data-protection", status_code=303)


@app.get("/api/data-protection/plan")
def api_data_protection_plan(request: Request, q: str | None = None, backup_type: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [dp_to_api(x) for x in dp_query(db, q, backup_type, responsible)]


@app.get("/api/data-protection/summary")
def api_data_protection_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    items = dp_query(db)
    return {"stats": dp_stats(items), "types": dp_type_stats(items)}


@app.post("/data-protection/clear")
def clear_data_protection_policies(db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    deleted = db.query(DataProtectionPolicy).delete(synchronize_session=False)
    log_change(db, "data_protection", None, "clear", f"Очищена таблица политик резервирования. Удалено записей: {deleted}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/data-protection", status_code=303)


def clean_cell(value) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def detect_docx_backup_type(row_values: list[str], current_type: str) -> str:
    joined = " ".join(v.lower() for v in row_values if v)
    if "filesystem" in joined or "file system" in joined or "файлов" in joined:
        return "filesystem"
    if "internal database" in joined or "internal db" in joined or "встроенн" in joined:
        return "internal_database"
    if "ms sql" in joined or "mssql" in joined or "sql server" in joined:
        return "ms_sql_server"
    if "virtual environment" in joined or "virtual" in joined or "vmware" in joined or "виртуаль" in joined:
        return "virtual_environment"
    return current_type


def is_docx_header_row(row_values: list[str]) -> bool:
    joined = " ".join(v.lower() for v in row_values if v)
    header_words = ["наименование", "информац", "периодич", "срок", "ответствен", "резерв"]
    return sum(1 for word in header_words if word in joined) >= 3


def row_looks_like_group(row_values: list[str]) -> bool:
    non_empty = [v for v in row_values if v]
    # Word often duplicates text from merged cells in every physical cell.
    # Treat rows like "Filesystem | Filesystem | ..." as one group header.
    unique = {v.lower() for v in non_empty}
    if len(non_empty) == 1 or len(unique) == 1:
        value = next(iter(unique), "")
        return any(marker in value for marker in ["filesystem", "internal", "sql", "virtual", "файлов", "виртуаль"])
    return False


def normalize_preview_row_number(value) -> int | None:
    return parse_int(clean_cell(value))


def preview_row_to_policy_data(row_number, backup_type, system_name, reserved_information, max_volume, procedure_frequency, retention_period, notes, responsible_person) -> dict:
    return {
        "row_number": normalize_preview_row_number(row_number),
        "backup_type": normalize_backup_type(backup_type),
        "system_name": clean_cell(system_name) or "-",
        "reserved_information": clean_cell(reserved_information) or None,
        "max_volume_gb": parse_volume_gb(max_volume),
        "procedure_frequency": clean_cell(procedure_frequency) or None,
        "retention_period": clean_cell(retention_period) or None,
        "notes": clean_cell(notes) or None,
        "responsible_person": clean_cell(responsible_person) or None,
    }


def data_protection_preview_dir() -> Path:
    path = Path.cwd() / "data" / "import_previews"
    path.mkdir(parents=True, exist_ok=True)
    return path


def save_import_preview(rows: list[dict], source_filename: str, source_type: str, username: str) -> str:
    token = uuid.uuid4().hex
    payload = {
        "token": token,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source_filename": source_filename,
        "source_type": source_type,
        "created_by": username,
        "rows": rows[:5000],
        "total_rows": len(rows),
    }
    (data_protection_preview_dir() / f"{token}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return token


def load_import_preview(token: str) -> dict | None:
    if not token or not re.fullmatch(r"[a-f0-9]{32}", token):
        return None
    path = data_protection_preview_dir() / f"{token}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def delete_import_preview(token: str) -> None:
    if token and re.fullmatch(r"[a-f0-9]{32}", token):
        path = data_protection_preview_dir() / f"{token}.json"
        if path.exists():
            path.unlink()


def data_protection_import_stats(rows: list[dict]) -> dict:
    volume = sum(row.get("max_volume_gb") or 0 for row in rows)
    no_system = sum(1 for row in rows if not row.get("system_name") or row.get("system_name") == "-")
    no_responsible = sum(1 for row in rows if not row.get("responsible_person"))
    by_type = {}
    for row in rows:
        key = normalize_backup_type(row.get("backup_type"))
        item = by_type.setdefault(key, {"type": key, "label": DP_TYPE_LABELS.get(key, key), "count": 0, "volume_gb": 0})
        item["count"] += 1
        item["volume_gb"] += row.get("max_volume_gb") or 0
    types = []
    for item in by_type.values():
        item["volume_label"] = format_volume(item["volume_gb"])
        types.append(item)
    return {"count": len(rows), "volume_gb": volume, "volume_label": format_volume(volume), "no_system": no_system, "no_responsible": no_responsible, "types": sorted(types, key=lambda x: x["label"])}


def parse_data_protection_xlsx_rows(file_bytes: bytes) -> list[dict]:
    wb = load_workbook(BytesIO(file_bytes), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    parsed = []
    for row in rows[1:]:
        values = [clean_cell(v) for v in row]
        if not any(values) or is_docx_header_row(values):
            continue
        parsed.append(preview_row_to_policy_data(
            values[0] if len(values) > 0 else None,
            values[1] if len(values) > 1 else None,
            values[2] if len(values) > 2 else None,
            values[3] if len(values) > 3 else None,
            values[4] if len(values) > 4 else None,
            values[5] if len(values) > 5 else None,
            values[6] if len(values) > 6 else None,
            values[7] if len(values) > 7 else None,
            values[8] if len(values) > 8 else None,
        ))
    return parsed


def parse_data_protection_docx_rows(file_bytes: bytes) -> list[dict]:
    if Document is None:
        raise HTTPException(status_code=500, detail="python-docx is not installed. Run: pip3 install python-docx")
    document = Document(BytesIO(file_bytes))
    current_type = "filesystem"
    parsed = []
    for table in document.tables:
        for row in table.rows:
            values = [clean_cell(cell.text) for cell in row.cells]
            if not any(values):
                continue

            # ВАЖНО: строки вида "Filesystem", "Internal Database",
            # "MS SQL Server", "Virtual Environment" являются заголовками
            # блоков, а не отдельными политиками. Тип резервирования меняется
            # только на таких строках. Обычные строки не должны менять группу,
            # даже если в тексте встретилось слово "virtual", "sql" и т.п.
            if row_looks_like_group(values):
                current_type = detect_docx_backup_type(values, current_type)
                continue

            if is_docx_header_row(values):
                continue

            # Expected Word order:
            # № | system | information | max GB | frequency | retention | notes | responsible
            data = preview_row_to_policy_data(
                values[0] if len(values) > 0 else None,
                current_type,
                values[1] if len(values) > 1 else None,
                values[2] if len(values) > 2 else None,
                values[3] if len(values) > 3 else None,
                values[4] if len(values) > 4 else None,
                values[5] if len(values) > 5 else None,
                values[6] if len(values) > 6 else None,
                values[7] if len(values) > 7 else None,
            )

            # Skip junk rows: repeated titles, separator rows, and rows without
            # useful object data. Group headers are already skipped above.
            joined = " ".join(str(x or "") for x in values).lower()
            if data["system_name"] == "-" and not data["reserved_information"]:
                continue
            if any(word in joined for word in ["наименование информационной системы", "информация, подлежащая", "ответственный работник"]):
                continue
            parsed.append(data)
    return parsed


def create_data_protection_items_from_rows(db: Session, rows: list[dict]) -> int:
    imported = 0
    for row in rows:
        item = DataProtectionPolicy(
            row_number=row.get("row_number"),
            backup_type=normalize_backup_type(row.get("backup_type")),
            system_name=row.get("system_name") or "-",
            reserved_information=row.get("reserved_information"),
            max_volume_gb=row.get("max_volume_gb"),
            procedure_frequency=row.get("procedure_frequency"),
            retention_period=row.get("retention_period"),
            notes=row.get("notes"),
            responsible_person=row.get("responsible_person"),
        )
        db.add(item)
        imported += 1
    return imported


@app.get("/data-protection/export.xlsx")
def export_data_protection_xlsx(db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    wb = Workbook()
    ws = wb.active
    ws.title = "data_protection_plan"
    headers = ["№", "Тип backup", "Наименование информационной системы", "Информация, подлежащая резервированию", "Максимальный объём, ГБ", "Периодичность проведения процедуры", "Срок хранения информации", "Примечания", "Ответственный работник"]
    ws.append(headers)
    for item in dp_query(db):
        ws.append([item.row_number, DP_TYPE_LABELS.get(item.backup_type, item.backup_type), item.system_name, item.reserved_information, item.max_volume_gb, item.procedure_frequency, item.retention_period, item.notes, item.responsible_person])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
    for column_cells in ws.columns:
        length = max(len(str(cell.value or "")) for cell in column_cells)
        ws.column_dimensions[get_column_letter(column_cells[0].column)].width = min(max(length + 2, 12), 55)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="data_protection_plan_{date.today().isoformat()}.xlsx"'})


@app.post("/data-protection/import.xlsx/preview")
async def preview_data_protection_xlsx(file: UploadFile = File(...), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Upload .xlsx file")
    rows = parse_data_protection_xlsx_rows(await file.read())
    token = save_import_preview(rows, file.filename, "Excel", current_user.username)
    return RedirectResponse(url=f"/data-protection?preview={token}", status_code=303)


@app.post("/data-protection/import.docx/preview")
async def preview_data_protection_docx(file: UploadFile = File(...), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith(".docx"):
        raise HTTPException(status_code=400, detail="Upload .docx file")
    rows = parse_data_protection_docx_rows(await file.read())
    token = save_import_preview(rows, file.filename, "Word", current_user.username)
    return RedirectResponse(url=f"/data-protection?preview={token}", status_code=303)


@app.post("/data-protection/import/commit")
def commit_data_protection_import(
    token: str = Form(...),
    clear_before_import: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    preview = load_import_preview(token)
    if not preview:
        raise HTTPException(status_code=404, detail="Import preview not found or expired")
    rows = preview.get("rows", [])
    if clear_before_import:
        db.query(DataProtectionPolicy).delete(synchronize_session=False)
    imported = create_data_protection_items_from_rows(db, rows)
    log_change(
        db,
        "data_protection",
        None,
        "import",
        f"Подтверждён импорт Data Protection из {preview.get('source_type')}: {preview.get('source_filename')}. Записей: {imported}",
        actor=current_user.username,
    )
    db.commit()
    delete_import_preview(token)
    return RedirectResponse(url="/data-protection", status_code=303)


@app.post("/data-protection/import/cancel")
def cancel_data_protection_import(token: str = Form(...), current_user: User = Depends(require_role("manager"))):
    delete_import_preview(token)
    return RedirectResponse(url="/data-protection", status_code=303)


# Backward-compatible direct import endpoints. They now create a preview first.
@app.post("/data-protection/import.xlsx")
async def import_data_protection_xlsx(file: UploadFile = File(...), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Upload .xlsx file")
    rows = parse_data_protection_xlsx_rows(await file.read())
    token = save_import_preview(rows, file.filename, "Excel", current_user.username)
    return RedirectResponse(url=f"/data-protection?preview={token}", status_code=303)


@app.post("/data-protection/import.docx")
async def import_data_protection_docx(file: UploadFile = File(...), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith(".docx"):
        raise HTTPException(status_code=400, detail="Upload .docx file")
    rows = parse_data_protection_docx_rows(await file.read())
    token = save_import_preview(rows, file.filename, "Word", current_user.username)
    return RedirectResponse(url=f"/data-protection?preview={token}", status_code=303)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if not settings.auth_enabled:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(request=request, name="login.html", context={"app_name": settings.app_name, "error": None})


@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        return templates.TemplateResponse(request=request, name="login.html", context={"app_name": settings.app_name, "error": "Неверный логин или пароль"}, status_code=401)
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie(SESSION_COOKIE, create_session_token(user.id), httponly=True, samesite="lax", max_age=60 * 60 * 12)
    return response


@app.post("/logout")
def logout():
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(SESSION_COOKIE)
    return response


@app.get("/admin/users", response_class=HTMLResponse)
def users_page(request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role("admin"))):
    users = db.query(User).order_by(User.username).all()
    return templates.TemplateResponse(request=request, name="users.html", context={"app_name": settings.app_name, "users": users, "roles": ROLE_LABELS, "current_user": current_user})


@app.post("/admin/users")
def create_user(
    username: str = Form(...), password: str = Form(...), full_name: str | None = Form(None),
    email: str | None = Form(None), role: str = Form("viewer"), is_active: bool = Form(False),
    db: Session = Depends(get_db), current_user: User = Depends(require_role("admin")),
):
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Invalid role")
    existing = db.query(User).filter(User.username == username).first()
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")
    db.add(User(username=username, password_hash=hash_password(password), full_name=full_name or None, email=email or None, role=role, is_active=is_active))
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@app.post("/admin/users/{user_id}/update")
def update_user(
    user_id: int, full_name: str | None = Form(None), email: str | None = Form(None), role: str = Form("viewer"),
    is_active: bool = Form(False), password: str | None = Form(None), db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Invalid role")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.full_name = full_name or None
    user.email = email or None
    user.role = role
    user.is_active = is_active
    password = (password or "").strip()
    password = (password or "").strip()
    if password:
        user.password_hash = hash_password(password)
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@app.get("/", response_class=HTMLResponse)
def index(request: Request, section: str = "hardware", q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    current_user = get_current_user(request, db)
    if settings.auth_enabled and current_user is None:
        return RedirectResponse(url="/login", status_code=303)
    if section not in {"hardware", "software"}:
        section = "hardware"
    hw_all = hardware_query(db)
    sw_all = software_query(db)
    selected_groups = [g for g in request.query_params.getlist("group") if g]
    selected_manufacturers = [m for m in request.query_params.getlist("manufacturer") if m]
    items = hardware_query(db, q, status, responsible, selected_manufacturers) if section == "hardware" else software_query(db, q, status, responsible, selected_groups)
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "app_name": settings.app_name,
            "section": section,
            "items": items,
            "today": date.today(),
            "stats": stats_for(hw_all if section == "hardware" else sw_all),
            "global_stats": {"hardware": stats_for(hw_all), "software": stats_for(sw_all)},
            "selected": {"q": q or "", "status": status or "", "responsible": responsible or "", "groups": selected_groups, "manufacturers": selected_manufacturers},
            "responsibles": distinct_responsibles(db, HardwareSupport if section == "hardware" else SoftwareLicense),
            "software_groups": distinct_software_groups(db),
            "hardware_manufacturers": distinct_hardware_manufacturers(db),
            "statuses": ["active", "warning", "critical", "urgent", "expired"],
            "current_user": current_user,
            "can_edit": user_can(current_user, "editor"),
            "can_manage": user_can(current_user, "manager"),
            "can_admin": user_can(current_user, "admin"),
        },
    )


@app.post("/hardware")
def create_hardware(
    manufacturer: str | None = Form(None), dzo: str = Form("-"), serial_number: str = Form("-"), equipment_model: str = Form("-"), delivery_year: str | None = Form(None),
    support_end_date: str = Form(...), purchase_period: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), auto_renewal: bool = Form(False),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    end = parse_date(support_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания ТП обязательна")
    if hardware_serial_exists(db, serial_number):
        raise HTTPException(status_code=400, detail=f"Серийный номер уже существует: {serial_number}")
    item = HardwareSupport(
        manufacturer=manufacturer or None, dzo=dzo or "-", serial_number=serial_number or "-", equipment_model=equipment_model or "-", delivery_year=parse_int(delivery_year),
        support_end_date=end, purchase_period=purchase_period or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None, auto_renewal=auto_renewal, comment=comment or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "hardware", item.id, "create", f"Добавлена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)




@app.post("/hardware/clear")
def clear_hardware_table(db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    deleted = db.query(HardwareSupport).delete(synchronize_session=False)
    log_change(db, "hardware", None, "clear", f"Очищена таблица техподдержки оборудования. Удалено записей: {deleted}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software")
def create_software(
    group_name: str | None = Form(None), location: str | None = Form(None), code: str = Form("-"), quantity: int = Form(1), cert_start_date: str | None = Form(None), cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None), comment: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    end = parse_date(cert_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания сертификата обязательна")
    item = SoftwareLicense(
        group_name=group_name or None, location=location or None, code=code or "-", quantity=quantity or 1, cert_start_date=parse_date(cert_start_date), cert_end_date=end,
        certificate_number=certificate_number or None, comment=comment or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "software", item.id, "create", f"Добавлена лицензия ПО: {item.code}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.post("/hardware/{item_id}/delete")
def delete_hardware(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(HardwareSupport, item_id)
    if item:
        log_change(db, "hardware", item.id, "delete", f"Удалена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software/{item_id}/delete")
def delete_software(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(SoftwareLicense, item_id)
    if item:
        log_change(db, "software", item.id, "delete", f"Удалена лицензия ПО: {item.code}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.post("/hardware/{item_id}/update")
def update_hardware(
    item_id: int,
    manufacturer: str | None = Form(None), dzo: str = Form("-"), serial_number: str = Form("-"), equipment_model: str = Form("-"), delivery_year: str | None = Form(None),
    support_end_date: str = Form(...), purchase_period: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), auto_renewal: bool = Form(False),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    end = parse_date(support_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания ТП обязательна")
    if hardware_serial_exists(db, serial_number, exclude_id=item_id):
        raise HTTPException(status_code=400, detail=f"Серийный номер уже существует: {serial_number}")
    item.manufacturer = manufacturer or None
    item.dzo = dzo or "-"
    item.serial_number = serial_number or "-"
    item.equipment_model = equipment_model or "-"
    item.delivery_year = parse_int(delivery_year)
    item.support_end_date = end
    item.purchase_period = purchase_period or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    item.auto_renewal = auto_renewal
    item.comment = comment or None
    update_status(item)
    log_change(db, "hardware", item.id, "update", f"Обновлена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software/{item_id}/update")
def update_software(
    item_id: int,
    group_name: str | None = Form(None), location: str | None = Form(None), code: str = Form("-"), quantity: int = Form(1), cert_start_date: str | None = Form(None), cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None), comment: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    end = parse_date(cert_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания сертификата обязательна")
    item.group_name = group_name or None
    item.location = location or None
    item.code = code or "-"
    item.quantity = quantity or 1
    item.cert_start_date = parse_date(cert_start_date)
    item.cert_end_date = end
    item.certificate_number = certificate_number or None
    item.comment = comment or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    update_status(item)
    log_change(db, "software", item.id, "update", f"Обновлена лицензия ПО: {item.code}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.get("/history", response_class=HTMLResponse)
def history_page(request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_login)):
    history = db.query(ChangeLog).order_by(ChangeLog.created_at.desc()).limit(200).all()
    return templates.TemplateResponse(request=request, name="history.html", context={"history": history, "app_name": settings.app_name, "current_user": current_user, "can_admin": user_can(current_user, "admin") })


def hardware_to_api(item: HardwareSupport) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "hardware",
        "section_name": "Техподдержка оборудования",
        "number": None,
        "manufacturer": item.manufacturer,
        "dzo": item.dzo,
        "serial_number": item.serial_number,
        "equipment_model": item.equipment_model,
        "delivery_year": item.delivery_year,
        "support_end_date": item.support_end_date,
        "purchase_period": item.purchase_period,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "auto_renewal": item.auto_renewal,
        "comment": item.comment,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def software_to_api(item: SoftwareLicense) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "software",
        "section_name": "Лицензии ПО",
        "number": None,
        "group_name": item.group_name,
        "location": item.location,
        "code": item.code,
        "quantity": item.quantity,
        "cert_start_date": item.cert_start_date,
        "cert_end_date": item.cert_end_date,
        "certificate_number": item.certificate_number,
        "comment": item.comment,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def combined_api_items(db: Session, days: int | None = None) -> list[dict]:
    result = []
    for item in hardware_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(hardware_to_api(item))
    for item in software_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(software_to_api(item))
    result.sort(key=lambda x: x.get("days_left", 999999))
    for idx, item in enumerate(result, 1):
        item["number"] = idx
    return result



@app.get("/api/licenses")
def api_all_licenses(request: Request, section: str | None = None, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    """Совместимый API: возвращает записи обоих разделов или выбранного section=hardware/software."""
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]
    if section == "software":
        return [software_to_api(x) for x in software_query(db, q, status, responsible)]
    return combined_api_items(db)


@app.get("/api/licenses/expiring")
def api_expiring_licenses(request: Request, days: int = 30, section: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    today = date.today()
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db) if x.days_left(today) <= days]
    if section == "software":
        return [software_to_api(x) for x in software_query(db) if x.days_left(today) <= days]
    return combined_api_items(db, days=days)


@app.get("/api/hardware-support")
def api_hardware_support(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]


@app.get("/api/hardware-support/{item_id}")
def api_hardware_support_item(request: Request, item_id: int, db: Session = Depends(get_db)):
    require_api_key(request)
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    update_status(item)
    db.commit()
    return hardware_to_api(item)


@app.get("/api/software-licenses")
def api_software_licenses(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [software_to_api(x) for x in software_query(db, q, status, responsible)]


@app.get("/api/software-licenses/{item_id}")
def api_software_license_item(request: Request, item_id: int, db: Session = Depends(get_db)):
    require_api_key(request)
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    update_status(item)
    db.commit()
    return software_to_api(item)

@app.get("/api/monitoring/summary")
def api_monitoring_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    hw = hardware_query(db)
    sw = software_query(db)
    return {"hardware_support": stats_for(hw), "software_licenses": stats_for(sw), "backup_monitor": backup_stats(backup_query(db)), "data_protection": dp_stats(dp_query(db))}




@app.get("/api/zabbix/summary")
def api_zabbix_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    """Плоский JSON для Zabbix HTTP agent и JSONPath."""
    hw = stats_for(hardware_query(db))
    sw = stats_for(software_query(db))
    return {
        "hardware_total": hw["total"],
        "hardware_warning": hw["warning"],
        "hardware_critical": hw["critical"],
        "hardware_urgent": hw["urgent"],
        "hardware_expired": hw["expired"],
        "software_total": sw["total"],
        "software_warning": sw["warning"],
        "software_critical": sw["critical"],
        "software_urgent": sw["urgent"],
        "software_expired": sw["expired"],
        "total_expired": hw["expired"] + sw["expired"],
        "total_urgent": hw["urgent"] + sw["urgent"],
        "total_critical": hw["critical"] + sw["critical"],
        "total_warning": hw["warning"] + sw["warning"],
        "backup_total": backup_stats(backup_query(db))["total"],
        "backup_success": backup_stats(backup_query(db))["success"],
        "backup_warning": backup_stats(backup_query(db))["warning"],
        "backup_failed": backup_stats(backup_query(db))["failed"],
        "backup_running": backup_stats(backup_query(db))["running"],
        "backup_health": backup_stats(backup_query(db))["health"],
        "data_protection_total": dp_stats(dp_query(db))["total"],
        "data_protection_volume_gb": dp_stats(dp_query(db))["volume_gb"],
        "data_protection_no_responsible": dp_stats(dp_query(db))["no_responsible"],
    }

@app.get("/metrics", response_class=PlainTextResponse)
def metrics(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    hw = stats_for(hardware_query(db))
    sw = stats_for(software_query(db))
    lines = []
    for section, data in {"hardware": hw, "software": sw}.items():
        for key, value in data.items():
            lines.append(f'license_monitor_{key}{{section="{section}"}} {value}')
    backup = backup_stats(backup_query(db))
    for key, value in backup.items():
        lines.append(f'license_monitor_backup_{key} {value}')
    dp = dp_stats(dp_query(db))
    for key, value in dp.items():
        if isinstance(value, (int, float)):
            lines.append(f'license_monitor_data_protection_{key} {value}')
    return "\n".join(lines) + "\n"


@app.get("/export.xlsx")
def export_xlsx(section: str = "hardware", db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    wb = Workbook()
    ws = wb.active
    today = date.today()
    if section == "software":
        ws.title = "software_licenses"
        headers = ["№", "Производитель", "ДЗО", "Код", "Кол-во", "Дата начала сертификата", "Дата окончания сертификата", "Номер сертификата", "Комментарий", "Номер договора", "Контрагент", "Описание", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(software_query(db), 1):
            ws.append([idx, item.group_name, item.location, item.code, item.quantity, item.cert_start_date, item.cert_end_date, item.certificate_number, item.comment, item.contract_number, item.contractor, item.responsible, item.days_left(today), item.status])
        filename = f"software_licenses_{today.isoformat()}.xlsx"
    else:
        ws.title = "hardware_support"
        headers = ["№", "Производитель", "ДЗО", "Серийный номер", "Модель оборудования", "Год поставки", "Текущее состояние ТП (дата окончания)", "Срок на который закупается ТП", "Договор", "Контрагент", "Ответственный", "Автопродление", "Комментарий", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(hardware_query(db), 1):
            ws.append([idx, item.manufacturer, item.dzo, item.serial_number, item.equipment_model, item.delivery_year, item.support_end_date, item.purchase_period, item.contract_number, item.contractor, item.responsible, "да" if item.auto_renewal else "нет", item.comment, item.days_left(today), item.status])
        filename = f"hardware_support_{today.isoformat()}.xlsx"
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
    for column_cells in ws.columns:
        length = max(len(str(cell.value or "")) for cell in column_cells)
        ws.column_dimensions[get_column_letter(column_cells[0].column)].width = min(max(length + 2, 12), 45)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/import.xlsx")
async def import_xlsx(section: str = Form("hardware"), file: UploadFile = File(...), db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Upload .xlsx file")
    wb = load_workbook(BytesIO(await file.read()), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return RedirectResponse(url=f"/?section={section}", status_code=303)
    headers = [str(x).strip() if x is not None else "" for x in rows[0]]
    index = {name: i for i, name in enumerate(headers)}

    def val(row, name, default=None):
        i = index.get(name)
        return row[i] if i is not None and i < len(row) else default

    imported = 0
    for row in rows[1:]:
        if not row or not any(row):
            continue
        try:
            if section == "software":
                end = parse_date(val(row, "Дата окончания сертификата"))
                if not end:
                    continue
                item = SoftwareLicense(
                    group_name=str((val(row, "Производитель") if val(row, "Производитель") is not None else val(row, "Группа")) or "").strip() or None,
                    location=str((val(row, "ДЗО") if val(row, "ДЗО") is not None else val(row, "Локация")) or "").strip() or None,
                    code=str(val(row, "Код", "-") or "-").strip(), quantity=parse_int(val(row, "Кол-во"), 1) or 1,
                    cert_start_date=parse_date(val(row, "Дата начала сертификата")), cert_end_date=end,
                    certificate_number=str(val(row, "Номер сертификата") or "").strip() or None,
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                    contract_number=str(val(row, "Номер договора") or "").strip() or None,
                    contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str((val(row, "Описание") if val(row, "Описание") is not None else val(row, "Ответственный")) or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
            else:
                end = parse_date(val(row, "Текущее состояние ТП (дата окончания)"))
                if not end:
                    continue
                serial_import = str(val(row, "Серийный номер", "-") or "-").strip()
                if hardware_serial_exists(db, serial_import):
                    continue
                item = HardwareSupport(
                    manufacturer=str(val(row, "Производитель") or "").strip() or None,
                    dzo=str(val(row, "ДЗО", "-") or "-").strip(), serial_number=serial_import,
                    equipment_model=str(val(row, "Модель оборудования", "-") or "-").strip(), delivery_year=parse_int(val(row, "Год поставки")),
                    support_end_date=end, purchase_period=str(val(row, "Срок на который закупается ТП") or "").strip() or None,
                    contract_number=str(val(row, "Договор") or "").strip() or None, contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str((val(row, "Описание") if val(row, "Описание") is not None else val(row, "Ответственный")) or "").strip() or None, auto_renewal=parse_bool(val(row, "Автопродление")),
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
        except Exception:
            continue
    log_change(db, section, None, "import", f"Импортировано строк из Excel: {imported}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url=f"/?section={section}", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}
