# v16.35 replace files

Скопировать поверх текущих:
- app/main.py -> /opt/license-monitor/app/main.py
- app/templates/data_protection.html -> /opt/license-monitor/app/templates/data_protection.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
