# v16.30 replace files

Скопировать поверх текущих:

- app/templates/index.html -> /opt/license-monitor/app/templates/index.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css
- app/main.py -> /opt/license-monitor/app/main.py

Потом:

```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
