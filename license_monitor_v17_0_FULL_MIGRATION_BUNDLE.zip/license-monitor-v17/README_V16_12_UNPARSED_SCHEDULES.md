# v16.12 — диагностика нераспознанных расписаний

Добавлено:
- блок «Не распознано расписание» в Data Protection;
- список строк, которые парсер не смог корректно разобрать по дням/времени/типу;
- причины: не найден день недели, не найдено время запуска, не найден тип Full/Incr, не распознана периодичность.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
