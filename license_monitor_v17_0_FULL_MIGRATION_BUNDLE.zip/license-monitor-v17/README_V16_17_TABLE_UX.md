# v16.17 — Table UX cleanup

Изменения:
- убрана колонка «Действия» с красной кнопкой удаления;
- удаление осталось через карточку записи;
- во вкладке «Лицензии ПО» скрыт столбец «Номер договора» из таблицы;
- во вкладке «Лицензии ПО» заголовок «Ответственный» заменён на «Описание»;
- добавлено сохранение сортировки таблиц в localStorage;
- добавлены CSS-правки под 1280/1440/1920/4K.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
