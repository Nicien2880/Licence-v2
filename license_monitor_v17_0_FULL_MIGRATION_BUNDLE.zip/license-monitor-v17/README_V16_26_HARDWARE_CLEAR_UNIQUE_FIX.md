# v16.26 — Hardware clear button + serial uniqueness fix

Исправлено:
- кнопка «Очистить таблицу» гарантированно добавлена в верхнюю панель вкладки «Техподдержка оборудования»;
- маршрут `POST /hardware/clear` добавлен в backend;
- проверка уникальности серийного номера явно добавлена в:
  - ручное добавление `/hardware`;
  - редактирование `/hardware/{item_id}/update`;
  - импорт Excel.

Проверка:
1. Открой вкладку «Техподдержка оборудования».
2. В верхней панели должна быть кнопка «Очистить таблицу».
3. Попробуй вручную добавить запись с уже существующим серийным номером — приложение должно вернуть ошибку `Серийный номер уже существует`.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
