# v16.14 — Differential backups

Добавлено:
- поддержка Diff / Differential backups в Data Protection dashboard;
- распознавание слов: diff, differential, differ, дифф, дифференц;
- отдельный счётчик Differential;
- Diff учитывается по дням недели;
- Diff больше не считается как «Прочее»;
- причины нераспознавания теперь говорят Full/Incr/Diff.

Также сохранены правила из v16.13:
- через день;
- каждые 2/3/4 недели;
- AM/PM время.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
