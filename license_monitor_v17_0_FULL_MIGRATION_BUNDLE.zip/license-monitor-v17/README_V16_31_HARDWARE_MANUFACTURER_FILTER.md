# v16.31 — Hardware manufacturer filter

Добавлено во вкладку «Техподдержка оборудования»:
- новое поле «Производитель»;
- столбец «Производитель» между № и ДЗО;
- фильтр «Производитель» с выпадающим списком и чекбоксами;
- множественный выбор производителей;
- сохранение выбранных производителей в localStorage;
- импорт/экспорт Excel с колонкой «Производитель»;
- авто-добавление колонки `manufacturer` в существующую SQLite-базу.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
