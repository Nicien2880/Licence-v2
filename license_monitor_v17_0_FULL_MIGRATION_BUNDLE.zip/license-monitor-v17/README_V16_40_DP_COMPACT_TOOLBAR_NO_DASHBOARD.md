# v16.40 — Data Protection compact toolbar + no dashboard

Изменения:
- убран верхний dashboard с KPI-карточками во вкладке Data Protection;
- кнопки в верхней панели сделаны компактнее:
  - Экспорт;
  - Импорт;
  - Добавить;
- кнопки сгруппированы, чтобы не разъезжались;
- импорт и добавление по-прежнему открываются отдельными скрытыми панелями.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
