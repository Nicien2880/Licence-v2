# v16.43 — Clean Sidebar Menu

Изменения меню:
- убраны служебные пункты API / Metrics из пользовательской навигации;
- основное меню оставлено только для рабочих разделов:
  - Техподдержка оборудования;
  - Лицензии ПО;
  - Data Protection;
- «История изменений» оставлена отдельно;
- админские пункты сгруппированы в блок «Администрирование»:
  - Пользователи;
  - Резервные копии БД;
- технические URL не удалены, просто скрыты из меню.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
