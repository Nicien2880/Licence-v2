# v16.37 — Data Protection Heatmap Grid Fix

Исправлено:
- heatmap больше не строится HTML-таблицей;
- часы находятся только в верхней строке;
- дни недели находятся только слева;
- внутри сетки только цветные квадраты;
- убраны лишние подписи «день» и съехавшие часы;
- значения доступны через подсказку при наведении.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
