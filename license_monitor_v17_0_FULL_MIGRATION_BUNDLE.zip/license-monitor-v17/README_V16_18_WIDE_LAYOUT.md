# v16.18 — Wide Monitor Layout

Исправление:
- вкладки «Лицензии ПО» и «Техподдержка оборудования» теперь используют почти всю ширину большого монитора;
- убрано искусственное ограничение ширины контейнера;
- таблицы растягиваются на доступную ширину;
- добавлены отдельные правила для 1600px+ и 2200px+.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
