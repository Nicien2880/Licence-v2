# v16.20 — Filter UI Fix

Исправлено:
- убран фильтр «Все ответственные» во вкладке «Лицензии ПО»;
- фильтр «Группа» расположен сразу после поля «Поиск по реестру»;
- кнопка «Применить» больше не растягивается огромной кнопкой;
- фильтр стал компактнее и ровнее.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
