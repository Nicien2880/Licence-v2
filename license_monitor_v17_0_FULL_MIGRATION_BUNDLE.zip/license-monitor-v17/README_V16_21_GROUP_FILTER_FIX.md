# v16.21 — Group Filter Fix

Исправлено:
- фильтр «Группа» во вкладке «Лицензии ПО» теперь реально фильтрует записи;
- backend принимает несколько `group` query-параметров через FastAPI Query;
- выбранные группы сохраняются в localStorage;
- позиции в выпадающем списке выровнены по левому краю: сначала чекбокс, потом имя группы.

Проверка вручную:

```bash
curl "http://127.0.0.1:8000/?section=software&group=VMware"
curl "http://127.0.0.1:8000/?section=software&group=VMware&group=Microsoft"
```

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
