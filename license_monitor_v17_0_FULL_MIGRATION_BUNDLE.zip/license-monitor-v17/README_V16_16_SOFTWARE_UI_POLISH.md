# v16.16 — Software licenses UI polish

Изменения:
- в таблице «Лицензии ПО» заголовок «Ответственный» заменён на «Описание»;
- форма «Добавить запись» в разделе «Лицензии ПО» убрана с главного экрана;
- добавлена кнопка «Добавить запись» в верхнюю панель;
- блок Excel убран с главного экрана;
- загрузка Excel перенесена в верхнюю панель рядом с экспортом;
- импорт Excel запускается после выбора файла.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
