# v16.39 — Data Protection toolbar actions

Исправлено реально:
- кнопка «Импорт из файла» добавлена рядом с «Экспорт Excel»;
- кнопка «Добавить политику резервирования» добавлена в верхнюю панель;
- старый блок импорта убран из body/карточек;
- форма добавления политики скрыта и открывается кнопкой;
- фильтры и таблица не тронуты.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
