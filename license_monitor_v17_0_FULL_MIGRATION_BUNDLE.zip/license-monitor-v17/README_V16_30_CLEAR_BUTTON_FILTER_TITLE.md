# v16.30 — Clear button in filter title

Исправление:
- кнопка «Очистить таблицу» перенесена в заголовок блока «Фильтры»;
- кнопка выровнена по правому краю;
- сама строка фильтров и её поля не изменялись;
- двойное подтверждение удаления сохранено;
- backend route `/hardware/clear` сохранён.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
