# v16.19 — Software group anchor filter

Добавлено:
- во вкладке «Лицензии ПО» новый столбец «Группа» между № и Локацией;
- поле «Группа» в форме добавления и карточке редактирования;
- фильтр по группам в верхнем блоке фильтров;
- фильтр работает как выпадающий список с множественным выбором;
- поле добавляется в существующую SQLite-базу автоматически через mini-migration;
- экспорт/импорт Excel поддерживает колонку «Группа».

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
