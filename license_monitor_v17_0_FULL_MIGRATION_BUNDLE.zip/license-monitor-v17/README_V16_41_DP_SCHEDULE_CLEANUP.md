# v16.41 — Data Protection schedule cleanup

Изменения:
- удалён раздел «Когда выполняются бэкапы»;
- блок «По типу процедуры» поднят выше и поставлен рядом с аналитическими карточками;
- блок «По времени запуска» удалён;
- тепловая карта запусков осталась отдельным визуальным блоком.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
