# v16.35 — Data Protection launch heatmap

Добавлено во вкладку Data Protection:
- тепловая карта запусков;
- матрица: дни недели × часы;
- расчёт по полю «Периодичность проведения процедуры»;
- поддержка Full / Incremental / Differential;
- поддержка «через день», «каждые 2/3/4 недели», AM/PM времени;
- ежедневные и «через день» процедуры распределяются по всем дням недели.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
