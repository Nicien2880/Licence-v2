# v16.27 — Remove main dashboards

Изменение:
- со страниц «Техподдержка оборудования» и «Лицензии ПО» удалены верхние dashboard-карточки:
  - Всего;
  - 31–60 дней;
  - 8–30 дней;
  - ≤ 7 дней;
  - Просрочено.

Остались:
- верхняя панель действий;
- фильтры;
- таблица;
- карточка записи;
- импорт/экспорт.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
