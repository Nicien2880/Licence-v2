# v16.36 — Data Protection Heatmap Redesign

Переделана тепловая карта запусков:
- убраны цифры из всех ячеек;
- добавлена цветовая шкала нагрузки;
- значения показываются при наведении;
- добавлена легенда 0 / 1–5 / 6–10 / 11–20 / 20+;
- добавлен блок «Пиковое окно»;
- карта выглядит как heatmap, а не как отладочная таблица.

Обновление:
```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
