# v16.24 — Hardware add button

Изменение:
- во вкладке «Техподдержка оборудования» форма добавления убрана с главного экрана;
- добавлена кнопка «Добавить запись» в верхнюю панель;
- форма открывается/скрывается так же, как во вкладке «Лицензии ПО».

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
