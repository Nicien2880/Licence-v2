# v16.23 — Group Filter Summary + Reset

Изменения:
- в фильтре «Группа» вместо количества выбранных чекбоксов отображаются выбранные группы;
- если групп много и строка длинная, она обрезается с tooltip;
- кнопка «Сбросить» перенесена рядом с «Применить»;
- сброс очищает сохранённые фильтры из localStorage.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
