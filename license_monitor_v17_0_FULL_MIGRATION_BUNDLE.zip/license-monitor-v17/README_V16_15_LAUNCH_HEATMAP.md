# v16.15 — Heatmap запусков

Добавлено:
- тепловая карта запусков в Data Protection;
- матрица: дни недели × часы;
- расчёт строится по полю «Периодичность проведения процедуры»;
- учитываются Full / Incremental / Differential;
- учитываются формулировки «через день», «каждые 2/3/4 недели», AM/PM время.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
