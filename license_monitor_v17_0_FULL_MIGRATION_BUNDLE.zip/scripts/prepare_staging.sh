#!/usr/bin/env bash
set -euo pipefail
CURRENT="/opt/license-monitor"
BUNDLE="/opt/license_monitor_v17_bundle"
PROJECT="${BUNDLE}/license-monitor-v17"
STAGING="/opt/license-monitor-v17-test"
sudo rm -rf "${STAGING}"
sudo mkdir -p "${STAGING}"
sudo rsync -av "${PROJECT}/" "${STAGING}/"
sudo cp "${CURRENT}/.env" "${STAGING}/.env"
sudo mkdir -p "${STAGING}/data"
sudo cp "${CURRENT}/data/license_monitor.db" "${STAGING}/data/license_monitor.db"
sudo chown -R license-monitor:license-monitor "${STAGING}"
echo "Staging ready: ${STAGING}"
