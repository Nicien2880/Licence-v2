#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/license-monitor"
BACKUP_DIR="/opt/license-monitor-backups"
TS="$(date +%F_%H%M%S)"
mkdir -p "${BACKUP_DIR}"
sudo tar -czf "${BACKUP_DIR}/app_before_${TS}.tar.gz" \
  --exclude="${APP_DIR}/data" \
  --exclude="${APP_DIR}/.env" \
  --exclude="${APP_DIR}/.venv" \
  "${APP_DIR}"
cp "${APP_DIR}/data/license_monitor.db" "${BACKUP_DIR}/db_before_${TS}.db"
echo "Backup created in ${BACKUP_DIR}"
