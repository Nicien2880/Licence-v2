#!/usr/bin/env bash
set -euo pipefail
PORT="${1:-8000}"
BASE_URL="http://127.0.0.1:${PORT}"
curl -I "${BASE_URL}/" || true
curl -I "${BASE_URL}/data-protection" || true
curl -I "${BASE_URL}/docs" || true
echo "Smoke HTTP check done"
