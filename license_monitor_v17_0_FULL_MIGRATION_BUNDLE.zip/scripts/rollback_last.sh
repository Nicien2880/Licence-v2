#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/license-monitor"
BACKUP_DIR="/opt/license-monitor-backups"
SERVICE="license-monitor"
APP_BACKUP="$(ls -1t ${BACKUP_DIR}/app_before_deploy_*.tar.gz ${BACKUP_DIR}/app_before_*.tar.gz 2>/dev/null | head -n 1)"
DB_BACKUP="$(ls -1t ${BACKUP_DIR}/db_before_deploy_*.db ${BACKUP_DIR}/db_before_*.db 2>/dev/null | head -n 1)"
echo "Restoring ${APP_BACKUP}"
echo "Restoring ${DB_BACKUP}"
sudo systemctl stop "${SERVICE}"
sudo tar -xzf "${APP_BACKUP}" -C /
cp "${DB_BACKUP}" "${APP_DIR}/data/license_monitor.db"
sudo chown -R license-monitor:license-monitor "${APP_DIR}"
find "${APP_DIR}" -name "*.pyc" -delete
find "${APP_DIR}" -type d -name "__pycache__" -exec rm -rf {} + || true
sudo systemctl start "${SERVICE}"
sudo systemctl status "${SERVICE}" --no-pager || true
journalctl -u "${SERVICE}" -n 120 --no-pager
