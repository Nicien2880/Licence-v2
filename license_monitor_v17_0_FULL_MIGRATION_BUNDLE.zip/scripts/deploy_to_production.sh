#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/opt/license-monitor"
STAGING="/opt/license-monitor-v17-test"
BACKUP_DIR="/opt/license-monitor-backups"
SERVICE="license-monitor"
TS="$(date +%F_%H%M%S)"
mkdir -p "${BACKUP_DIR}"
sudo tar -czf "${BACKUP_DIR}/app_before_deploy_${TS}.tar.gz" \
  --exclude="${APP_DIR}/data" \
  --exclude="${APP_DIR}/.env" \
  --exclude="${APP_DIR}/.venv" \
  "${APP_DIR}"
cp "${APP_DIR}/data/license_monitor.db" "${BACKUP_DIR}/db_before_deploy_${TS}.db"
sudo systemctl stop "${SERVICE}"
sudo rsync -av --exclude 'data/' --exclude '.env' --exclude '.venv/' "${STAGING}/" "${APP_DIR}/"
sudo chown -R license-monitor:license-monitor "${APP_DIR}"
find "${APP_DIR}" -name "*.pyc" -delete
find "${APP_DIR}" -type d -name "__pycache__" -exec rm -rf {} + || true
sudo systemctl start "${SERVICE}"
sudo systemctl status "${SERVICE}" --no-pager || true
journalctl -u "${SERVICE}" -n 120 --no-pager
