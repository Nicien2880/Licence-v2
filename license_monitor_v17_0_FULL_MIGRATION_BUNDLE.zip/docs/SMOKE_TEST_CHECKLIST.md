# Smoke-test checklist

## Команды

```bash
curl -I http://127.0.0.1:8000/
curl -I http://127.0.0.1:8000/data-protection
journalctl -u license-monitor -n 150 --no-pager
```

Не должно быть:
- AttributeError
- no such column
- TemplateNotFound
- Invalid API key на пользовательских страницах
- database is locked

## Проверить в браузере

Лицензии ПО:
- Производитель
- ДЗО
- фильтры
- экспорт/импорт
- карточка

Техподдержка оборудования:
- Производитель
- фильтр
- уникальность серийного номера
- очистка с подтверждением

Data Protection:
- импорт Word/Excel
- добавить политику
- heatmap
- нераспознанные расписания
- таблица
