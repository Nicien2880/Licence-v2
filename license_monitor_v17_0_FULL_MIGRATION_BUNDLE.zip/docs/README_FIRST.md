# License Monitor v17.0 FULL Migration Bundle

Состав комплекта:

```text
license-monitor-v17/   полный проект
docs/                  инструкция и чеклисты
scripts/               backup / staging / deploy / rollback
```

Миграция выполняется безопасно:

```text
backup текущего сервера
→ staging-копия на порту 8017
→ smoke-test
→ production deploy
→ rollback при необходимости
```

Не накатывай сразу поверх `/opt/license-monitor`, сначала проверь staging.
