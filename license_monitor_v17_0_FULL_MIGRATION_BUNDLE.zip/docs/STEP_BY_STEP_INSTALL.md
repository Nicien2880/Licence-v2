# Полная инструкция установки и миграции

## 1. Скопировать архив на сервер

```bash
scp license_monitor_v17_0_FULL_MIGRATION_BUNDLE.zip user@SERVER:/opt/
```

На сервере:

```bash
cd /opt
unzip license_monitor_v17_0_FULL_MIGRATION_BUNDLE.zip -d license_monitor_v17_bundle
cd /opt/license_monitor_v17_bundle
ls -la
```

Должно быть:

```text
license-monitor-v17
docs
scripts
```

## 2. Сделать backup текущей версии

```bash
chmod +x scripts/*.sh
sudo scripts/backup_current.sh
```

Backup появится в:

```bash
/opt/license-monitor-backups
```

## 3. Подготовить staging-копию

```bash
sudo scripts/prepare_staging.sh
```

Будет создано:

```bash
/opt/license-monitor-v17-test
```

Туда скопируются:
- новый проект;
- текущий `.env`;
- текущая SQLite-база.

## 4. Запустить staging на порту 8017

```bash
cd /opt/license-monitor-v17-test

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

uvicorn app.main:app --host 127.0.0.1 --port 8017
```

Во второй консоли:

```bash
cd /opt/license_monitor_v17_bundle
scripts/smoke_test.sh 8017
```

## 5. Проверить руками

Открыть:
- `/`
- `/data-protection`
- Лицензии ПО
- Техподдержка оборудования
- Data Protection
- импорт/экспорт
- heatmap
- меню
- карточки записей

Логи:

```bash
journalctl -u license-monitor -n 100 --no-pager
```

## 6. Накатить на production

Только после успешного staging:

```bash
cd /opt/license_monitor_v17_bundle
sudo scripts/deploy_to_production.sh
```

## 7. Проверить production

```bash
sudo systemctl status license-monitor --no-pager
journalctl -u license-monitor -n 150 --no-pager
curl -I http://127.0.0.1:8000/
curl -I http://127.0.0.1:8000/data-protection
```

## 8. Rollback при проблеме

```bash
cd /opt/license_monitor_v17_bundle
sudo scripts/rollback_last.sh
```
