# v16.34 replace files

Скопировать поверх текущих:

- app/main.py -> /opt/license-monitor/app/main.py
- app/templates/index.html -> /opt/license-monitor/app/templates/index.html

Потом:

```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
