(function () {
  const root = document.documentElement;

  function applyTheme(theme) {
    root.dataset.theme = theme;
    localStorage.setItem("lm_theme", theme);
  }

  const savedTheme = localStorage.getItem("lm_theme") || "light";
  applyTheme(savedTheme);

  const themeToggle = document.getElementById("themeToggle");
  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      applyTheme(root.dataset.theme === "dark" ? "light" : "dark");
    });
  }

  function applySidebarState() {
    const collapsed = localStorage.getItem("lm_sidebar_collapsed") === "true";
    document.body.classList.toggle("sidebar-collapsed", collapsed);
  }

  applySidebarState();
  document.querySelectorAll("[data-sidebar-toggle]").forEach((button) => {
    button.addEventListener("click", function () {
      const next = !(localStorage.getItem("lm_sidebar_collapsed") === "true");
      localStorage.setItem("lm_sidebar_collapsed", String(next));
      applySidebarState();
    });
  });

  const filtersForm = document.getElementById("filtersForm");
  if (filtersForm) {
    const section = filtersForm.dataset.section || "default";
    const key = "lm_filters_" + section;
    const currentParams = new URLSearchParams(window.location.search);

    if (!currentParams.has("q") && !currentParams.has("status") && !currentParams.has("responsible")) {
      const saved = JSON.parse(localStorage.getItem(key) || "{}");
      const hasSaved = saved.q || saved.status || saved.responsible;
      if (hasSaved) {
        const target = new URL(window.location.href);
        target.searchParams.set("section", section);
        ["q", "status", "responsible"].forEach((name) => {
          if (saved[name]) target.searchParams.set(name, saved[name]);
        });
        window.location.replace(target.toString());
      }
    }

    filtersForm.addEventListener("submit", function () {
      const data = new FormData(filtersForm);
      localStorage.setItem(key, JSON.stringify({
        q: data.get("q") || "",
        status: data.get("status") || "",
        responsible: data.get("responsible") || "",
      }));
    });

    const reset = document.getElementById("resetFilters");
    if (reset) {
      reset.addEventListener("click", function () {
        localStorage.removeItem(key);
      });
    }
  }

  function sortTable(table, columnIndex, direction) {
    const tbody = table.tBodies[0];
    const rows = Array.from(tbody.querySelectorAll("tr")).filter((row) => !row.querySelector(".empty"));

    rows.sort((a, b) => {
      const aCell = a.children[columnIndex];
      const bCell = b.children[columnIndex];
      const aValue = (aCell?.dataset.sort || aCell?.innerText || "").trim();
      const bValue = (bCell?.dataset.sort || bCell?.innerText || "").trim();
      const aNum = Number(aValue.replace(",", "."));
      const bNum = Number(bValue.replace(",", "."));

      let result;
      if (!Number.isNaN(aNum) && !Number.isNaN(bNum) && aValue !== "" && bValue !== "") {
        result = aNum - bNum;
      } else {
        result = aValue.localeCompare(bValue, "ru", { numeric: true, sensitivity: "base" });
      }
      return direction === "asc" ? result : -result;
    });

    rows.forEach((row) => tbody.appendChild(row));
  }

  document.querySelectorAll(".sortable-table").forEach((table) => {
    table.querySelectorAll("thead th").forEach((th, index) => {
      if (th.dataset.noSort === "true") return;
      th.classList.add("sortable");
      th.addEventListener("click", function () {
        const current = th.dataset.direction === "asc" ? "desc" : "asc";
        table.querySelectorAll("th").forEach((x) => {
          x.classList.remove("sort-asc", "sort-desc");
          delete x.dataset.direction;
        });
        th.dataset.direction = current;
        th.classList.add(current === "asc" ? "sort-asc" : "sort-desc");
        sortTable(table, index, current);
      });
    });
  });

  const modal = document.getElementById("detailModal");
  const modalTitle = document.getElementById("modalTitle");
  const modalDetails = document.getElementById("modalDetails");

  function openModal(row) {
    if (!modal || !modalDetails) return;
    modalTitle.innerText = row.dataset.title || "Карточка объекта";
    const headers = Array.from(row.closest("table").querySelectorAll("thead th")).map((th) => th.innerText.trim());
    const cells = Array.from(row.children);
    modalDetails.innerHTML = "";
    cells.forEach((cell, index) => {
      if (!headers[index] || headers[index] === "Действия") return;
      const block = document.createElement("div");
      block.className = "detail-item";
      const label = document.createElement("span");
      label.innerText = headers[index].replace(/\n/g, " ");
      const value = document.createElement("strong");
      value.innerText = cell.innerText.trim() || "—";
      block.appendChild(label);
      block.appendChild(value);
      modalDetails.appendChild(block);
    });
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }

  document.querySelectorAll(".clickable-row").forEach((row) => {
    row.addEventListener("click", function (event) {
      if (event.target.closest("button, a, form, input, select, textarea")) return;
      openModal(row);
    });
  });

  document.querySelectorAll("[data-modal-close]").forEach((el) => {
    el.addEventListener("click", function () {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    });
  });
})();
