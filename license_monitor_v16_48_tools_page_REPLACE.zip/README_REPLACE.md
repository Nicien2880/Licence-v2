# v16.48 replace files

Скопировать поверх текущих:
- app/main.py
- app/templates/*.html
- app/static/style.css
- app/static/app.js

Потом:
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor

Открыть: /tools
