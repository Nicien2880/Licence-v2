# v16.49 replace files

Скопировать поверх текущих:
- app/templates/tools.html -> /opt/license-monitor/app/templates/tools.html
- app/static/app.js -> /opt/license-monitor/app/static/app.js
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
