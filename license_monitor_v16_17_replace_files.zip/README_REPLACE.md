# v16.17 replace files

Скопировать поверх текущих:

- app/templates/index.html -> /opt/license-monitor/app/templates/index.html
- app/static/app.js -> /opt/license-monitor/app/static/app.js
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:

```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
