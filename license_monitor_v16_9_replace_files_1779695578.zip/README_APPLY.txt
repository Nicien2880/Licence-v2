License Monitor v16.9 — файлы для замены/добавления

1. Скопировать файл:
   static/v16_scroll_sync.js
   в:
   /opt/license-monitor/static/v16_scroll_sync.js

2. Содержимое файла:
   static/append_to_style.css
   добавить в самый конец:
   /opt/license-monitor/static/style.css

3. В шаблоне:
   /opt/license-monitor/templates/data_protection.html

   перед контейнером таблицы вставить:

   <div class="top-scroll" data-scroll-sync="dp">
     <div class="top-scroll-inner"></div>
   </div>

   контейнер таблицы сделать таким:

   <div class="table-wrap table-scroll" data-scroll-sync="dp">

   перед закрывающим </body> добавить:

   <script src="/static/v16_scroll_sync.js"></script>

4. После правок:

   sudo chown -R license-monitor:license-monitor /opt/license-monitor
   sudo systemctl restart license-monitor
