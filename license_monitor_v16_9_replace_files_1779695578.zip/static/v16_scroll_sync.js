document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".top-scroll[data-scroll-sync]").forEach(function (topScroll) {
    const key = topScroll.dataset.scrollSync;

    const tableScroll =
      document.querySelector('.table-scroll[data-scroll-sync="' + key + '"]') ||
      document.querySelector('.table-wrap[data-scroll-sync="' + key + '"]');

    if (!tableScroll) return;

    const inner = topScroll.querySelector(".top-scroll-inner");
    const table = tableScroll.querySelector("table");

    if (!inner || !table) return;

    function refreshWidth() {
      inner.style.width = table.scrollWidth + "px";
    }

    refreshWidth();
    window.addEventListener("resize", refreshWidth);

    let lock = false;

    topScroll.addEventListener("scroll", function () {
      if (lock) return;
      lock = true;
      tableScroll.scrollLeft = topScroll.scrollLeft;
      lock = false;
    });

    tableScroll.addEventListener("scroll", function () {
      if (lock) return;
      lock = true;
      topScroll.scrollLeft = tableScroll.scrollLeft;
      lock = false;
    });

    if (window.ResizeObserver) {
      const observer = new ResizeObserver(refreshWidth);
      observer.observe(table);
    }
  });
});
