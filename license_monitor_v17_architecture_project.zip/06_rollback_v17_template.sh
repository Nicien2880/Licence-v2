#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/license-monitor"
SERVICE="license-monitor"

if [ "$#" -ne 2 ]; then
  echo "Usage:"
  echo "./rollback_v17_template.sh APP_BACKUP.tar.gz DB_BACKUP.db"
  exit 1
fi

APP_BACKUP="$1"
DB_BACKUP="$2"

sudo systemctl stop "${SERVICE}"
sudo tar -xzf "${APP_BACKUP}" -C /
cp "${DB_BACKUP}" "${APP_DIR}/data/license_monitor.db"
sudo chown -R license-monitor:license-monitor "${APP_DIR}"
find "${APP_DIR}" -name "*.pyc" -delete
find "${APP_DIR}" -type d -name "__pycache__" -exec rm -rf {} + || true
sudo systemctl start "${SERVICE}"
sudo systemctl status "${SERVICE}" --no-pager || true
journalctl -u "${SERVICE}" -n 100 --no-pager
