# Шаблон накатки v17.0 на рабочий сервер

## 1. Backup текущей версии

```bash
cd /opt/license-monitor

sudo tar -czf /opt/license-monitor-backup-before-v17-$(date +%F_%H%M%S).tar.gz \
  --exclude='/opt/license-monitor/data' \
  --exclude='/opt/license-monitor/.env' \
  --exclude='/opt/license-monitor/.venv' \
  /opt/license-monitor

mkdir -p /opt/license-monitor/backups

cp /opt/license-monitor/data/license_monitor.db \
   /opt/license-monitor/backups/license_monitor_before_v17_$(date +%F_%H%M%S).db
```

## 2. Подготовить staging-копию

```bash
cd /opt

sudo mkdir -p /opt/license-monitor-v17-test
sudo chown -R license-monitor:license-monitor /opt/license-monitor-v17-test

unzip license_monitor_v17_FULL.zip -d /opt/license-monitor-v17-test
cp /opt/license-monitor/.env /opt/license-monitor-v17-test/.env
mkdir -p /opt/license-monitor-v17-test/data
cp /opt/license-monitor/data/license_monitor.db /opt/license-monitor-v17-test/data/license_monitor.db
```

## 3. Запуск staging на другом порту

```bash
cd /opt/license-monitor-v17-test

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

uvicorn app.main:app --host 127.0.0.1 --port 8017
```

Проверка:

```bash
curl -I http://127.0.0.1:8017/
curl -I http://127.0.0.1:8017/data-protection
curl -I http://127.0.0.1:8017/export.xlsx?section=software
```

## 4. Накат на production

```bash
sudo systemctl stop license-monitor

rsync -av \
  --exclude 'data/' \
  --exclude '.env' \
  --exclude '.venv/' \
  /opt/license-monitor-v17-test/ \
  /opt/license-monitor/

sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
find /opt/license-monitor -type d -name "__pycache__" -exec rm -rf {} +

sudo systemctl start license-monitor
sudo systemctl status license-monitor --no-pager
journalctl -u license-monitor -n 100 --no-pager
```

## 5. Rollback

```bash
sudo systemctl stop license-monitor

sudo tar -xzf /opt/license-monitor-backup-before-v17-YYYY-MM-DD_HHMMSS.tar.gz -C /

cp /opt/license-monitor/backups/license_monitor_before_v17_YYYY-MM-DD_HHMMSS.db \
   /opt/license-monitor/data/license_monitor.db

sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl start license-monitor
journalctl -u license-monitor -n 100 --no-pager
```
