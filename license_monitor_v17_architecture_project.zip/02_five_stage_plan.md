# План из 5 этапов

## Этап 1. Разделение по доменам

Вынести Software, Hardware и Data Protection в отдельные модули:

```python
app.include_router(software_router)
app.include_router(hardware_router)
app.include_router(data_protection_router)
```

Критерий готовности:
- старые URL работают;
- таблицы открываются;
- импорт/экспорт работает;
- API для Zabbix отвечает.

## Этап 2. Сервисный слой

Разделить:

```text
routes.py      HTTP, формы, шаблоны
service.py     бизнес-правила
repository.py  SQL-запросы
schemas.py     структуры данных
```

Например, проверка уникальности серийного номера должна жить в `hardware/service.py`, а не прямо в route.

## Этап 3. Настройки и состояние UI

Оставить в localStorage:
- ширины колонок;
- сортировку;
- состояние бокового меню.

Позже перенести в БД:
- сохранённые фильтры;
- пользовательские представления;
- наборы колонок.

## Этап 4. Очередь задач

Для тяжёлых операций:
- импорт Word;
- импорт Excel;
- пересчёт heatmap;
- массовое удаление;
- массовое обновление.

Минимально можно сделать через FastAPI `BackgroundTasks` и таблицу `jobs`.

## Этап 5. Единый движок таблиц

Сделать общий механизм таблиц:

```python
columns = [
    {"key": "manufacturer", "label": "Производитель", "sortable": True, "filter": "multi"},
    {"key": "dzo", "label": "ДЗО", "sortable": True},
    {"key": "status", "label": "Статус", "badge": True},
]
```

Тогда новые разделы будут собираться конфигурацией, а не копированием HTML.
