#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/license-monitor"
TEST_DIR="/opt/license-monitor-v17-test"
SERVICE="license-monitor"
TS="$(date +%F_%H%M%S)"

echo "[1/7] Backup app"
sudo tar -czf "/opt/license-monitor-backup-before-v17-${TS}.tar.gz" \
  --exclude="${APP_DIR}/data" \
  --exclude="${APP_DIR}/.env" \
  --exclude="${APP_DIR}/.venv" \
  "${APP_DIR}"

echo "[2/7] Backup DB"
mkdir -p "${APP_DIR}/backups"
cp "${APP_DIR}/data/license_monitor.db" "${APP_DIR}/backups/license_monitor_before_v17_${TS}.db"

echo "[3/7] Stop service"
sudo systemctl stop "${SERVICE}"

echo "[4/7] Sync files"
sudo rsync -av \
  --exclude 'data/' \
  --exclude '.env' \
  --exclude '.venv/' \
  "${TEST_DIR}/" \
  "${APP_DIR}/"

echo "[5/7] Permissions"
sudo chown -R license-monitor:license-monitor "${APP_DIR}"
find "${APP_DIR}" -name "*.pyc" -delete
find "${APP_DIR}" -type d -name "__pycache__" -exec rm -rf {} + || true

echo "[6/7] Start service"
sudo systemctl start "${SERVICE}"

echo "[7/7] Logs"
sudo systemctl status "${SERVICE}" --no-pager || true
journalctl -u "${SERVICE}" -n 100 --no-pager
