# Целевая структура v17.0

```text
app/
├── main.py
├── core/
│   ├── config.py
│   ├── db.py
│   ├── auth.py
│   └── logging.py
├── shared/
│   ├── excel.py
│   ├── filters.py
│   ├── tables.py
│   ├── dates.py
│   └── permissions.py
├── modules/
│   ├── software/
│   │   ├── routes.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   ├── import_export.py
│   │   └── schemas.py
│   ├── hardware/
│   │   ├── routes.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   ├── import_export.py
│   │   └── schemas.py
│   ├── data_protection/
│   │   ├── routes.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   ├── parser.py
│   │   ├── heatmap.py
│   │   ├── import_export.py
│   │   └── schemas.py
│   ├── admin/
│   │   ├── routes.py
│   │   └── service.py
│   └── integrations/
│       ├── routes.py
│       ├── zabbix.py
│       └── metrics.py
├── templates/
│   ├── base.html
│   ├── components/
│   │   ├── sidebar.html
│   │   ├── topbar.html
│   │   ├── filters.html
│   │   ├── table.html
│   │   └── modal.html
│   ├── software/index.html
│   ├── hardware/index.html
│   └── data_protection/index.html
└── static/
    ├── css/
    └── js/
```

`main.py` должен стать точкой сборки приложения, а не местом всей логики.
