# v16.45 replace files

Скопировать поверх текущих:
- app/main.py -> /opt/license-monitor/app/main.py
- app/templates/users.html -> /opt/license-monitor/app/templates/users.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```

Проверка:
1. Открой Администрирование → Пользователи.
2. В колонке «Новый пароль» введи пароль.
3. Нажми кнопку «Сохранить пароль» прямо рядом с полем.
4. Выйди и зайди под этим пользователем с новым паролем.
