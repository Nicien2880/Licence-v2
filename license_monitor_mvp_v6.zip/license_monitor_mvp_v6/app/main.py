from datetime import date, datetime
from io import BytesIO
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import or_
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .models import ChangeLog, HardwareSupport, SoftwareLicense
from .settings import get_settings

settings = get_settings()
app = FastAPI(title=settings.app_name)
BASE_DIR = Path(__file__).resolve().parent
Base.metadata.create_all(bind=engine)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def parse_date(value) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value).strip()[:10])


def parse_int(value, default=None):
    if value in (None, ""):
        return default
    try:
        return int(value)
    except Exception:
        return default


def parse_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "да", "истина", "on"}


def calc_status(days_left: int) -> str:
    if days_left < 0:
        return "expired"
    if days_left <= 7:
        return "urgent"
    if days_left <= 30:
        return "critical"
    if days_left <= 60:
        return "warning"
    return "active"


def update_status(item) -> None:
    item.status = calc_status(item.days_left(date.today()))


def log_change(db: Session, section: str, record_id: int | None, action: str, description: str, actor: str = "web") -> None:
    db.add(ChangeLog(section=section, record_id=record_id, action=action, description=description, actor=actor))


def hardware_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None):
    query = db.query(HardwareSupport)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            HardwareSupport.dzo.ilike(pattern), HardwareSupport.serial_number.ilike(pattern),
            HardwareSupport.equipment_model.ilike(pattern), HardwareSupport.contract_number.ilike(pattern),
            HardwareSupport.contractor.ilike(pattern), HardwareSupport.responsible.ilike(pattern),
            HardwareSupport.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(HardwareSupport.status == status)
    if responsible:
        query = query.filter(HardwareSupport.responsible == responsible)
    items = query.order_by(HardwareSupport.support_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def software_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None):
    query = db.query(SoftwareLicense)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            SoftwareLicense.code.ilike(pattern), SoftwareLicense.certificate_number.ilike(pattern),
            SoftwareLicense.contract_number.ilike(pattern), SoftwareLicense.contractor.ilike(pattern),
            SoftwareLicense.responsible.ilike(pattern), SoftwareLicense.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(SoftwareLicense.status == status)
    if responsible:
        query = query.filter(SoftwareLicense.responsible == responsible)
    items = query.order_by(SoftwareLicense.cert_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def stats_for(items):
    today = date.today()
    return {
        "total": len(items),
        "expired": sum(1 for x in items if x.days_left(today) < 0),
        "urgent": sum(1 for x in items if 0 <= x.days_left(today) <= 7),
        "critical": sum(1 for x in items if 8 <= x.days_left(today) <= 30),
        "warning": sum(1 for x in items if 31 <= x.days_left(today) <= 60),
    }


def distinct_responsibles(db: Session, model):
    values = db.query(model.responsible).distinct().order_by(model.responsible).all()
    return [x[0] for x in values if x[0]]


@app.get("/", response_class=HTMLResponse)
def index(request: Request, section: str = "hardware", q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    if section not in {"hardware", "software"}:
        section = "hardware"
    hw_all = hardware_query(db)
    sw_all = software_query(db)
    items = hardware_query(db, q, status, responsible) if section == "hardware" else software_query(db, q, status, responsible)
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "app_name": settings.app_name,
            "section": section,
            "items": items,
            "today": date.today(),
            "stats": stats_for(hw_all if section == "hardware" else sw_all),
            "global_stats": {"hardware": stats_for(hw_all), "software": stats_for(sw_all)},
            "selected": {"q": q or "", "status": status or "", "responsible": responsible or ""},
            "responsibles": distinct_responsibles(db, HardwareSupport if section == "hardware" else SoftwareLicense),
            "statuses": ["active", "warning", "critical", "urgent", "expired"],
        },
    )


@app.post("/hardware")
def create_hardware(
    dzo: str = Form("-"), serial_number: str = Form("-"), equipment_model: str = Form("-"), delivery_year: str | None = Form(None),
    support_end_date: str = Form(...), purchase_period: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), auto_renewal: bool = Form(False),
    comment: str | None = Form(None), db: Session = Depends(get_db),
):
    end = parse_date(support_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания ТП обязательна")
    item = HardwareSupport(
        dzo=dzo or "-", serial_number=serial_number or "-", equipment_model=equipment_model or "-", delivery_year=parse_int(delivery_year),
        support_end_date=end, purchase_period=purchase_period or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None, auto_renewal=auto_renewal, comment=comment or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "hardware", item.id, "create", f"Добавлена ТП оборудования: {item.equipment_model} / {item.serial_number}")
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software")
def create_software(
    code: str = Form("-"), quantity: int = Form(1), cert_start_date: str | None = Form(None), cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None), comment: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), db: Session = Depends(get_db),
):
    end = parse_date(cert_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания сертификата обязательна")
    item = SoftwareLicense(
        code=code or "-", quantity=quantity or 1, cert_start_date=parse_date(cert_start_date), cert_end_date=end,
        certificate_number=certificate_number or None, comment=comment or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "software", item.id, "create", f"Добавлена лицензия ПО: {item.code}")
    db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.post("/hardware/{item_id}/delete")
def delete_hardware(item_id: int, db: Session = Depends(get_db)):
    item = db.get(HardwareSupport, item_id)
    if item:
        log_change(db, "hardware", item.id, "delete", f"Удалена ТП оборудования: {item.equipment_model} / {item.serial_number}")
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software/{item_id}/delete")
def delete_software(item_id: int, db: Session = Depends(get_db)):
    item = db.get(SoftwareLicense, item_id)
    if item:
        log_change(db, "software", item.id, "delete", f"Удалена лицензия ПО: {item.code}")
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.get("/history", response_class=HTMLResponse)
def history_page(request: Request, db: Session = Depends(get_db)):
    history = db.query(ChangeLog).order_by(ChangeLog.created_at.desc()).limit(200).all()
    return templates.TemplateResponse(request=request, name="history.html", context={"history": history, "app_name": settings.app_name})


def hardware_to_api(item: HardwareSupport) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "hardware",
        "section_name": "Техподдержка оборудования",
        "number": None,
        "dzo": item.dzo,
        "serial_number": item.serial_number,
        "equipment_model": item.equipment_model,
        "delivery_year": item.delivery_year,
        "support_end_date": item.support_end_date,
        "purchase_period": item.purchase_period,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "auto_renewal": item.auto_renewal,
        "comment": item.comment,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def software_to_api(item: SoftwareLicense) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "software",
        "section_name": "Лицензии ПО",
        "number": None,
        "code": item.code,
        "quantity": item.quantity,
        "cert_start_date": item.cert_start_date,
        "cert_end_date": item.cert_end_date,
        "certificate_number": item.certificate_number,
        "comment": item.comment,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def combined_api_items(db: Session, days: int | None = None) -> list[dict]:
    result = []
    for item in hardware_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(hardware_to_api(item))
    for item in software_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(software_to_api(item))
    result.sort(key=lambda x: x.get("days_left", 999999))
    for idx, item in enumerate(result, 1):
        item["number"] = idx
    return result



@app.get("/api/licenses")
def api_all_licenses(section: str | None = None, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    """Совместимый API: возвращает записи обоих разделов или выбранного section=hardware/software."""
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]
    if section == "software":
        return [software_to_api(x) for x in software_query(db, q, status, responsible)]
    return combined_api_items(db)


@app.get("/api/licenses/expiring")
def api_expiring_licenses(days: int = 30, section: str | None = None, db: Session = Depends(get_db)):
    today = date.today()
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db) if x.days_left(today) <= days]
    if section == "software":
        return [software_to_api(x) for x in software_query(db) if x.days_left(today) <= days]
    return combined_api_items(db, days=days)


@app.get("/api/hardware-support")
def api_hardware_support(q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]


@app.get("/api/hardware-support/{item_id}")
def api_hardware_support_item(item_id: int, db: Session = Depends(get_db)):
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    update_status(item)
    db.commit()
    return hardware_to_api(item)


@app.get("/api/software-licenses")
def api_software_licenses(q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    return [software_to_api(x) for x in software_query(db, q, status, responsible)]


@app.get("/api/software-licenses/{item_id}")
def api_software_license_item(item_id: int, db: Session = Depends(get_db)):
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    update_status(item)
    db.commit()
    return software_to_api(item)

@app.get("/api/monitoring/summary")
def api_monitoring_summary(db: Session = Depends(get_db)):
    hw = hardware_query(db)
    sw = software_query(db)
    return {"hardware_support": stats_for(hw), "software_licenses": stats_for(sw)}


@app.get("/metrics", response_class=PlainTextResponse)
def metrics(db: Session = Depends(get_db)):
    hw = stats_for(hardware_query(db))
    sw = stats_for(software_query(db))
    lines = []
    for section, data in {"hardware": hw, "software": sw}.items():
        for key, value in data.items():
            lines.append(f'license_monitor_{key}{{section="{section}"}} {value}')
    return "\n".join(lines) + "\n"


@app.get("/export.xlsx")
def export_xlsx(section: str = "hardware", db: Session = Depends(get_db)):
    wb = Workbook()
    ws = wb.active
    today = date.today()
    if section == "software":
        ws.title = "software_licenses"
        headers = ["№", "Код", "Кол-во", "Дата начала сертификата", "Дата окончания сертификата", "Номер сертификата", "Комментарий", "Номер договора", "Контрагент", "Ответственный", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(software_query(db), 1):
            ws.append([idx, item.code, item.quantity, item.cert_start_date, item.cert_end_date, item.certificate_number, item.comment, item.contract_number, item.contractor, item.responsible, item.days_left(today), item.status])
        filename = f"software_licenses_{today.isoformat()}.xlsx"
    else:
        ws.title = "hardware_support"
        headers = ["№", "ДЗО", "Серийный номер", "Модель оборудования", "Год поставки", "Текущее состояние ТП (дата окончания)", "Срок на который закупается ТП", "Договор", "Контрагент", "Ответственный", "Автопродление", "Комментарий", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(hardware_query(db), 1):
            ws.append([idx, item.dzo, item.serial_number, item.equipment_model, item.delivery_year, item.support_end_date, item.purchase_period, item.contract_number, item.contractor, item.responsible, "да" if item.auto_renewal else "нет", item.comment, item.days_left(today), item.status])
        filename = f"hardware_support_{today.isoformat()}.xlsx"
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
    for column_cells in ws.columns:
        length = max(len(str(cell.value or "")) for cell in column_cells)
        ws.column_dimensions[get_column_letter(column_cells[0].column)].width = min(max(length + 2, 12), 45)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/import.xlsx")
async def import_xlsx(section: str = Form("hardware"), file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Upload .xlsx file")
    wb = load_workbook(BytesIO(await file.read()), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return RedirectResponse(url=f"/?section={section}", status_code=303)
    headers = [str(x).strip() if x is not None else "" for x in rows[0]]
    index = {name: i for i, name in enumerate(headers)}

    def val(row, name, default=None):
        i = index.get(name)
        return row[i] if i is not None and i < len(row) else default

    imported = 0
    for row in rows[1:]:
        if not row or not any(row):
            continue
        try:
            if section == "software":
                end = parse_date(val(row, "Дата окончания сертификата"))
                if not end:
                    continue
                item = SoftwareLicense(
                    code=str(val(row, "Код", "-") or "-").strip(), quantity=parse_int(val(row, "Кол-во"), 1) or 1,
                    cert_start_date=parse_date(val(row, "Дата начала сертификата")), cert_end_date=end,
                    certificate_number=str(val(row, "Номер сертификата") or "").strip() or None,
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                    contract_number=str(val(row, "Номер договора") or "").strip() or None,
                    contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str(val(row, "Ответственный") or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
            else:
                end = parse_date(val(row, "Текущее состояние ТП (дата окончания)"))
                if not end:
                    continue
                item = HardwareSupport(
                    dzo=str(val(row, "ДЗО", "-") or "-").strip(), serial_number=str(val(row, "Серийный номер", "-") or "-").strip(),
                    equipment_model=str(val(row, "Модель оборудования", "-") or "-").strip(), delivery_year=parse_int(val(row, "Год поставки")),
                    support_end_date=end, purchase_period=str(val(row, "Срок на который закупается ТП") or "").strip() or None,
                    contract_number=str(val(row, "Договор") or "").strip() or None, contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str(val(row, "Ответственный") or "").strip() or None, auto_renewal=parse_bool(val(row, "Автопродление")),
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
        except Exception:
            continue
    log_change(db, section, None, "import", f"Импортировано строк из Excel: {imported}", actor="excel")
    db.commit()
    return RedirectResponse(url=f"/?section={section}", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}
