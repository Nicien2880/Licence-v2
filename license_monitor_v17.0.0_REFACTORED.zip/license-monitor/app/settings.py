from __future__ import annotations

import secrets
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

from .core.status import Thresholds

# Значения, с которыми запускать прод нельзя ни при каких условиях.
INSECURE_SECRETS = {
    "",
    "change-me-session-secret",
    "change-this-to-long-random-string",
    "changeme",
    "secret",
}
INSECURE_PASSWORDS = {"", "ChangeMe123!", "admin", "password", "123456"}
MIN_SECRET_LENGTH = 32


class ConfigurationError(RuntimeError):
    """Конфигурация небезопасна или противоречива — приложение не должно стартовать."""


class Settings(BaseSettings):
    app_name: str = "License Monitor"
    host: str = "0.0.0.0"
    port: int = 8000
    database_url: str = "sqlite:///./data/licenses.db"
    backup_dir: str = "./data/backups"

    # Пороги статусов, дни
    warning_days: int = 60
    critical_days: int = 30
    urgent_days: int = 7

    # Периодичность фонового пересчёта статусов, минуты. 0 — выключить.
    status_refresh_minutes: int = 60

    # Авторизация веб-интерфейса
    auth_enabled: bool = True
    session_secret: str = ""
    session_ttl_hours: int = 12
    cookie_secure: bool = False  # включать при работе через HTTPS
    initial_admin_username: str = "admin"
    initial_admin_password: str = ""
    initial_admin_email: str = "admin@company.local"

    # Защита формы входа от перебора
    login_max_attempts: int = 10
    login_lockout_minutes: int = 15

    # Защита от CSRF: проверка заголовка Origin/Referer для небезопасных методов.
    csrf_protection: bool = True
    # Домены, с которых разрешены POST-запросы (host[:port]), через запятую.
    # Пусто — принимаются запросы, чей Origin совпадает с Host запроса.
    trusted_origins: str = ""

    # API-ключ для Zabbix/Prometheus. Обязателен, если включена авторизация.
    zabbix_api_key: str = ""
    # Явное разрешение открыть API без ключа (только для изолированного стенда).
    allow_unauthenticated_api: bool = False

    # Ограничения на загружаемые файлы
    max_upload_mb: int = 25

    # Email notifications (используются jobs/notify_email.py)
    license_monitor_url: str = "http://127.0.0.1:8000"
    smtp_host: str = ""
    smtp_port: int = 25
    smtp_from: str = ""
    smtp_to: str = ""
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_starttls: bool = False
    smtp_ssl: bool = False
    smtp_timeout: int = 20

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    @property
    def thresholds(self) -> Thresholds:
        return Thresholds(
            urgent_days=self.urgent_days,
            critical_days=self.critical_days,
            warning_days=self.warning_days,
        )

    @property
    def trusted_origin_hosts(self) -> set[str]:
        return {x.strip().lower() for x in self.trusted_origins.split(",") if x.strip()}

    @property
    def max_upload_bytes(self) -> int:
        return self.max_upload_mb * 1024 * 1024

    def validate_runtime(self) -> list[str]:
        """Проверяет конфигурацию и возвращает список некритичных предупреждений.

        Всё, что даёт полный обход авторизации, поднимает ConfigurationError:
        падать на старте лучше, чем месяцами работать с дефолтным секретом,
        которым любой желающий подпишет себе сессию администратора.
        """
        errors: list[str] = []
        warnings: list[str] = []

        # Пороги должны быть согласованы — иначе статусы считаются бессмысленно.
        try:
            self.thresholds
        except ValueError as exc:
            errors.append(str(exc))

        if self.auth_enabled:
            if self.session_secret.strip().lower() in INSECURE_SECRETS:
                errors.append(
                    "SESSION_SECRET не задан или содержит значение по умолчанию. "
                    f"Сгенерируйте: python3 -c \"import secrets;print(secrets.token_urlsafe(48))\" "
                    f"(нужно минимум {MIN_SECRET_LENGTH} символов)."
                )
            elif len(self.session_secret) < MIN_SECRET_LENGTH:
                errors.append(
                    f"SESSION_SECRET короче {MIN_SECRET_LENGTH} символов — подпись сессии подбирается."
                )
            if self.initial_admin_password in INSECURE_PASSWORDS:
                errors.append(
                    "INITIAL_ADMIN_PASSWORD не задан или совпадает с известным значением по умолчанию."
                )
            if not self.zabbix_api_key and not self.allow_unauthenticated_api:
                errors.append(
                    "ZABBIX_API_KEY пуст: /api/* и /metrics отдавали бы всю базу без аутентификации. "
                    "Задайте ключ или явно выставьте ALLOW_UNAUTHENTICATED_API=true для закрытого стенда."
                )
            if not self.cookie_secure:
                warnings.append(
                    "COOKIE_SECURE=false: cookie сессии уйдёт по HTTP. "
                    "Включите после настройки TLS на nginx."
                )
        else:
            warnings.append(
                "AUTH_ENABLED=false: интерфейс и API открыты всем, кто дотянется до порта."
            )

        if self.allow_unauthenticated_api and self.zabbix_api_key:
            warnings.append(
                "ALLOW_UNAUTHENTICATED_API=true при заданном ZABBIX_API_KEY — ключ всё равно требуется."
            )

        if errors:
            raise ConfigurationError(
                "Небезопасная конфигурация:\n  - " + "\n  - ".join(errors)
            )
        return warnings


def generate_secret() -> str:
    return secrets.token_urlsafe(48)


@lru_cache
def get_settings() -> Settings:
    return Settings()
