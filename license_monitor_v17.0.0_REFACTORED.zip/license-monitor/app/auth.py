from __future__ import annotations

import base64
import hashlib
import hmac
import os
import threading
import time

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from .core.parsing import utcnow
from .database import get_db
from .models import User
from .settings import get_settings

ROLE_LEVEL = {"viewer": 10, "editor": 20, "manager": 30, "admin": 40}

ROLE_LABELS = {
    "viewer": "Просмотр",
    "editor": "Редактор",
    "manager": "Менеджер",
    "admin": "Администратор",
}

SESSION_COOKIE = "license_monitor_session"
PBKDF2_ITERATIONS = 240_000


# --------------------------------------------------------------------------- #
# Пароли
# --------------------------------------------------------------------------- #

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return "$".join([
        "pbkdf2_sha256",
        str(PBKDF2_ITERATIONS),
        base64.urlsafe_b64encode(salt).decode(),
        base64.urlsafe_b64encode(digest).decode(),
    ])


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, iterations, salt_b64, digest_b64 = stored_hash.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(digest_b64.encode())
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def validate_password_strength(password: str) -> None:
    """Минимальные требования. Без них admin может завести пользователя с паролем «1»."""
    problems = []
    if len(password) < 10:
        problems.append("минимум 10 символов")
    if password.isdigit() or password.isalpha():
        problems.append("должен содержать и буквы, и цифры")
    if password.lower() in {"password", "qwerty123", "changeme123!", "admin12345"}:
        problems.append("слишком распространённый пароль")
    if problems:
        raise HTTPException(status_code=400, detail="Пароль не подходит: " + ", ".join(problems))


# --------------------------------------------------------------------------- #
# Сессии
# --------------------------------------------------------------------------- #

def _sign(payload: str) -> str:
    secret = get_settings().session_secret.encode("utf-8")
    return hmac.new(secret, payload.encode("utf-8"), hashlib.sha256).hexdigest()


def create_session_token(user_id: int, session_version: int) -> str:
    """Токен вида user_id:session_version:issued_at:HMAC.

    session_version входит в подпись: инкремент при смене пароля или роли делает
    все ранее выданные токены недействительными, чего в прежней схеме не было —
    там угнанная cookie жила до истечения TTL несмотря на смену пароля.
    """
    payload = f"{user_id}:{session_version}:{int(time.time())}"
    token = f"{payload}:{_sign(payload)}"
    return base64.urlsafe_b64encode(token.encode("utf-8")).decode("utf-8")


def read_session_token(token: str | None) -> tuple[int, int] | None:
    """Возвращает (user_id, session_version) либо None."""
    if not token:
        return None
    settings = get_settings()
    try:
        decoded = base64.urlsafe_b64decode(token.encode("utf-8")).decode("utf-8")
        user_id_str, version_str, created_str, signature = decoded.split(":", 3)
        payload = f"{user_id_str}:{version_str}:{created_str}"
        if not hmac.compare_digest(signature, _sign(payload)):
            return None
        age = int(time.time()) - int(created_str)
        if age > settings.session_ttl_hours * 3600 or age < -300:
            return None
        return int(user_id_str), int(version_str)
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# Защита формы входа от перебора
# --------------------------------------------------------------------------- #

class LoginThrottle:
    """Счётчик неудачных попыток входа в памяти процесса.

    Осознанное ограничение: состояние не переживает рестарт и не разделяется
    между воркерами, поэтому приложение запускается в один воркер. Для
    нескольких инстансов счётчик нужно вынести в Redis.
    """

    def __init__(self) -> None:
        self._attempts: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def _prune(self, key: str, window: float, now: float) -> list[float]:
        kept = [ts for ts in self._attempts.get(key, []) if now - ts < window]
        if kept:
            self._attempts[key] = kept
        else:
            self._attempts.pop(key, None)
        return kept

    def is_locked(self, key: str) -> bool:
        settings = get_settings()
        window = settings.login_lockout_minutes * 60
        with self._lock:
            return len(self._prune(key, window, time.time())) >= settings.login_max_attempts

    def register_failure(self, key: str) -> None:
        settings = get_settings()
        window = settings.login_lockout_minutes * 60
        now = time.time()
        with self._lock:
            self._prune(key, window, now)
            self._attempts.setdefault(key, []).append(now)

    def reset(self, key: str) -> None:
        with self._lock:
            self._attempts.pop(key, None)


login_throttle = LoginThrottle()


def throttle_key(request: Request, username: str) -> str:
    client = request.client.host if request.client else "unknown"
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        client = forwarded.split(",")[0].strip()
    return f"{client}|{username.lower()}"


# --------------------------------------------------------------------------- #
# Первичный администратор
# --------------------------------------------------------------------------- #

def create_initial_admin_if_needed(db: Session) -> bool:
    settings = get_settings()
    if not settings.auth_enabled or db.query(User).count() > 0:
        return False
    db.add(User(
        username=settings.initial_admin_username,
        password_hash=hash_password(settings.initial_admin_password),
        full_name="Initial Admin",
        email=settings.initial_admin_email,
        role="admin",
        is_active=True,
        session_version=1,
    ))
    db.commit()
    return True


# --------------------------------------------------------------------------- #
# Зависимости FastAPI
# --------------------------------------------------------------------------- #

def _system_user() -> User:
    """Псевдопользователь для режима AUTH_ENABLED=false."""
    return User(id=0, username="system", password_hash="", role="admin",
                is_active=True, session_version=1)


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    settings = get_settings()
    if not settings.auth_enabled:
        return _system_user()
    parsed = read_session_token(request.cookies.get(SESSION_COOKIE))
    if parsed is None:
        return None
    user_id, session_version = parsed
    user = db.get(User, user_id)
    if user is None or not user.is_active or user.session_version != session_version:
        return None
    return user


def require_login(request: Request, db: Session = Depends(get_db)) -> User:
    user = get_current_user(request, db)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"X-Login-Required": "1"},
        )
    return user


def require_role(*allowed_roles: str):
    """Проверяет, что уровень роли пользователя не ниже минимального из указанных."""
    unknown = [role for role in allowed_roles if role not in ROLE_LEVEL]
    if unknown:
        raise ValueError(f"Неизвестные роли в require_role: {unknown}")
    required_level = min(ROLE_LEVEL[role] for role in allowed_roles)

    def checker(user: User = Depends(require_login)) -> User:
        if ROLE_LEVEL.get(user.role, 0) < required_level:
            raise HTTPException(status_code=403, detail="Недостаточно прав для этой операции")
        return user

    return checker


def user_can(user: User | None, role: str) -> bool:
    if user is None:
        return False
    return ROLE_LEVEL.get(user.role, 0) >= ROLE_LEVEL.get(role, 999)


def require_api_key(request: Request) -> None:
    """Аутентификация машинных клиентов (Zabbix, Prometheus).

    Fail-closed: раньше пустой ключ означал «API открыт всем», причём пустая
    строка была значением по умолчанию. Теперь открыть API без ключа можно
    только явным ALLOW_UNAUTHENTICATED_API=true.
    """
    settings = get_settings()
    key = settings.zabbix_api_key
    if not key:
        if settings.allow_unauthenticated_api or not settings.auth_enabled:
            return
        raise HTTPException(status_code=503, detail="API key is not configured on the server")
    provided = request.headers.get("X-API-Key") or request.query_params.get("api_key")
    if not provided or not hmac.compare_digest(provided, key):
        raise HTTPException(status_code=401, detail="Invalid API key")


def touch_session_version(user: User) -> None:
    """Отзывает все активные сессии пользователя."""
    user.session_version = (user.session_version or 1) + 1
    user.updated_at = utcnow()
