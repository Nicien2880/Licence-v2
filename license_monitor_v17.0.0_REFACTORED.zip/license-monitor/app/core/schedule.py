"""Разбор текстового поля «Периодичность проведения процедуры».

Единственный по-настоящему нетривиальный алгоритм в проекте: превращает
свободный русско-английский текст регламента в структурированную аналитику
(дни недели, часы запуска, тип копии, heatmap «день x час»).

Модуль не зависит от SQLAlchemy: на вход принимает любые объекты с полями
id / row_number / system_name / backup_type / procedure_frequency,
что делает его тестируемым напрямую.
"""
from __future__ import annotations

import re
from typing import Iterable

DP_TYPE_LABELS = {
    "filesystem": "Filesystem",
    "internal_database": "Internal Database",
    "ms_sql_server": "MS SQL Server",
    "virtual_environment": "Virtual Environment",
}

DP_TYPE_ALIASES = {
    "mssql": "ms_sql_server",
    "ms_sql": "ms_sql_server",
    "sql_server": "ms_sql_server",
    "sqlserver": "ms_sql_server",
    "virtual": "virtual_environment",
    "vm": "virtual_environment",
    "vmware": "virtual_environment",
    "internal_db": "internal_database",
    "database": "internal_database",
    "db": "internal_database",
    "fs": "filesystem",
    "file_system": "filesystem",
}

DAY_ALIASES: dict[str, tuple[str, list[str]]] = {
    "mon": ("Пн", ["понедельник", "понедельникам", "понедельниками", "пн", "monday", "mon"]),
    "tue": ("Вт", ["вторник", "вторникам", "вторниками", "вт", "tuesday", "tue"]),
    "wed": ("Ср", ["среда", "среду", "средам", "средами", "ср", "wednesday", "wed"]),
    "thu": ("Чт", ["четверг", "четвергам", "четвергами", "чт", "thursday", "thu"]),
    "fri": ("Пт", ["пятница", "пятницу", "пятницам", "пятницами", "пт", "friday", "fri"]),
    "sat": ("Сб", ["суббота", "субботу", "субботам", "субботами", "сб", "saturday", "sat"]),
    "sun": ("Вс", ["воскресенье", "воскресеньям", "воскресеньями", "вс", "sunday", "sun"]),
}

FULL_MARKERS = ["full", "полный", "полная", "полное"]
INCREMENTAL_MARKERS = ["incr", "increment", "incremental", "инкрем", "инкремент"]
DIFFERENTIAL_MARKERS = ["diff", "differential", "differ", "дифф", "дифференц", "разностн"]

HOUR_RE = re.compile(r"\b((?:0?\d|1\d|2[0-3])[:.][0-5]\d)\s*(am|pm|a\.m\.|p\.m\.)?\b")
MULTIWEEK_RE = re.compile(r"(каждые|кажд[а-я]+|раз в)\s+[234]\s+недел")


def normalize_backup_type(value: str | None) -> str:
    value = str(value or "filesystem").strip().lower().replace(" ", "_").replace("-", "_")
    if value in DP_TYPE_LABELS:
        return value
    return DP_TYPE_ALIASES.get(value, "filesystem")


def normalize_text(value: str | None) -> str:
    """Приводит текст к виду, пригодному для поиска подстрок."""
    return (value or "").lower().replace("ё", "е").replace("—", "-").replace("–", "-")


def has_any(text: str, values: Iterable[str]) -> bool:
    return any(x in text for x in values)


def extract_hours(text: str) -> list[int]:
    """Достаёт часы запуска: 02:00, 2.00, 8:00 PM, 1:09 AM."""
    result: list[int] = []
    for value, ampm in HOUR_RE.findall(text):
        hour_str, _minutes = value.replace(".", ":").split(":")
        hour = int(hour_str)
        ampm = (ampm or "").replace(".", "")
        if ampm == "pm" and hour < 12:
            hour += 12
        if ampm == "am" and hour == 12:
            hour = 0
        result.append(hour)
    return result


def detect_modes(text: str) -> dict[str, bool]:
    return {
        "full": has_any(text, FULL_MARKERS),
        "incremental": has_any(text, INCREMENTAL_MARKERS),
        "differential": has_any(text, DIFFERENTIAL_MARKERS),
    }


def detect_cadence(text: str) -> str:
    """Возвращает один из ключей: multi_daily / daily / weekly / monthly / unknown."""
    is_every_other_day = has_any(text, ["через день", "every other day"])
    is_daily_like = is_every_other_day or has_any(
        text, ["ежеднев", "каждый день", "daily", "раз в день"]
    )
    if has_any(text, ["2 раза в день", "два раза в день", "несколько раз в день"]):
        return "multi_daily"
    if is_daily_like:
        return "daily"
    if bool(MULTIWEEK_RE.search(text)) or has_any(
        text, ["еженед", "раз в неделю", "weekly", "каждую неделю"]
    ):
        return "weekly"
    if has_any(text, ["ежемесяч", "раз в месяц", "monthly", "каждый месяц"]):
        return "monthly"
    return "unknown"


def detect_days(text: str) -> list[str]:
    return [
        key
        for key, (_label, aliases) in DAY_ALIASES.items()
        if any(alias in text for alias in aliases)
    ]


def heat_bucket(count: int) -> str:
    if count == 0:
        return "empty"
    if count <= 5:
        return "low"
    if count <= 10:
        return "medium"
    if count <= 20:
        return "high"
    return "peak"


def _unparsed_entry(item, raw: str, reason: str) -> dict:
    backup_type = getattr(item, "backup_type", None)
    return {
        "id": getattr(item, "id", None),
        "row_number": getattr(item, "row_number", None),
        "system_name": getattr(item, "system_name", None),
        "backup_type": backup_type,
        "backup_type_label": DP_TYPE_LABELS.get(backup_type, backup_type),
        "procedure_frequency": raw,
        "reason": reason,
    }


def schedule_stats(items) -> dict:
    """Строит аналитику расписаний: дни, каденс, типы копий, часы и heatmap."""
    day_rows = {
        key: {"key": key, "label": label, "total": 0, "full": 0, "incremental": 0,
              "differential": 0, "other": 0}
        for key, (label, _aliases) in DAY_ALIASES.items()
    }
    cadence = {
        "multi_daily": {"label": "Несколько раз в день", "count": 0},
        "daily": {"label": "Ежедневно / через день", "count": 0},
        "weekly": {"label": "Еженедельно / каждые N недель", "count": 0},
        "monthly": {"label": "Ежемесячно", "count": 0},
        "unknown": {"label": "Не распознано", "count": 0},
    }
    modes = {
        "full": {"label": "Full", "count": 0},
        "incremental": {"label": "Incremental", "count": 0},
        "differential": {"label": "Differential", "count": 0},
        "other": {"label": "Прочее", "count": 0},
    }
    hour_rows = {h: {"hour": f"{h:02d}:00", "count": 0} for h in range(24)}
    heatmap_matrix = {day: dict.fromkeys(range(24), 0) for day in DAY_ALIASES}
    unparsed: list[dict] = []

    for item in items:
        raw = getattr(item, "procedure_frequency", None) or ""
        text = normalize_text(raw)

        if not text.strip():
            cadence["unknown"]["count"] += 1
            modes["other"]["count"] += 1
            unparsed.append(_unparsed_entry(item, raw, "пустое поле периодичности"))
            continue

        reasons: list[str] = []
        found = detect_modes(text)

        for key in ("full", "incremental", "differential"):
            if found[key]:
                modes[key]["count"] += 1
        if not any(found.values()):
            modes["other"]["count"] += 1
            reasons.append("не найден тип Full/Incr/Diff")

        cadence_key = detect_cadence(text)
        cadence[cadence_key]["count"] += 1
        if cadence_key == "unknown":
            reasons.append("не распознана периодичность")
        is_daily_like = cadence_key in {"daily", "multi_daily"}

        matched_days = detect_days(text)
        heatmap_days = matched_days or (list(DAY_ALIASES) if is_daily_like else [])
        if not matched_days and not is_daily_like:
            reasons.append("не найден день недели")

        for key in matched_days:
            day_rows[key]["total"] += 1
            for mode_key in ("full", "incremental", "differential"):
                if found[mode_key]:
                    day_rows[key][mode_key] += 1
            if not any(found.values()):
                day_rows[key]["other"] += 1

        hours = extract_hours(text)
        if not hours:
            reasons.append("не найдено время запуска")

        for hour in hours:
            hour_rows[hour]["count"] += 1
            for day_key in heatmap_days:
                heatmap_matrix[day_key][hour] += 1

        if reasons:
            unparsed.append(_unparsed_entry(item, raw, "; ".join(dict.fromkeys(reasons))))

    max_day = max([row["total"] for row in day_rows.values()] + [1])
    max_hour = max([row["count"] for row in hour_rows.values()] + [1])
    max_heat = max([v for day in heatmap_matrix.values() for v in day.values()] + [1])

    for row in day_rows.values():
        row["percent"] = round(row["total"] / max_day * 100, 1)
    for row in hour_rows.values():
        row["percent"] = round(row["count"] / max_hour * 100, 1)

    peak = {"label": "—", "hour": "—", "count": 0}
    heatmap = {"hours": [f"{h:02d}" for h in range(24)], "max": max_heat, "rows": [], "peak": peak}
    for key, (label, _aliases) in DAY_ALIASES.items():
        cells = []
        for hour in range(24):
            count = heatmap_matrix[key][hour]
            if count > peak["count"]:
                peak.update({"label": label, "hour": f"{hour:02d}:00", "count": count})
            cells.append({
                "hour": f"{hour:02d}:00",
                "count": count,
                "level": round(count / max_heat * 100, 1),
                "bucket": heat_bucket(count),
            })
        heatmap["rows"].append({"key": key, "label": label, "cells": cells})

    return {
        "days": list(day_rows.values()),
        "cadence": list(cadence.values()),
        "modes": list(modes.values()),
        "hours": [row for row in hour_rows.values() if row["count"] > 0],
        "heatmap": heatmap,
        "unparsed": unparsed,
        "unparsed_count": len(unparsed),
    }
