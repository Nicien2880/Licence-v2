"""Парсинг и нормализация входных значений.

Модуль намеренно не зависит ни от FastAPI, ни от SQLAlchemy:
это позволяет покрывать его юнит-тестами без поднятия приложения.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timezone

TRUE_VALUES = {"1", "true", "yes", "y", "on", "да", "истина"}


def utcnow() -> datetime:
    """Текущее время в UTC (timezone-aware).

    datetime.utcnow() объявлен deprecated в Python 3.12 и возвращает naive-объект,
    из-за чего сравнение с aware-датами падает. Используем явный UTC.
    """
    return datetime.now(timezone.utc)


def today_utc() -> date:
    """Сегодняшняя дата в UTC.

    Все сроки в базе хранятся как даты без часового пояса, а расчёт days_left
    раньше смешивал date.today() (локальная TZ) с datetime.utcnow() (UTC),
    что на границе суток давало расхождение в один день.
    """
    return utcnow().date()


def parse_date(value) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        pass
    for fmt in ("%d.%m.%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text[:10], fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Не удалось разобрать дату: {value!r}")


def parse_date_safe(value) -> date | None:
    try:
        return parse_date(value)
    except ValueError:
        return None


def parse_int(value, default=None):
    if value in (None, ""):
        return default
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def parse_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in TRUE_VALUES


def parse_datetime_local(value) -> datetime | None:
    """Разбирает значение из <input type="datetime-local"> (2026-05-22T03:00)."""
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, tzinfo=timezone.utc)
    text = str(value).strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text[:16])
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def format_dt_for_input(value: datetime | None) -> str:
    return value.strftime("%Y-%m-%dT%H:%M") if value else ""


def clean_cell(value) -> str:
    """Схлопывает пробелы и неразрывные пробелы из ячеек Excel/Word."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def normalize_serial(value: str | None) -> str:
    """Каноничный вид серийного номера для проверки уникальности."""
    return re.sub(r"\s+", "", str(value or "")).strip().upper()


def parse_volume_gb(value) -> int | None:
    """Разбирает объём с единицами измерения и приводит к гигабайтам.

    Поддерживает ТБ/TB (x1024) и ГБ/GB. Значения без единиц считаются гигабайтами.
    """
    if value in (None, ""):
        return None
    raw = str(value).strip().lower().replace(",", ".")
    multiplier = 1
    if "pb" in raw or "пб" in raw:
        multiplier = 1024 * 1024
    elif "tb" in raw or "тб" in raw:
        multiplier = 1024
    elif "mb" in raw or "мб" in raw:
        multiplier = 0
    digits = re.sub(r"[^0-9.]", "", raw)
    if not digits or digits == ".":
        return None
    try:
        number = float(digits)
    except ValueError:
        return None
    if multiplier == 0:  # мегабайты округляем до целых ГБ вверх, но не ниже 1
        return max(1, int(round(number / 1024)))
    return int(round(number * multiplier))


def format_volume(value: int | None) -> str:
    if value is None:
        return ""
    if value >= 1024:
        tb = value / 1024
        return f"{tb:.2f} ТБ".replace(".00", "")
    return f"{value} ГБ"
