"""Расчёт статуса записи по числу оставшихся дней.

В старой версии пороги были захардкожены в calc_status (7/30/60), хотя
одновременно существовали настройки URGENT_DAYS/CRITICAL_DAYS/WARNING_DAYS,
которые ни на что не влияли. Здесь они реально используются.
"""
from __future__ import annotations

from dataclasses import dataclass

STATUS_ORDER = ["expired", "urgent", "critical", "warning", "active"]

STATUS_LABELS = {
    "expired": "Просрочено",
    "urgent": "Срочно",
    "critical": "Критично",
    "warning": "Предупреждение",
    "active": "В порядке",
}


@dataclass(frozen=True)
class Thresholds:
    urgent_days: int = 7
    critical_days: int = 30
    warning_days: int = 60

    def __post_init__(self) -> None:
        if not (self.urgent_days <= self.critical_days <= self.warning_days):
            raise ValueError(
                "Пороги должны возрастать: urgent_days <= critical_days <= warning_days, "
                f"получено {self.urgent_days}/{self.critical_days}/{self.warning_days}"
            )


DEFAULT_THRESHOLDS = Thresholds()


def calc_status(days_left: int, thresholds: Thresholds | None = None) -> str:
    t = thresholds or DEFAULT_THRESHOLDS
    if days_left < 0:
        return "expired"
    if days_left <= t.urgent_days:
        return "urgent"
    if days_left <= t.critical_days:
        return "critical"
    if days_left <= t.warning_days:
        return "warning"
    return "active"


def stats_for(items, today, thresholds: Thresholds | None = None) -> dict:
    """Сводка по коллекции записей с методом days_left(today).

    Считает по фактическому days_left, а не по сохранённому полю status,
    чтобы цифры не разъезжались, если статусы в базе устарели.
    """
    t = thresholds or DEFAULT_THRESHOLDS
    counters = {"total": 0, "expired": 0, "urgent": 0, "critical": 0, "warning": 0, "active": 0}
    for item in items:
        counters["total"] += 1
        counters[calc_status(item.days_left(today), t)] += 1
    return counters
