from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .core.parsing import normalize_serial, utcnow
from .database import Base


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow
    )


class HardwareSupport(TimestampMixin, Base):
    __tablename__ = "hardware_support"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    manufacturer: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    dzo: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    serial_number: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    # Каноничная форма серийника: без пробелов, в верхнем регистре.
    # Нужна, чтобы проверять уникальность одним индексированным запросом,
    # а не выгружать всю таблицу в память на каждую вставку.
    serial_normalized: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    equipment_model: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    delivery_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    support_end_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    purchase_period: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contract_number: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    contractor: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    responsible: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    auto_renewal: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="active", index=True)

    def days_left(self, today: date) -> int:
        return (self.support_end_date - today).days

    def sync_serial(self) -> None:
        self.serial_normalized = normalize_serial(self.serial_number) or None


class SoftwareLicense(TimestampMixin, Base):
    __tablename__ = "software_licenses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    group_name: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    cert_start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    cert_end_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    certificate_number: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    contract_number: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    contractor: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    responsible: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="active", index=True)

    def days_left(self, today: date) -> int:
        return (self.cert_end_date - today).days


class BackupObject(TimestampMixin, Base):
    __tablename__ = "backup_objects"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    object_name: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    object_type: Mapped[str] = mapped_column(String(80), nullable=False, default="vm", index=True)
    platform: Mapped[str] = mapped_column(String(120), nullable=False, default="manual", index=True)
    last_backup_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    next_backup_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    size_gb: Mapped[int | None] = mapped_column(Integer, nullable=True)
    storage: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    retention_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    policy_name: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    responsible: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="success", index=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)

    def hours_since_backup(self, now: datetime | None = None) -> int | None:
        if self.last_backup_at is None:
            return None
        now = now or utcnow()
        last = self.last_backup_at
        if last.tzinfo is None:  # значения, записанные до перехода на aware-время
            last = last.replace(tzinfo=now.tzinfo)
        return int((now - last).total_seconds() // 3600)


class DataProtectionPolicy(TimestampMixin, Base):
    __tablename__ = "data_protection_policies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    row_number: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    backup_type: Mapped[str] = mapped_column(String(120), nullable=False, default="filesystem", index=True)
    system_name: Mapped[str] = mapped_column(String(255), nullable=False, default="-", index=True)
    reserved_information: Mapped[str | None] = mapped_column(Text, nullable=True)
    max_volume_gb: Mapped[int | None] = mapped_column(Integer, nullable=True)
    procedure_frequency: Mapped[str | None] = mapped_column(Text, nullable=True)
    retention_period: Mapped[str | None] = mapped_column(String(255), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    responsible_person: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)


class ChangeLog(Base):
    __tablename__ = "change_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    section: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    record_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    actor: Mapped[str] = mapped_column(String(255), nullable=False, default="system")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow, index=True
    )


class User(TimestampMixin, Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(80), nullable=False, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[str] = mapped_column(String(30), nullable=False, default="viewer", index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    # Инкрементируется при смене пароля или роли: все ранее выданные
    # cookie-сессии этого пользователя сразу становятся недействительными.
    session_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
