from __future__ import annotations

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, StreamingResponse
from sqlalchemy.orm import Session

from ..auth import require_login, require_role
from ..core.parsing import parse_date_safe, parse_int, today_utc
from ..database import get_db
from ..deps import base_context, page_user, redirect, templates
from ..models import ChangeLog, HardwareSupport, SoftwareLicense, User
from ..services.common import distinct_responsibles, distinct_values, log_change
from ..services.exporting import (
    HARDWARE_HEADERS,
    SOFTWARE_HEADERS,
    XLSX_MEDIA_TYPE,
    build_workbook,
    hardware_rows,
    software_rows,
)
from ..services.importing import import_hardware_rows, import_software_rows
from ..services.inventory import (
    STATUSES,
    apply_status,
    hardware_query,
    hardware_serial_exists,
    hardware_stats,
    software_query,
    software_stats,
)

router = APIRouter(tags=["inventory"])


# --------------------------------------------------------------------------- #
# Страницы
# --------------------------------------------------------------------------- #

@router.get("/", response_class=HTMLResponse)
def index(
    request: Request,
    section: str = "hardware",
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    if section not in {"hardware", "software"}:
        section = "hardware"

    selected_groups = [g for g in request.query_params.getlist("group") if g]
    selected_manufacturers = [m for m in request.query_params.getlist("manufacturer") if m]

    hw_all = hardware_query(db)
    sw_all = software_query(db)
    items = (
        hardware_query(db, q, status, responsible, selected_manufacturers)
        if section == "hardware"
        else software_query(db, q, status, responsible, selected_groups)
    )

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context=base_context(
            request,
            current_user,
            section=section,
            items=items,
            today=today_utc(),
            stats=hardware_stats(hw_all) if section == "hardware" else software_stats(sw_all),
            global_stats={"hardware": hardware_stats(hw_all), "software": software_stats(sw_all)},
            selected={
                "q": q or "",
                "status": status or "",
                "responsible": responsible or "",
                "groups": selected_groups,
                "manufacturers": selected_manufacturers,
            },
            responsibles=distinct_responsibles(
                db, HardwareSupport if section == "hardware" else SoftwareLicense
            ),
            software_groups=distinct_values(db, SoftwareLicense.group_name),
            hardware_manufacturers=distinct_values(db, HardwareSupport.manufacturer),
            statuses=STATUSES,
        ),
    )


@router.get("/history", response_class=HTMLResponse)
def history_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    history = db.query(ChangeLog).order_by(ChangeLog.created_at.desc()).limit(200).all()
    return templates.TemplateResponse(
        request=request,
        name="history.html",
        context=base_context(request, current_user, history=history),
    )


@router.get("/tools", response_class=HTMLResponse)
def tools_page(request: Request, current_user: User = Depends(page_user)):
    return templates.TemplateResponse(
        request=request, name="tools.html", context=base_context(request, current_user)
    )


# --------------------------------------------------------------------------- #
# Техподдержка оборудования
# --------------------------------------------------------------------------- #

def _require_date(value: str | None, field_label: str):
    parsed = parse_date_safe(value)
    if parsed is None:
        raise HTTPException(status_code=400, detail=f"{field_label}: некорректная или пустая дата")
    return parsed


@router.post("/hardware")
def create_hardware(
    manufacturer: str | None = Form(None),
    dzo: str = Form("-"),
    serial_number: str = Form("-"),
    equipment_model: str = Form("-"),
    delivery_year: str | None = Form(None),
    support_end_date: str = Form(...),
    purchase_period: str | None = Form(None),
    contract_number: str | None = Form(None),
    contractor: str | None = Form(None),
    responsible: str | None = Form(None),
    auto_renewal: bool = Form(False),
    comment: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    end_date = _require_date(support_end_date, "Дата окончания ТП")
    if hardware_serial_exists(db, serial_number):
        raise HTTPException(status_code=400, detail=f"Серийный номер уже существует: {serial_number}")

    item = HardwareSupport(
        manufacturer=manufacturer or None,
        dzo=dzo or "-",
        serial_number=serial_number or "-",
        equipment_model=equipment_model or "-",
        delivery_year=parse_int(delivery_year),
        support_end_date=end_date,
        purchase_period=purchase_period or None,
        contract_number=contract_number or None,
        contractor=contractor or None,
        responsible=responsible or None,
        auto_renewal=auto_renewal,
        comment=comment or None,
    )
    item.sync_serial()
    apply_status(item)
    db.add(item)
    db.flush()
    log_change(db, "hardware", item.id, "create",
               f"Добавлена ТП оборудования: {item.equipment_model} / {item.serial_number}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=hardware")


@router.post("/hardware/{item_id}/update")
def update_hardware(
    item_id: int,
    manufacturer: str | None = Form(None),
    dzo: str = Form("-"),
    serial_number: str = Form("-"),
    equipment_model: str = Form("-"),
    delivery_year: str | None = Form(None),
    support_end_date: str = Form(...),
    purchase_period: str | None = Form(None),
    contract_number: str | None = Form(None),
    contractor: str | None = Form(None),
    responsible: str | None = Form(None),
    auto_renewal: bool = Form(False),
    comment: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Запись техподдержки не найдена")
    end_date = _require_date(support_end_date, "Дата окончания ТП")
    if hardware_serial_exists(db, serial_number, exclude_id=item_id):
        raise HTTPException(status_code=400, detail=f"Серийный номер уже существует: {serial_number}")

    item.manufacturer = manufacturer or None
    item.dzo = dzo or "-"
    item.serial_number = serial_number or "-"
    item.equipment_model = equipment_model or "-"
    item.delivery_year = parse_int(delivery_year)
    item.support_end_date = end_date
    item.purchase_period = purchase_period or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    item.auto_renewal = auto_renewal
    item.comment = comment or None
    item.sync_serial()
    apply_status(item)
    log_change(db, "hardware", item.id, "update",
               f"Обновлена ТП оборудования: {item.equipment_model} / {item.serial_number}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=hardware")


@router.post("/hardware/{item_id}/delete")
def delete_hardware(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    item = db.get(HardwareSupport, item_id)
    if item:
        log_change(db, "hardware", item.id, "delete",
                   f"Удалена ТП оборудования: {item.equipment_model} / {item.serial_number}",
                   actor=current_user.username)
        db.delete(item)
        db.commit()
    return redirect("/?section=hardware")


@router.post("/hardware/clear")
def clear_hardware(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    deleted = db.query(HardwareSupport).delete(synchronize_session=False)
    log_change(db, "hardware", None, "clear",
               f"Очищена таблица техподдержки оборудования. Удалено записей: {deleted}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=hardware")


# --------------------------------------------------------------------------- #
# Лицензии ПО
# --------------------------------------------------------------------------- #

@router.post("/software")
def create_software(
    group_name: str | None = Form(None),
    location: str | None = Form(None),
    code: str = Form("-"),
    quantity: int = Form(1),
    cert_start_date: str | None = Form(None),
    cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None),
    comment: str | None = Form(None),
    contract_number: str | None = Form(None),
    contractor: str | None = Form(None),
    responsible: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    end_date = _require_date(cert_end_date, "Дата окончания сертификата")
    item = SoftwareLicense(
        group_name=group_name or None,
        location=location or None,
        code=code or "-",
        quantity=quantity or 1,
        cert_start_date=parse_date_safe(cert_start_date),
        cert_end_date=end_date,
        certificate_number=certificate_number or None,
        comment=comment or None,
        contract_number=contract_number or None,
        contractor=contractor or None,
        responsible=responsible or None,
    )
    apply_status(item)
    db.add(item)
    db.flush()
    log_change(db, "software", item.id, "create", f"Добавлена лицензия ПО: {item.code}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=software")


@router.post("/software/{item_id}/update")
def update_software(
    item_id: int,
    group_name: str | None = Form(None),
    location: str | None = Form(None),
    code: str = Form("-"),
    quantity: int = Form(1),
    cert_start_date: str | None = Form(None),
    cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None),
    comment: str | None = Form(None),
    contract_number: str | None = Form(None),
    contractor: str | None = Form(None),
    responsible: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Лицензия не найдена")
    end_date = _require_date(cert_end_date, "Дата окончания сертификата")

    item.group_name = group_name or None
    item.location = location or None
    item.code = code or "-"
    item.quantity = quantity or 1
    item.cert_start_date = parse_date_safe(cert_start_date)
    item.cert_end_date = end_date
    item.certificate_number = certificate_number or None
    item.comment = comment or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    apply_status(item)
    log_change(db, "software", item.id, "update", f"Обновлена лицензия ПО: {item.code}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=software")


@router.post("/software/{item_id}/delete")
def delete_software(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    item = db.get(SoftwareLicense, item_id)
    if item:
        log_change(db, "software", item.id, "delete", f"Удалена лицензия ПО: {item.code}",
                   actor=current_user.username)
        db.delete(item)
        db.commit()
    return redirect("/?section=software")


@router.post("/software/clear")
def clear_software(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    deleted = db.query(SoftwareLicense).delete(synchronize_session=False)
    log_change(db, "software", None, "clear",
               f"Очищена таблица лицензий ПО. Удалено записей: {deleted}",
               actor=current_user.username)
    db.commit()
    return redirect("/?section=software")


# --------------------------------------------------------------------------- #
# Экспорт и импорт
# --------------------------------------------------------------------------- #

@router.get("/export.xlsx")
def export_xlsx(
    section: str = "hardware",
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    today = today_utc()
    if section == "software":
        buffer = build_workbook(
            "software_licenses", SOFTWARE_HEADERS, software_rows(software_query(db), today)
        )
        filename = f"software_licenses_{today.isoformat()}.xlsx"
    else:
        buffer = build_workbook(
            "hardware_support", HARDWARE_HEADERS, hardware_rows(hardware_query(db), today)
        )
        filename = f"hardware_support_{today.isoformat()}.xlsx"
    return StreamingResponse(
        buffer,
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/import.xlsx")
async def import_xlsx(
    request: Request,
    section: str = Form("hardware"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    filename = (file.filename or "").lower()
    if not filename.endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Загрузите файл .xlsx или .xlsm")

    payload = await file.read()
    if section == "software":
        result = import_software_rows(db, payload)
    else:
        section = "hardware"
        result = import_hardware_rows(db, payload)

    log_change(db, section, None, "import",
               f"Импорт из Excel «{file.filename}»: {result.summary()}",
               actor=current_user.username)
    db.commit()

    # Отчёт вместо молчаливого редиректа: раньше ошибочные строки исчезали без следа.
    return templates.TemplateResponse(
        request=request,
        name="import_report.html",
        context=base_context(
            request,
            current_user,
            section=section,
            source_filename=file.filename,
            result=result,
            back_url=f"/?section={section}",
        ),
        status_code=200,
    )
