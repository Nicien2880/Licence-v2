from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from sqlalchemy.orm import Session

from ..auth import (
    ROLE_LABELS,
    hash_password,
    require_role,
    touch_session_version,
    validate_password_strength,
)
from ..database import get_db
from ..deps import base_context, redirect, templates
from ..models import User
from ..services.common import log_change
from ..services.db_backup import (
    BackupError,
    BackupNotFound,
    create_sqlite_backup,
    get_backup_dir,
    get_sqlite_db_path,
    list_db_backups,
    resolve_backup_path,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


# --------------------------------------------------------------------------- #
# Пользователи
# --------------------------------------------------------------------------- #

@router.get("/users", response_class=HTMLResponse)
def users_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    users = db.query(User).order_by(User.username).all()
    return templates.TemplateResponse(
        request=request,
        name="users.html",
        context=base_context(request, current_user, users=users, roles=ROLE_LABELS),
    )


@router.post("/users")
def create_user(
    username: str = Form(...),
    password: str = Form(...),
    full_name: str | None = Form(None),
    email: str | None = Form(None),
    role: str = Form("viewer"),
    is_active: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    username = username.strip()
    if not username:
        raise HTTPException(status_code=400, detail="Имя пользователя обязательно")
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Недопустимая роль")
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(status_code=400, detail="Пользователь с таким именем уже существует")
    validate_password_strength(password)

    db.add(User(
        username=username,
        password_hash=hash_password(password),
        full_name=(full_name or "").strip() or None,
        email=(email or "").strip() or None,
        role=role,
        is_active=is_active,
        session_version=1,
    ))
    log_change(db, "system", None, "user_create", f"Создан пользователь {username} ({role})",
               actor=current_user.username)
    db.commit()
    return redirect("/admin/users")


@router.post("/users/{user_id}/update")
def update_user(
    user_id: int,
    full_name: str | None = Form(None),
    email: str | None = Form(None),
    role: str = Form("viewer"),
    is_active: bool = Form(False),
    password: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Недопустимая роль")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    # Защита от блокировки самого себя и от исчезновения последнего администратора.
    if user.id == current_user.id and (not is_active or role != "admin"):
        raise HTTPException(
            status_code=400,
            detail="Нельзя снять с себя роль администратора или деактивировать свою учётную запись",
        )
    if user.role == "admin" and role != "admin":
        remaining = db.query(User).filter(
            User.role == "admin", User.is_active.is_(True), User.id != user.id
        ).count()
        if remaining == 0:
            raise HTTPException(status_code=400, detail="Это последний активный администратор")

    role_changed = user.role != role
    deactivated = user.is_active and not is_active

    user.full_name = (full_name or "").strip() or None
    user.email = (email or "").strip() or None
    user.role = role
    user.is_active = is_active

    password = (password or "").strip()
    if password:
        validate_password_strength(password)
        user.password_hash = hash_password(password)

    # Смена пароля, роли или деактивация должны немедленно обрывать активные сессии.
    if password or role_changed or deactivated:
        touch_session_version(user)

    changes = []
    if password:
        changes.append("пароль")
    if role_changed:
        changes.append(f"роль -> {role}")
    if deactivated:
        changes.append("деактивирован")
    log_change(db, "system", user.id, "user_update",
               f"Изменён пользователь {user.username}"
               + (f": {', '.join(changes)}" if changes else ""),
               actor=current_user.username)
    db.commit()
    return redirect("/admin/users")


# --------------------------------------------------------------------------- #
# Резервные копии базы
# --------------------------------------------------------------------------- #

@router.get("/backups", response_class=HTMLResponse)
def backups_page(
    request: Request,
    current_user: User = Depends(require_role("admin")),
):
    try:
        database_path = str(get_sqlite_db_path())
    except BackupError as exc:
        database_path = str(exc)
    return templates.TemplateResponse(
        request=request,
        name="backups.html",
        context=base_context(
            request,
            current_user,
            backups=list_db_backups(),
            backup_dir=str(get_backup_dir()),
            database_path=database_path,
        ),
    )


@router.post("/backups/create")
def create_backup(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    try:
        path = create_sqlite_backup(current_user.username)
    except BackupNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except BackupError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    log_change(db, "system", None, "backup", f"Создана резервная копия базы: {path.name}",
               actor=current_user.username)
    db.commit()
    return redirect("/admin/backups")


@router.get("/backups/{filename}/download")
def download_backup(filename: str, current_user: User = Depends(require_role("admin"))):
    try:
        path = resolve_backup_path(filename)
    except BackupNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except BackupError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return FileResponse(path=str(path), media_type="application/octet-stream", filename=path.name)


@router.post("/backups/{filename}/delete")
def delete_backup(
    filename: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    try:
        path = resolve_backup_path(filename)
    except BackupNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except BackupError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    path.unlink()
    log_change(db, "system", None, "backup_delete", f"Удалена резервная копия базы: {filename}",
               actor=current_user.username)
    db.commit()
    return redirect("/admin/backups")
