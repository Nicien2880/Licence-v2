from __future__ import annotations

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from ..auth import require_role
from ..core.parsing import parse_datetime_local, parse_int
from ..database import get_db
from ..deps import base_context, page_user, redirect, templates
from ..models import BackupObject, User
from ..services.backup_monitor import (
    BACKUP_STATUSES,
    backup_platform_stats,
    backup_query,
    backup_stats,
    backup_type_stats,
)
from ..services.common import distinct_responsibles, log_change

router = APIRouter(tags=["backup-monitor"])


@router.get("/backup-monitor", response_class=HTMLResponse)
def backup_monitor_page(
    request: Request,
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    items = backup_query(db, q, status, responsible)
    all_items = backup_query(db)
    return templates.TemplateResponse(
        request=request,
        name="backup_monitor.html",
        context=base_context(
            request,
            current_user,
            items=items,
            all_items=all_items,
            stats=backup_stats(all_items),
            platform_stats=backup_platform_stats(all_items),
            type_stats=backup_type_stats(all_items),
            # Прежняя версия подставляла сюда selected_groups/selected_manufacturers,
            # которых в этой функции не существует — страница падала с NameError.
            selected={"q": q or "", "status": status or "", "responsible": responsible or ""},
            responsibles=distinct_responsibles(db, BackupObject),
            statuses=BACKUP_STATUSES,
        ),
    )


def _assign_fields(item: BackupObject, values: dict) -> None:
    item.object_name = values["object_name"] or "-"
    item.object_type = values["object_type"] or "vm"
    item.platform = values["platform"] or "manual"
    item.last_backup_at = parse_datetime_local(values["last_backup_at"])
    item.next_backup_at = parse_datetime_local(values["next_backup_at"])
    item.size_gb = parse_int(values["size_gb"])
    item.storage = values["storage"] or None
    item.retention_days = parse_int(values["retention_days"])
    item.duration_min = parse_int(values["duration_min"])
    item.policy_name = values["policy_name"] or None
    item.responsible = values["responsible"] or None
    item.status = values["status"] if values["status"] in BACKUP_STATUSES else "unknown"
    item.comment = values["comment"] or None


def _form_values(
    object_name: str, object_type: str, platform: str, last_backup_at: str | None,
    next_backup_at: str | None, size_gb: str | None, storage: str | None,
    retention_days: str | None, duration_min: str | None, policy_name: str | None,
    responsible: str | None, status: str, comment: str | None,
) -> dict:
    return locals()


@router.post("/backup-monitor")
def create_backup_object(
    object_name: str = Form("-"),
    object_type: str = Form("vm"),
    platform: str = Form("manual"),
    last_backup_at: str | None = Form(None),
    next_backup_at: str | None = Form(None),
    size_gb: str | None = Form(None),
    storage: str | None = Form(None),
    retention_days: str | None = Form(None),
    duration_min: str | None = Form(None),
    policy_name: str | None = Form(None),
    responsible: str | None = Form(None),
    status: str = Form("success"),
    comment: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = BackupObject()
    _assign_fields(item, _form_values(
        object_name, object_type, platform, last_backup_at, next_backup_at, size_gb,
        storage, retention_days, duration_min, policy_name, responsible, status, comment,
    ))
    db.add(item)
    db.flush()
    log_change(db, "backup_monitor", item.id, "create",
               f"Добавлен объект резервного копирования: {item.object_name}",
               actor=current_user.username)
    db.commit()
    return redirect("/backup-monitor")


@router.post("/backup-monitor/{item_id}/update")
def update_backup_object(
    item_id: int,
    object_name: str = Form("-"),
    object_type: str = Form("vm"),
    platform: str = Form("manual"),
    last_backup_at: str | None = Form(None),
    next_backup_at: str | None = Form(None),
    size_gb: str | None = Form(None),
    storage: str | None = Form(None),
    retention_days: str | None = Form(None),
    duration_min: str | None = Form(None),
    policy_name: str | None = Form(None),
    responsible: str | None = Form(None),
    status: str = Form("success"),
    comment: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = db.get(BackupObject, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Объект резервного копирования не найден")
    _assign_fields(item, _form_values(
        object_name, object_type, platform, last_backup_at, next_backup_at, size_gb,
        storage, retention_days, duration_min, policy_name, responsible, status, comment,
    ))
    log_change(db, "backup_monitor", item.id, "update",
               f"Обновлён объект резервного копирования: {item.object_name}",
               actor=current_user.username)
    db.commit()
    return redirect("/backup-monitor")


@router.post("/backup-monitor/{item_id}/delete")
def delete_backup_object(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    item = db.get(BackupObject, item_id)
    if item:
        log_change(db, "backup_monitor", item.id, "delete",
                   f"Удалён объект резервного копирования: {item.object_name}",
                   actor=current_user.username)
        db.delete(item)
        db.commit()
    return redirect("/backup-monitor")
