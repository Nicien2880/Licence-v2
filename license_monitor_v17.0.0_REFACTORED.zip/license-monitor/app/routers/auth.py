from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from ..auth import (
    SESSION_COOKIE,
    create_session_token,
    login_throttle,
    throttle_key,
    verify_password,
)
from ..database import get_db
from ..deps import redirect, templates
from ..models import User
from ..settings import get_settings

logger = logging.getLogger(__name__)
router = APIRouter(tags=["auth"])


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    settings = get_settings()
    if not settings.auth_enabled:
        return redirect("/")
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"app_name": settings.app_name, "error": None},
    )


@router.post("/login")
def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    settings = get_settings()
    key = throttle_key(request, username)

    if login_throttle.is_locked(key):
        logger.warning("Вход заблокирован по лимиту попыток: %s", key)
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={
                "app_name": settings.app_name,
                "error": f"Слишком много попыток. Повторите через {settings.login_lockout_minutes} мин.",
            },
            status_code=429,
        )

    user = db.query(User).filter(User.username == username).first()
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        login_throttle.register_failure(key)
        # Одна и та же формулировка для всех случаев: иначе форма подсказывает,
        # какие логины существуют.
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={"app_name": settings.app_name, "error": "Неверный логин или пароль"},
            status_code=401,
        )

    login_throttle.reset(key)
    response = redirect("/")
    response.set_cookie(
        SESSION_COOKIE,
        create_session_token(user.id, user.session_version),
        httponly=True,
        samesite="lax",
        secure=settings.cookie_secure,
        max_age=settings.session_ttl_hours * 3600,
        path="/",
    )
    logger.info("Успешный вход: %s", user.username)
    return response


@router.post("/logout")
def logout():
    response = redirect("/login")
    response.delete_cookie(SESSION_COOKIE, path="/")
    return response
