from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from ..auth import require_api_key
from ..core.parsing import today_utc
from ..database import get_db
from ..models import HardwareSupport, SoftwareLicense
from ..services.backup_monitor import (
    backup_platform_stats,
    backup_query,
    backup_stats,
    backup_to_api,
    backup_type_stats,
)
from ..services.data_protection import dp_query, dp_stats, dp_to_api, dp_type_stats
from ..services.inventory import (
    combined_api_items,
    hardware_query,
    hardware_stats,
    hardware_to_api,
    software_query,
    software_stats,
    software_to_api,
)
from ..settings import get_settings

# Все эндпоинты роутера закрыты API-ключом на уровне зависимости,
# а не вызовом require_api_key() в теле каждой функции — так его нельзя забыть.
router = APIRouter(prefix="/api", tags=["api"], dependencies=[Depends(require_api_key)])


@router.get("/licenses")
def api_licenses(
    section: str | None = None,
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
):
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]
    if section == "software":
        return [software_to_api(x) for x in software_query(db, q, status, responsible)]
    return combined_api_items(db)


@router.get("/licenses/expiring")
def api_expiring(days: int = 30, section: str | None = None, db: Session = Depends(get_db)):
    today = today_utc()
    if section == "hardware":
        return [hardware_to_api(x, today) for x in hardware_query(db) if x.days_left(today) <= days]
    if section == "software":
        return [software_to_api(x, today) for x in software_query(db) if x.days_left(today) <= days]
    return combined_api_items(db, days=days)


@router.get("/hardware-support")
def api_hardware(
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
):
    return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]


@router.get("/hardware-support/{item_id}")
def api_hardware_item(item_id: int, db: Session = Depends(get_db)):
    # GET больше не пишет в базу: статус вычисляется в hardware_to_api на лету.
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    return hardware_to_api(item)


@router.get("/software-licenses")
def api_software(
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
):
    return [software_to_api(x) for x in software_query(db, q, status, responsible)]


@router.get("/software-licenses/{item_id}")
def api_software_item(item_id: int, db: Session = Depends(get_db)):
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    return software_to_api(item)


@router.get("/backup-monitor")
def api_backup_monitor(
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
):
    return [backup_to_api(x) for x in backup_query(db, q, status, responsible)]


@router.get("/backup-monitor/summary")
def api_backup_summary(db: Session = Depends(get_db)):
    items = backup_query(db)
    return {
        "stats": backup_stats(items),
        "platforms": backup_platform_stats(items),
        "types": backup_type_stats(items),
    }


@router.get("/data-protection/plan")
def api_dp_plan(
    q: str | None = None,
    backup_type: str | None = None,
    responsible: str | None = None,
    db: Session = Depends(get_db),
):
    return [dp_to_api(x) for x in dp_query(db, q, backup_type, responsible)]


@router.get("/data-protection/summary")
def api_dp_summary(db: Session = Depends(get_db)):
    items = dp_query(db)
    return {"stats": dp_stats(items), "types": dp_type_stats(items)}


def _collect_summary(db: Session) -> dict:
    """Одна выборка на раздел.

    Прежняя реализация /api/zabbix/summary вызывала backup_stats(backup_query(db))
    шесть раз и dp_stats(dp_query(db)) трижды — девять полных обходов таблиц
    вместо двух.
    """
    return {
        "hardware": hardware_stats(hardware_query(db)),
        "software": software_stats(software_query(db)),
        "backup": backup_stats(backup_query(db)),
        "data_protection": dp_stats(dp_query(db)),
    }


@router.get("/monitoring/summary")
def api_monitoring_summary(db: Session = Depends(get_db)):
    summary = _collect_summary(db)
    return {
        "hardware_support": summary["hardware"],
        "software_licenses": summary["software"],
        "backup_monitor": summary["backup"],
        "data_protection": summary["data_protection"],
    }


@router.get("/zabbix/summary")
def api_zabbix_summary(db: Session = Depends(get_db)):
    """Плоский JSON для HTTP agent + JSONPath."""
    summary = _collect_summary(db)
    hw, sw = summary["hardware"], summary["software"]
    backup, dp = summary["backup"], summary["data_protection"]
    return {
        "hardware_total": hw["total"],
        "hardware_warning": hw["warning"],
        "hardware_critical": hw["critical"],
        "hardware_urgent": hw["urgent"],
        "hardware_expired": hw["expired"],
        "software_total": sw["total"],
        "software_warning": sw["warning"],
        "software_critical": sw["critical"],
        "software_urgent": sw["urgent"],
        "software_expired": sw["expired"],
        "total_expired": hw["expired"] + sw["expired"],
        "total_urgent": hw["urgent"] + sw["urgent"],
        "total_critical": hw["critical"] + sw["critical"],
        "total_warning": hw["warning"] + sw["warning"],
        "backup_total": backup["total"],
        "backup_success": backup["success"],
        "backup_warning": backup["warning"],
        "backup_failed": backup["failed"],
        "backup_running": backup["running"],
        "backup_health": backup["health"],
        "data_protection_total": dp["total"],
        "data_protection_volume_gb": dp["volume_gb"],
        "data_protection_no_responsible": dp["no_responsible"],
    }


# /metrics и /health живут вне префикса /api.
public_router = APIRouter(tags=["monitoring"])


@public_router.get("/metrics", response_class=PlainTextResponse)
def metrics(request: Request, db: Session = Depends(get_db)):
    """Формат Prometheus text exposition с HELP/TYPE."""
    require_api_key(request)
    summary = _collect_summary(db)
    lines: list[str] = [
        "# HELP license_monitor_records Количество записей по статусам.",
        "# TYPE license_monitor_records gauge",
    ]
    for section in ("hardware", "software"):
        for key, value in summary[section].items():
            lines.append(f'license_monitor_records{{section="{section}",status="{key}"}} {value}')

    lines += [
        "# HELP license_monitor_backup Состояние объектов резервного копирования.",
        "# TYPE license_monitor_backup gauge",
    ]
    for key, value in summary["backup"].items():
        lines.append(f'license_monitor_backup{{state="{key}"}} {value}')

    lines += [
        "# HELP license_monitor_data_protection Метрики плана резервирования.",
        "# TYPE license_monitor_data_protection gauge",
    ]
    for key, value in summary["data_protection"].items():
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            lines.append(f'license_monitor_data_protection{{metric="{key}"}} {value}')

    return "\n".join(lines) + "\n"


@public_router.get("/health")
def health(db: Session = Depends(get_db)):
    """Проверка живости для Docker HEALTHCHECK и балансировщика.

    Дёргает базу: процесс, поднятый над недоступным файлом БД, «живым» не считается.
    """
    from sqlalchemy import text

    try:
        db.execute(text("SELECT 1"))
        database_ok = True
    except Exception:
        database_ok = False
    status_code = 200 if database_ok else 503
    body = {
        "status": "ok" if database_ok else "degraded",
        "app": get_settings().app_name,
        "database": "ok" if database_ok else "unavailable",
    }
    from fastapi.responses import JSONResponse

    return JSONResponse(body, status_code=status_code)
