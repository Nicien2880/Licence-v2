from __future__ import annotations

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, StreamingResponse
from sqlalchemy.orm import Session

from ..auth import require_role
from ..core.parsing import parse_int, parse_volume_gb, today_utc
from ..database import get_db
from ..deps import base_context, page_user, redirect, templates
from ..models import DataProtectionPolicy, User
from ..services.common import distinct_responsibles, log_change
from ..services.data_protection import (
    DP_TYPE_LABELS,
    dp_grouped,
    dp_query,
    dp_schedule_stats,
    dp_stats,
    dp_type_stats,
    normalize_backup_type,
)
from ..services.exporting import (
    DATA_PROTECTION_HEADERS,
    XLSX_MEDIA_TYPE,
    build_workbook,
    data_protection_rows,
)
from ..services.importing import (
    create_dp_items,
    dp_import_stats,
    parse_dp_docx,
    parse_dp_xlsx,
)
from ..state import preview_store

router = APIRouter(tags=["data-protection"])


@router.get("/data-protection", response_class=HTMLResponse)
def data_protection_page(
    request: Request,
    q: str | None = None,
    backup_type: str | None = None,
    responsible: str | None = None,
    preview: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    items = dp_query(db, q, backup_type, responsible)
    all_items = dp_query(db)

    import_preview = preview_store.load(preview) if preview else None
    if import_preview:
        import_preview["stats"] = dp_import_stats(import_preview.get("rows", []))

    return templates.TemplateResponse(
        request=request,
        name="data_protection.html",
        context=base_context(
            request,
            current_user,
            items=items,
            all_items=all_items,
            groups=dp_grouped(items),
            stats=dp_stats(all_items),
            type_stats=dp_type_stats(all_items),
            schedule_stats=dp_schedule_stats(all_items),
            backup_types=DP_TYPE_LABELS,
            selected={
                "q": q or "",
                "backup_type": backup_type or "",
                "responsible": responsible or "",
            },
            responsibles=distinct_responsibles(db, DataProtectionPolicy),
            import_preview=import_preview,
        ),
    )


def _assign_policy(item: DataProtectionPolicy, values: dict) -> None:
    item.row_number = parse_int(values["row_number"])
    item.backup_type = normalize_backup_type(values["backup_type"])
    item.system_name = values["system_name"] or "-"
    item.reserved_information = values["reserved_information"] or None
    item.max_volume_gb = parse_volume_gb(values["max_volume_gb"])
    item.procedure_frequency = values["procedure_frequency"] or None
    item.retention_period = values["retention_period"] or None
    item.notes = values["notes"] or None
    item.responsible_person = values["responsible_person"] or None


def _policy_form(
    row_number: str | None, backup_type: str, system_name: str,
    reserved_information: str | None, max_volume_gb: str | None,
    procedure_frequency: str | None, retention_period: str | None,
    notes: str | None, responsible_person: str | None,
) -> dict:
    return locals()


@router.post("/data-protection")
def create_policy(
    row_number: str | None = Form(None),
    backup_type: str = Form("filesystem"),
    system_name: str = Form("-"),
    reserved_information: str | None = Form(None),
    max_volume_gb: str | None = Form(None),
    procedure_frequency: str | None = Form(None),
    retention_period: str | None = Form(None),
    notes: str | None = Form(None),
    responsible_person: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = DataProtectionPolicy()
    _assign_policy(item, _policy_form(
        row_number, backup_type, system_name, reserved_information, max_volume_gb,
        procedure_frequency, retention_period, notes, responsible_person,
    ))
    db.add(item)
    db.flush()
    log_change(db, "data_protection", item.id, "create",
               f"Добавлена политика резервирования: {item.system_name}",
               actor=current_user.username)
    db.commit()
    return redirect("/data-protection")


@router.post("/data-protection/{item_id}/update")
def update_policy(
    item_id: int,
    row_number: str | None = Form(None),
    backup_type: str = Form("filesystem"),
    system_name: str = Form("-"),
    reserved_information: str | None = Form(None),
    max_volume_gb: str | None = Form(None),
    procedure_frequency: str | None = Form(None),
    retention_period: str | None = Form(None),
    notes: str | None = Form(None),
    responsible_person: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("editor")),
):
    item = db.get(DataProtectionPolicy, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Политика резервирования не найдена")
    _assign_policy(item, _policy_form(
        row_number, backup_type, system_name, reserved_information, max_volume_gb,
        procedure_frequency, retention_period, notes, responsible_person,
    ))
    log_change(db, "data_protection", item.id, "update",
               f"Обновлена политика резервирования: {item.system_name}",
               actor=current_user.username)
    db.commit()
    return redirect("/data-protection")


@router.post("/data-protection/{item_id}/delete")
def delete_policy(
    item_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    item = db.get(DataProtectionPolicy, item_id)
    if item:
        log_change(db, "data_protection", item.id, "delete",
                   f"Удалена политика резервирования: {item.system_name}",
                   actor=current_user.username)
        db.delete(item)
        db.commit()
    return redirect("/data-protection")


@router.post("/data-protection/clear")
def clear_policies(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    deleted = db.query(DataProtectionPolicy).delete(synchronize_session=False)
    log_change(db, "data_protection", None, "clear",
               f"Очищена таблица политик резервирования. Удалено записей: {deleted}",
               actor=current_user.username)
    db.commit()
    return redirect("/data-protection")


# --------------------------------------------------------------------------- #
# Экспорт / импорт
# --------------------------------------------------------------------------- #

@router.get("/data-protection/export.xlsx")
def export_policies(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    buffer = build_workbook(
        "data_protection_plan",
        DATA_PROTECTION_HEADERS,
        data_protection_rows(dp_query(db), DP_TYPE_LABELS),
        max_width=55,
    )
    filename = f"data_protection_plan_{today_utc().isoformat()}.xlsx"
    return StreamingResponse(
        buffer,
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


async def _make_preview(file: UploadFile, kind: str, username: str):
    """Разбирает файл и создаёт черновик импорта."""
    filename = (file.filename or "").lower()
    if kind == "xlsx":
        if not filename.endswith((".xlsx", ".xlsm")):
            raise HTTPException(status_code=400, detail="Загрузите файл .xlsx или .xlsm")
        rows = parse_dp_xlsx(await file.read())
        source_type = "Excel"
    else:
        if not filename.endswith(".docx"):
            raise HTTPException(status_code=400, detail="Загрузите файл .docx")
        try:
            rows = parse_dp_docx(await file.read())
        except RuntimeError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        source_type = "Word"

    if not rows:
        raise HTTPException(
            status_code=400,
            detail="В файле не найдено ни одной строки политики. Проверьте структуру таблицы.",
        )
    token = preview_store.save(rows, file.filename or "", source_type, username)
    return redirect(f"/data-protection?preview={token}")


@router.post("/data-protection/import.xlsx/preview")
@router.post("/data-protection/import.xlsx")
async def preview_xlsx(
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("manager")),
):
    return await _make_preview(file, "xlsx", current_user.username)


@router.post("/data-protection/import.docx/preview")
@router.post("/data-protection/import.docx")
async def preview_docx(
    file: UploadFile = File(...),
    current_user: User = Depends(require_role("manager")),
):
    return await _make_preview(file, "docx", current_user.username)


@router.post("/data-protection/import/commit")
def commit_import(
    token: str = Form(...),
    clear_before_import: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("manager")),
):
    preview = preview_store.load(token)
    if not preview:
        raise HTTPException(status_code=404, detail="Черновик импорта не найден или устарел")
    rows = preview.get("rows", [])
    if clear_before_import:
        db.query(DataProtectionPolicy).delete(synchronize_session=False)
    imported = create_dp_items(db, rows)
    log_change(db, "data_protection", None, "import",
               f"Подтверждён импорт Data Protection из {preview.get('source_type')}: "
               f"{preview.get('source_filename')}. Записей: {imported}",
               actor=current_user.username)
    db.commit()
    preview_store.delete(token)
    return redirect("/data-protection")


@router.post("/data-protection/import/cancel")
def cancel_import(
    token: str = Form(...),
    current_user: User = Depends(require_role("manager")),
):
    preview_store.delete(token)
    return redirect("/data-protection")
