"""Техподдержка оборудования и лицензии ПО: выборки, статусы, сериализация."""
from __future__ import annotations

import logging
from datetime import date

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..core.parsing import normalize_serial, today_utc
from ..core.status import calc_status, stats_for
from ..models import HardwareSupport, SoftwareLicense
from ..settings import get_settings

logger = logging.getLogger(__name__)

STATUSES = ["active", "warning", "critical", "urgent", "expired"]


def thresholds():
    return get_settings().thresholds


def apply_status(item, today: date | None = None) -> bool:
    """Проставляет актуальный статус. True, если значение изменилось."""
    today = today or today_utc()
    new_status = calc_status(item.days_left(today), thresholds())
    if item.status != new_status:
        item.status = new_status
        return True
    return False


def refresh_statuses(db: Session) -> int:
    """Пересчёт статусов всех записей.

    Вызывается при старте и по таймеру. Раньше пересчёт происходил внутри
    каждой выборки, из-за чего обычный GET-запрос писал в базу.
    """
    today = today_utc()
    changed = 0
    for model in (HardwareSupport, SoftwareLicense):
        for item in db.scalars(select(model)).all():
            if apply_status(item, today):
                changed += 1
    if changed:
        db.commit()
        logger.info("Пересчитано статусов: %d", changed)
    return changed


# --------------------------------------------------------------------------- #
# Выборки
# --------------------------------------------------------------------------- #

def hardware_query(
    db: Session,
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    manufacturers: list[str] | None = None,
) -> list[HardwareSupport]:
    query = db.query(HardwareSupport)
    if q:
        pattern = f"%{q.strip()}%"
        query = query.filter(or_(
            HardwareSupport.manufacturer.ilike(pattern),
            HardwareSupport.dzo.ilike(pattern),
            HardwareSupport.serial_number.ilike(pattern),
            HardwareSupport.equipment_model.ilike(pattern),
            HardwareSupport.contract_number.ilike(pattern),
            HardwareSupport.contractor.ilike(pattern),
            HardwareSupport.responsible.ilike(pattern),
            HardwareSupport.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(HardwareSupport.status == status)
    if responsible:
        query = query.filter(HardwareSupport.responsible == responsible)
    values = [m for m in (manufacturers or []) if m]
    if values:
        query = query.filter(HardwareSupport.manufacturer.in_(values))
    return query.order_by(HardwareSupport.support_end_date.asc()).all()


def software_query(
    db: Session,
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
    groups: list[str] | None = None,
) -> list[SoftwareLicense]:
    query = db.query(SoftwareLicense)
    if q:
        pattern = f"%{q.strip()}%"
        query = query.filter(or_(
            SoftwareLicense.group_name.ilike(pattern),
            SoftwareLicense.location.ilike(pattern),
            SoftwareLicense.code.ilike(pattern),
            SoftwareLicense.certificate_number.ilike(pattern),
            SoftwareLicense.contract_number.ilike(pattern),
            SoftwareLicense.contractor.ilike(pattern),
            SoftwareLicense.responsible.ilike(pattern),
            SoftwareLicense.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(SoftwareLicense.status == status)
    if responsible:
        query = query.filter(SoftwareLicense.responsible == responsible)
    values = [g for g in (groups or []) if g]
    if values:
        query = query.filter(SoftwareLicense.group_name.in_(values))
    return query.order_by(SoftwareLicense.cert_end_date.asc()).all()


def hardware_stats(items) -> dict:
    return stats_for(items, today_utc(), thresholds())


def software_stats(items) -> dict:
    return stats_for(items, today_utc(), thresholds())


# --------------------------------------------------------------------------- #
# Уникальность серийных номеров
# --------------------------------------------------------------------------- #

def hardware_serial_exists(
    db: Session, serial_number: str | None, exclude_id: int | None = None
) -> bool:
    """Проверка по индексированной колонке вместо перебора всей таблицы."""
    normalized = normalize_serial(serial_number)
    if not normalized or normalized == "-":
        return False
    query = db.query(HardwareSupport.id).filter(
        HardwareSupport.serial_normalized == normalized
    )
    if exclude_id is not None:
        query = query.filter(HardwareSupport.id != exclude_id)
    return db.query(query.exists()).scalar()


# --------------------------------------------------------------------------- #
# Сериализация
# --------------------------------------------------------------------------- #

def hardware_to_api(item: HardwareSupport, today: date | None = None) -> dict:
    today = today or today_utc()
    return {
        "id": item.id,
        "section": "hardware",
        "section_name": "Техподдержка оборудования",
        "number": None,
        "manufacturer": item.manufacturer,
        "dzo": item.dzo,
        "serial_number": item.serial_number,
        "equipment_model": item.equipment_model,
        "delivery_year": item.delivery_year,
        "support_end_date": item.support_end_date,
        "purchase_period": item.purchase_period,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "auto_renewal": item.auto_renewal,
        "comment": item.comment,
        "days_left": item.days_left(today),
        "status": calc_status(item.days_left(today), thresholds()),
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def software_to_api(item: SoftwareLicense, today: date | None = None) -> dict:
    today = today or today_utc()
    return {
        "id": item.id,
        "section": "software",
        "section_name": "Лицензии ПО",
        "number": None,
        "group_name": item.group_name,
        "location": item.location,
        "code": item.code,
        "quantity": item.quantity,
        "cert_start_date": item.cert_start_date,
        "cert_end_date": item.cert_end_date,
        "certificate_number": item.certificate_number,
        "comment": item.comment,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "days_left": item.days_left(today),
        "status": calc_status(item.days_left(today), thresholds()),
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def combined_api_items(db: Session, days: int | None = None) -> list[dict]:
    today = today_utc()
    result = [
        hardware_to_api(item, today)
        for item in hardware_query(db)
        if days is None or item.days_left(today) <= days
    ]
    result += [
        software_to_api(item, today)
        for item in software_query(db)
        if days is None or item.days_left(today) <= days
    ]
    result.sort(key=lambda x: x["days_left"])
    for index, item in enumerate(result, 1):
        item["number"] = index
    return result
