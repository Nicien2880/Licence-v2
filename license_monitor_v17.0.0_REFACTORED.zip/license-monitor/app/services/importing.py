"""Импорт из Excel и Word.

Ключевое отличие от прежней реализации: строки, которые не удалось разобрать,
больше не проглатываются через `except Exception: continue`. Каждая ошибка
собирается с номером строки и причиной и возвращается пользователю.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook
from sqlalchemy.orm import Session

from ..core.parsing import (
    clean_cell,
    parse_bool,
    parse_date,
    parse_int,
    parse_volume_gb,
    utcnow,
)
from ..core.schedule import DP_TYPE_LABELS, normalize_backup_type
from ..models import DataProtectionPolicy, HardwareSupport, SoftwareLicense

try:
    from docx import Document
except ImportError:  # python-docx необязателен для работы остальных разделов
    Document = None

TOKEN_RE = re.compile(r"^[a-f0-9]{32}$")
PREVIEW_TTL_HOURS = 24


@dataclass
class RowError:
    row: int
    message: str
    raw: str = ""


@dataclass
class ImportResult:
    imported: int = 0
    skipped: int = 0
    errors: list[RowError] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return bool(self.errors)

    def summary(self) -> str:
        return (
            f"импортировано {self.imported}, пропущено {self.skipped}, "
            f"ошибок {len(self.errors)}"
        )


# --------------------------------------------------------------------------- #
# Инвентарь: hardware / software
# --------------------------------------------------------------------------- #

HARDWARE_HEADERS = {
    "manufacturer": ["Производитель"],
    "dzo": ["ДЗО"],
    "serial_number": ["Серийный номер"],
    "equipment_model": ["Модель оборудования"],
    "delivery_year": ["Год поставки"],
    "support_end_date": ["Текущее состояние ТП (дата окончания)", "Дата окончания ТП"],
    "purchase_period": ["Срок на который закупается ТП"],
    "contract_number": ["Договор", "Номер договора"],
    "contractor": ["Контрагент"],
    "responsible": ["Ответственный", "Описание"],
    "auto_renewal": ["Автопродление"],
    "comment": ["Комментарий"],
}

SOFTWARE_HEADERS = {
    "group_name": ["Производитель", "Группа"],
    "location": ["ДЗО", "Локация"],
    "code": ["Код"],
    "quantity": ["Кол-во", "Количество"],
    "cert_start_date": ["Дата начала сертификата"],
    "cert_end_date": ["Дата окончания сертификата"],
    "certificate_number": ["Номер сертификата"],
    "comment": ["Комментарий"],
    "contract_number": ["Номер договора", "Договор"],
    "contractor": ["Контрагент"],
    "responsible": ["Ответственный", "Описание"],
}


class HeaderMap:
    """Сопоставление имён колонок с индексами, устойчивое к синонимам."""

    def __init__(self, headers: list[str], mapping: dict[str, list[str]]):
        normalized = {clean_cell(name).lower(): index for index, name in enumerate(headers)}
        self._index: dict[str, int] = {}
        for field_name, candidates in mapping.items():
            for candidate in candidates:
                key = candidate.lower()
                if key in normalized:
                    self._index[field_name] = normalized[key]
                    break

    def has(self, field_name: str) -> bool:
        return field_name in self._index

    def get(self, row: tuple, field_name: str, default=None):
        index = self._index.get(field_name)
        if index is None or index >= len(row):
            return default
        value = row[index]
        return default if value is None else value

    def text(self, row: tuple, field_name: str, default: str | None = None) -> str | None:
        value = clean_cell(self.get(row, field_name))
        return value or default

    def missing(self, required: list[str]) -> list[str]:
        return [name for name in required if name not in self._index]


def _read_sheet(file_bytes: bytes) -> list[tuple]:
    workbook = load_workbook(BytesIO(file_bytes), data_only=True, read_only=True)
    try:
        return list(workbook.active.iter_rows(values_only=True))
    finally:
        workbook.close()


def import_hardware_rows(db: Session, file_bytes: bytes) -> ImportResult:
    result = ImportResult()
    rows = _read_sheet(file_bytes)
    if not rows:
        result.errors.append(RowError(0, "Файл пуст"))
        return result

    headers = [clean_cell(value) for value in rows[0]]
    mapper = HeaderMap(headers, HARDWARE_HEADERS)
    missing = mapper.missing(["serial_number", "support_end_date"])
    if missing:
        result.errors.append(RowError(
            1, f"В заголовке не найдены обязательные колонки: {', '.join(missing)}"
        ))
        return result

    # Серийники, уже встреченные в этом же файле, чтобы не плодить дубли внутри импорта.
    seen: set[str] = set()
    from .inventory import apply_status, hardware_serial_exists
    from ..core.parsing import normalize_serial

    for line, row in enumerate(rows[1:], start=2):
        if not row or not any(row):
            continue
        raw_preview = " | ".join(clean_cell(value) for value in row[:4])
        try:
            end_date = parse_date(mapper.get(row, "support_end_date"))
        except ValueError as exc:
            result.errors.append(RowError(line, str(exc), raw_preview))
            continue
        if end_date is None:
            result.errors.append(RowError(line, "Не заполнена дата окончания ТП", raw_preview))
            continue

        serial = mapper.text(row, "serial_number", "-") or "-"
        normalized = normalize_serial(serial)
        if normalized and normalized != "-":
            if normalized in seen:
                result.skipped += 1
                result.errors.append(RowError(
                    line, f"Серийный номер повторяется внутри файла: {serial}", raw_preview
                ))
                continue
            if hardware_serial_exists(db, serial):
                result.skipped += 1
                result.errors.append(RowError(
                    line, f"Серийный номер уже есть в базе: {serial}", raw_preview
                ))
                continue
            seen.add(normalized)

        item = HardwareSupport(
            manufacturer=mapper.text(row, "manufacturer"),
            dzo=mapper.text(row, "dzo", "-") or "-",
            serial_number=serial,
            equipment_model=mapper.text(row, "equipment_model", "-") or "-",
            delivery_year=parse_int(mapper.get(row, "delivery_year")),
            support_end_date=end_date,
            purchase_period=mapper.text(row, "purchase_period"),
            contract_number=mapper.text(row, "contract_number"),
            contractor=mapper.text(row, "contractor"),
            responsible=mapper.text(row, "responsible"),
            auto_renewal=parse_bool(mapper.get(row, "auto_renewal")),
            comment=mapper.text(row, "comment"),
        )
        item.sync_serial()
        apply_status(item)
        db.add(item)
        result.imported += 1
    return result


def import_software_rows(db: Session, file_bytes: bytes) -> ImportResult:
    result = ImportResult()
    rows = _read_sheet(file_bytes)
    if not rows:
        result.errors.append(RowError(0, "Файл пуст"))
        return result

    headers = [clean_cell(value) for value in rows[0]]
    mapper = HeaderMap(headers, SOFTWARE_HEADERS)
    missing = mapper.missing(["cert_end_date"])
    if missing:
        result.errors.append(RowError(
            1, f"В заголовке не найдены обязательные колонки: {', '.join(missing)}"
        ))
        return result

    from .inventory import apply_status

    for line, row in enumerate(rows[1:], start=2):
        if not row or not any(row):
            continue
        raw_preview = " | ".join(clean_cell(value) for value in row[:4])
        try:
            end_date = parse_date(mapper.get(row, "cert_end_date"))
        except ValueError as exc:
            result.errors.append(RowError(line, str(exc), raw_preview))
            continue
        if end_date is None:
            result.errors.append(RowError(
                line, "Не заполнена дата окончания сертификата", raw_preview
            ))
            continue
        try:
            start_date = parse_date(mapper.get(row, "cert_start_date"))
        except ValueError as exc:
            result.errors.append(RowError(line, f"Дата начала: {exc}", raw_preview))
            continue

        item = SoftwareLicense(
            group_name=mapper.text(row, "group_name"),
            location=mapper.text(row, "location"),
            code=mapper.text(row, "code", "-") or "-",
            quantity=parse_int(mapper.get(row, "quantity"), 1) or 1,
            cert_start_date=start_date,
            cert_end_date=end_date,
            certificate_number=mapper.text(row, "certificate_number"),
            comment=mapper.text(row, "comment"),
            contract_number=mapper.text(row, "contract_number"),
            contractor=mapper.text(row, "contractor"),
            responsible=mapper.text(row, "responsible"),
        )
        apply_status(item)
        db.add(item)
        result.imported += 1
    return result


# --------------------------------------------------------------------------- #
# Data Protection: разбор Excel и Word
# --------------------------------------------------------------------------- #

def detect_docx_backup_type(row_values: list[str], current_type: str) -> str:
    joined = " ".join(value.lower() for value in row_values if value)
    if any(marker in joined for marker in ["filesystem", "file system", "файлов"]):
        return "filesystem"
    if any(marker in joined for marker in ["internal database", "internal db", "встроенн"]):
        return "internal_database"
    if any(marker in joined for marker in ["ms sql", "mssql", "sql server"]):
        return "ms_sql_server"
    if any(marker in joined for marker in ["virtual environment", "virtual", "vmware", "виртуаль"]):
        return "virtual_environment"
    return current_type


def is_header_row(row_values: list[str]) -> bool:
    joined = " ".join(value.lower() for value in row_values if value)
    header_words = ["наименование", "информац", "периодич", "срок", "ответствен", "резерв"]
    return sum(1 for word in header_words if word in joined) >= 3


def row_looks_like_group(row_values: list[str]) -> bool:
    """Строка-заголовок блока в Word.

    Word дублирует текст объединённой ячейки во все физические ячейки строки,
    поэтому «Filesystem | Filesystem | ...» — это один заголовок группы,
    а не политика.
    """
    non_empty = [value for value in row_values if value]
    if not non_empty:
        return False
    unique = {value.lower() for value in non_empty}
    if len(non_empty) == 1 or len(unique) == 1:
        value = next(iter(unique))
        return any(
            marker in value
            for marker in ["filesystem", "internal", "sql", "virtual", "файлов", "виртуаль"]
        )
    return False


def build_policy_row(
    row_number, backup_type, system_name, reserved_information, max_volume,
    procedure_frequency, retention_period, notes, responsible_person,
) -> dict:
    return {
        "row_number": parse_int(clean_cell(row_number)),
        "backup_type": normalize_backup_type(backup_type),
        "system_name": clean_cell(system_name) or "-",
        "reserved_information": clean_cell(reserved_information) or None,
        "max_volume_gb": parse_volume_gb(max_volume),
        "procedure_frequency": clean_cell(procedure_frequency) or None,
        "retention_period": clean_cell(retention_period) or None,
        "notes": clean_cell(notes) or None,
        "responsible_person": clean_cell(responsible_person) or None,
    }


def parse_dp_xlsx(file_bytes: bytes) -> list[dict]:
    parsed = []
    for row in _read_sheet(file_bytes)[1:]:
        values = [clean_cell(value) for value in row]
        if not any(values) or is_header_row(values):
            continue
        padded = values + [""] * (9 - len(values))
        parsed.append(build_policy_row(*padded[:9]))
    return parsed


def parse_dp_docx(file_bytes: bytes) -> list[dict]:
    if Document is None:
        raise RuntimeError("python-docx не установлен. Выполните: pip install python-docx")
    document = Document(BytesIO(file_bytes))
    current_type = "filesystem"
    parsed = []
    junk_markers = [
        "наименование информационной системы",
        "информация, подлежащая",
        "ответственный работник",
    ]
    for table in document.tables:
        for row in table.rows:
            values = [clean_cell(cell.text) for cell in row.cells]
            if not any(values):
                continue
            if row_looks_like_group(values):
                current_type = detect_docx_backup_type(values, current_type)
                continue
            if is_header_row(values):
                continue
            padded = values + [""] * (8 - len(values))
            data = build_policy_row(
                padded[0], current_type, padded[1], padded[2], padded[3],
                padded[4], padded[5], padded[6], padded[7],
            )
            if data["system_name"] == "-" and not data["reserved_information"]:
                continue
            joined = " ".join(values).lower()
            if any(marker in joined for marker in junk_markers):
                continue
            parsed.append(data)
    return parsed


def create_dp_items(db: Session, rows: list[dict]) -> int:
    for row in rows:
        db.add(DataProtectionPolicy(
            row_number=row.get("row_number"),
            backup_type=normalize_backup_type(row.get("backup_type")),
            system_name=row.get("system_name") or "-",
            reserved_information=row.get("reserved_information"),
            max_volume_gb=row.get("max_volume_gb"),
            procedure_frequency=row.get("procedure_frequency"),
            retention_period=row.get("retention_period"),
            notes=row.get("notes"),
            responsible_person=row.get("responsible_person"),
        ))
    return len(rows)


def dp_import_stats(rows: list[dict]) -> dict:
    from ..core.parsing import format_volume

    volume = sum(row.get("max_volume_gb") or 0 for row in rows)
    by_type: dict[str, dict] = {}
    for row in rows:
        key = normalize_backup_type(row.get("backup_type"))
        entry = by_type.setdefault(
            key, {"type": key, "label": DP_TYPE_LABELS.get(key, key), "count": 0, "volume_gb": 0}
        )
        entry["count"] += 1
        entry["volume_gb"] += row.get("max_volume_gb") or 0
    for entry in by_type.values():
        entry["volume_label"] = format_volume(entry["volume_gb"])
    return {
        "count": len(rows),
        "volume_gb": volume,
        "volume_label": format_volume(volume),
        "no_system": sum(1 for row in rows if not row.get("system_name") or row["system_name"] == "-"),
        "no_responsible": sum(1 for row in rows if not row.get("responsible_person")),
        "types": sorted(by_type.values(), key=lambda x: x["label"]),
    }


# --------------------------------------------------------------------------- #
# Предпросмотр импорта (файловое хранилище)
# --------------------------------------------------------------------------- #

class PreviewStore:
    """Черновики импорта на диске: пользователь сначала смотрит, потом применяет."""

    def __init__(self, directory: Path):
        self.directory = directory

    def _path(self, token: str) -> Path | None:
        if not token or not TOKEN_RE.match(token):
            return None
        return self.directory / f"{token}.json"

    def save(self, rows: list[dict], source_filename: str, source_type: str, username: str) -> str:
        self.directory.mkdir(parents=True, exist_ok=True)
        token = uuid.uuid4().hex
        payload = {
            "token": token,
            "created_at": utcnow().isoformat(timespec="seconds"),
            "source_filename": source_filename,
            "source_type": source_type,
            "created_by": username,
            "rows": rows[:5000],
            "total_rows": len(rows),
        }
        (self.directory / f"{token}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return token

    def load(self, token: str) -> dict | None:
        path = self._path(token)
        if path is None or not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return None

    def delete(self, token: str) -> None:
        path = self._path(token)
        if path is not None and path.exists():
            path.unlink()

    def purge_expired(self) -> int:
        """Черновики не удалялись при отказе от импорта и копились бесконечно."""
        if not self.directory.exists():
            return 0
        threshold = utcnow().timestamp() - PREVIEW_TTL_HOURS * 3600
        removed = 0
        for path in self.directory.glob("*.json"):
            try:
                if path.stat().st_mtime < threshold:
                    path.unlink()
                    removed += 1
            except OSError:
                continue
        return removed
