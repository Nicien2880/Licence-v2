"""План резервирования информационных систем (раздел Data Protection)."""
from __future__ import annotations

from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..core.parsing import format_volume
from ..core.schedule import (
    DIFFERENTIAL_MARKERS,
    DP_TYPE_LABELS,
    FULL_MARKERS,
    INCREMENTAL_MARKERS,
    has_any,
    normalize_backup_type,
    normalize_text,
    schedule_stats,
)
from ..models import DataProtectionPolicy

__all__ = [
    "DP_TYPE_LABELS",
    "normalize_backup_type",
    "dp_query",
    "dp_grouped",
    "dp_stats",
    "dp_type_stats",
    "dp_schedule_stats",
    "dp_to_api",
]


def dp_query(
    db: Session,
    q: str | None = None,
    backup_type: str | None = None,
    responsible: str | None = None,
) -> list[DataProtectionPolicy]:
    query = db.query(DataProtectionPolicy)
    if q:
        pattern = f"%{q.strip()}%"
        query = query.filter(or_(
            DataProtectionPolicy.system_name.ilike(pattern),
            DataProtectionPolicy.reserved_information.ilike(pattern),
            DataProtectionPolicy.procedure_frequency.ilike(pattern),
            DataProtectionPolicy.retention_period.ilike(pattern),
            DataProtectionPolicy.notes.ilike(pattern),
            DataProtectionPolicy.responsible_person.ilike(pattern),
        ))
    if backup_type:
        query = query.filter(
            DataProtectionPolicy.backup_type == normalize_backup_type(backup_type)
        )
    if responsible:
        query = query.filter(DataProtectionPolicy.responsible_person == responsible)
    return query.order_by(
        DataProtectionPolicy.backup_type.asc(),
        DataProtectionPolicy.row_number.asc().nullslast(),
        DataProtectionPolicy.system_name.asc(),
    ).all()


def _empty_group(key: str) -> dict:
    return {
        "type": key,
        "label": DP_TYPE_LABELS.get(key, key),
        "items": [],
        "count": 0,
        "volume_gb": 0,
        "volume_label": "0 ГБ",
    }


def dp_grouped(items: list[DataProtectionPolicy]) -> list[dict]:
    result = {key: _empty_group(key) for key in DP_TYPE_LABELS}
    for item in items:
        key = normalize_backup_type(item.backup_type)
        row = result.setdefault(key, _empty_group(key))
        row["items"].append(item)
        row["count"] += 1
        row["volume_gb"] += item.max_volume_gb or 0
    for row in result.values():
        row["volume_label"] = format_volume(row["volume_gb"])
    return [row for row in result.values() if row["count"] > 0]


def dp_stats(items: list[DataProtectionPolicy]) -> dict:
    volume = sum(item.max_volume_gb or 0 for item in items)
    texts = [normalize_text(item.procedure_frequency) for item in items]
    return {
        "total": len(items),
        "volume_gb": volume,
        "volume_label": format_volume(volume),
        "types": len({item.backup_type for item in items}),
        "full": sum(1 for text in texts if has_any(text, FULL_MARKERS)),
        "incremental": sum(1 for text in texts if has_any(text, INCREMENTAL_MARKERS)),
        "differential": sum(1 for text in texts if has_any(text, DIFFERENTIAL_MARKERS)),
        "no_responsible": sum(1 for item in items if not item.responsible_person),
    }


def dp_type_stats(items: list[DataProtectionPolicy]) -> list[dict]:
    rows = [
        {
            "type": group["type"],
            "label": group["label"],
            "count": group["count"],
            "volume_gb": group["volume_gb"],
            "volume_label": group["volume_label"],
        }
        for group in dp_grouped(items)
    ]
    rows.sort(key=lambda x: x["volume_gb"], reverse=True)
    return rows


def dp_schedule_stats(items: list[DataProtectionPolicy]) -> dict:
    return schedule_stats(items)


def dp_to_api(item: DataProtectionPolicy) -> dict:
    return {
        "id": item.id,
        "row_number": item.row_number,
        "backup_type": item.backup_type,
        "backup_type_label": DP_TYPE_LABELS.get(item.backup_type, item.backup_type),
        "system_name": item.system_name,
        "reserved_information": item.reserved_information,
        "max_volume_gb": item.max_volume_gb,
        "procedure_frequency": item.procedure_frequency,
        "retention_period": item.retention_period,
        "notes": item.notes,
        "responsible_person": item.responsible_person,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }
