"""Резервное копирование файла базы средствами SQLite."""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime
from pathlib import Path

from ..core.parsing import utcnow
from ..settings import get_settings

BACKUP_FILENAME_RE = re.compile(r"^license_monitor_backup_\d{8}_\d{6}_[A-Za-z0-9_.-]+\.db$")


class BackupError(RuntimeError):
    """Ошибка операции с резервной копией."""


class BackupNotFound(BackupError):
    pass


class BackupUnsupported(BackupError):
    pass


def get_sqlite_db_path() -> Path:
    db_url = get_settings().database_url
    if not db_url.startswith("sqlite:///"):
        raise BackupUnsupported("Резервное копирование из интерфейса доступно только для SQLite")
    path = Path(db_url.replace("sqlite:///", "", 1))
    if not path.is_absolute():
        path = Path.cwd() / path
    return path.resolve()


def get_backup_dir() -> Path:
    path = Path(get_settings().backup_dir)
    if not path.is_absolute():
        path = Path.cwd() / path
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def list_db_backups() -> list[dict]:
    rows = []
    for path in sorted(get_backup_dir().glob("license_monitor_backup_*.db"), reverse=True):
        stat = path.stat()
        rows.append({
            "name": path.name,
            "size_bytes": stat.st_size,
            "size_mb": round(stat.st_size / 1024 / 1024, 2),
            "created_at": datetime.fromtimestamp(stat.st_mtime),
        })
    return rows


def resolve_backup_path(filename: str) -> Path:
    """Проверяет имя файла и то, что итоговый путь не вышел за пределы каталога."""
    if not BACKUP_FILENAME_RE.match(filename):
        raise BackupError("Недопустимое имя файла резервной копии")
    backup_dir = get_backup_dir()
    path = (backup_dir / filename).resolve()
    if path.parent != backup_dir:
        raise BackupError("Недопустимый путь резервной копии")
    if not path.exists() or not path.is_file():
        raise BackupNotFound("Резервная копия не найдена")
    return path


def create_sqlite_backup(username: str) -> Path:
    """Горячая копия через sqlite3.backup() — корректна и при активных записях."""
    db_path = get_sqlite_db_path()
    if not db_path.exists():
        raise BackupNotFound(f"Файл базы не найден: {db_path}")
    safe_user = re.sub(r"[^A-Za-z0-9_.-]", "_", username or "system")[:40]
    filename = f"license_monitor_backup_{utcnow().strftime('%Y%m%d_%H%M%S')}_{safe_user}.db"
    destination = get_backup_dir() / filename
    with sqlite3.connect(str(db_path)) as source, sqlite3.connect(str(destination)) as target:
        source.backup(target)
    return destination


def prune_backups(keep: int) -> list[str]:
    """Оставляет N последних копий. Без ротации каталог рос без ограничений."""
    if keep <= 0:
        return []
    files = sorted(
        get_backup_dir().glob("license_monitor_backup_*.db"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    removed = []
    for path in files[keep:]:
        try:
            path.unlink()
            removed.append(path.name)
        except OSError:
            continue
    return removed
