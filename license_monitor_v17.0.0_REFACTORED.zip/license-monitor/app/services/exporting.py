"""Формирование Excel-выгрузок."""
from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill("solid", fgColor="E5E7EB")
XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def build_workbook(title: str, headers: list[str], rows, max_width: int = 45) -> BytesIO:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = title
    sheet.append(headers)
    for row in rows:
        sheet.append(row)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.fill = HEADER_FILL
    for column_cells in sheet.columns:
        length = max(len(str(cell.value or "")) for cell in column_cells)
        letter = get_column_letter(column_cells[0].column)
        sheet.column_dimensions[letter].width = min(max(length + 2, 12), max_width)
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    buffer = BytesIO()
    workbook.save(buffer)
    buffer.seek(0)
    return buffer


HARDWARE_HEADERS = [
    "№", "Производитель", "ДЗО", "Серийный номер", "Модель оборудования", "Год поставки",
    "Текущее состояние ТП (дата окончания)", "Срок на который закупается ТП", "Договор",
    "Контрагент", "Ответственный", "Автопродление", "Комментарий", "Осталось дней", "Статус",
]

SOFTWARE_HEADERS = [
    "№", "Производитель", "ДЗО", "Код", "Кол-во", "Дата начала сертификата",
    "Дата окончания сертификата", "Номер сертификата", "Комментарий", "Номер договора",
    "Контрагент", "Описание", "Осталось дней", "Статус",
]

DATA_PROTECTION_HEADERS = [
    "№", "Тип backup", "Наименование информационной системы",
    "Информация, подлежащая резервированию", "Максимальный объём, ГБ",
    "Периодичность проведения процедуры", "Срок хранения информации",
    "Примечания", "Ответственный работник",
]


def hardware_rows(items, today):
    for index, item in enumerate(items, 1):
        yield [
            index, item.manufacturer, item.dzo, item.serial_number, item.equipment_model,
            item.delivery_year, item.support_end_date, item.purchase_period,
            item.contract_number, item.contractor, item.responsible,
            "да" if item.auto_renewal else "нет", item.comment,
            item.days_left(today), item.status,
        ]


def software_rows(items, today):
    for index, item in enumerate(items, 1):
        yield [
            index, item.group_name, item.location, item.code, item.quantity,
            item.cert_start_date, item.cert_end_date, item.certificate_number, item.comment,
            item.contract_number, item.contractor, item.responsible,
            item.days_left(today), item.status,
        ]


def data_protection_rows(items, type_labels):
    for item in items:
        yield [
            item.row_number, type_labels.get(item.backup_type, item.backup_type),
            item.system_name, item.reserved_information, item.max_volume_gb,
            item.procedure_frequency, item.retention_period, item.notes, item.responsible_person,
        ]
