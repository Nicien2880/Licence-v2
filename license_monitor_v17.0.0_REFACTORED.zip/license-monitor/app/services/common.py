from __future__ import annotations

from sqlalchemy.orm import Session

from ..models import ChangeLog


def log_change(
    db: Session,
    section: str,
    record_id: int | None,
    action: str,
    description: str,
    actor: str = "web",
) -> None:
    """Добавляет запись в журнал. Commit остаётся за вызывающим кодом."""
    db.add(ChangeLog(
        section=section, record_id=record_id, action=action,
        description=description, actor=actor,
    ))


def distinct_values(db: Session, column) -> list[str]:
    """Уникальные непустые значения колонки, отсортированные."""
    rows = db.query(column).distinct().order_by(column).all()
    return [row[0] for row in rows if row[0]]


def distinct_responsibles(db: Session, model) -> list[str]:
    """Ответственные по модели.

    HardwareSupport / SoftwareLicense / BackupObject используют поле `responsible`,
    DataProtectionPolicy — `responsible_person`.
    """
    column = getattr(model, "responsible", None) or getattr(model, "responsible_person", None)
    if column is None:
        return []
    return distinct_values(db, column)
