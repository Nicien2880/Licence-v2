"""Мониторинг объектов резервного копирования."""
from __future__ import annotations

from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..models import BackupObject

BACKUP_STATUSES = ["success", "warning", "failed", "running", "unknown"]


def backup_query(
    db: Session,
    q: str | None = None,
    status: str | None = None,
    responsible: str | None = None,
) -> list[BackupObject]:
    query = db.query(BackupObject)
    if q:
        pattern = f"%{q.strip()}%"
        query = query.filter(or_(
            BackupObject.object_name.ilike(pattern),
            BackupObject.object_type.ilike(pattern),
            BackupObject.platform.ilike(pattern),
            BackupObject.storage.ilike(pattern),
            BackupObject.policy_name.ilike(pattern),
            BackupObject.responsible.ilike(pattern),
            BackupObject.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(BackupObject.status == status)
    if responsible:
        query = query.filter(BackupObject.responsible == responsible)
    return query.order_by(
        BackupObject.last_backup_at.desc().nullslast(), BackupObject.object_name.asc()
    ).all()


def backup_stats(items: list[BackupObject]) -> dict:
    counters = {name: 0 for name in BACKUP_STATUSES}
    for item in items:
        if item.status in counters:
            counters[item.status] += 1
    total = len(items)
    return {
        "total": total,
        **counters,
        "health": round(counters["success"] / total * 100, 1) if total else 0,
    }


def backup_platform_stats(items: list[BackupObject]) -> list[dict]:
    result: dict[str, dict] = {}
    for item in items:
        key = item.platform or "manual"
        row = result.setdefault(
            key, {"platform": key, "total": 0, **{name: 0 for name in BACKUP_STATUSES}}
        )
        row["total"] += 1
        if item.status in row:
            row[item.status] += 1
    rows = list(result.values())
    for row in rows:
        row["success_percent"] = round(row["success"] / row["total"] * 100, 1) if row["total"] else 0
    rows.sort(key=lambda x: x["total"], reverse=True)
    return rows


def backup_type_stats(items: list[BackupObject]) -> list[dict]:
    counters: dict[str, int] = {}
    for item in items:
        key = item.object_type or "other"
        counters[key] = counters.get(key, 0) + 1
    return [
        {"type": key, "count": value}
        for key, value in sorted(counters.items(), key=lambda x: x[1], reverse=True)
    ]


def backup_to_api(item: BackupObject) -> dict:
    return {
        "id": item.id,
        "object_name": item.object_name,
        "object_type": item.object_type,
        "platform": item.platform,
        "last_backup_at": item.last_backup_at,
        "next_backup_at": item.next_backup_at,
        "size_gb": item.size_gb,
        "storage": item.storage,
        "retention_days": item.retention_days,
        "duration_min": item.duration_min,
        "policy_name": item.policy_name,
        "responsible": item.responsible,
        "status": item.status,
        "comment": item.comment,
        "hours_since_backup": item.hours_since_backup(),
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }
