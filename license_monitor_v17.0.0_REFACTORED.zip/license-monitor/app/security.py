"""Middleware безопасности: CSRF, лимит размера тела, security-заголовки."""
from __future__ import annotations

import logging
from urllib.parse import urlparse

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import PlainTextResponse, Response

from .settings import Settings

logger = logging.getLogger(__name__)

SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}
# Машинные клиенты ходят по API-ключу и не имеют Origin — форма CSRF к ним неприменима.
CSRF_EXEMPT_PREFIXES = ("/api/", "/metrics", "/health")


class CSRFMiddleware(BaseHTTPMiddleware):
    """Проверка источника для небезопасных методов.

    Все изменяющие операции в приложении — это обычные HTML-формы с cookie-сессией.
    Токен в каждой форме потребовал бы правки всех шаблонов; проверка Origin/Referer
    даёт сопоставимую защиту (в связке с SameSite=Lax) и не трогает разметку.

    Запрос отклоняется, если источник указан и не совпадает с Host, либо если
    источник вовсе отсутствует у браузерного запроса.
    """

    def __init__(self, app, settings: Settings):
        super().__init__(app)
        self.settings = settings

    @staticmethod
    def _host_of(value: str | None) -> str | None:
        if not value:
            return None
        parsed = urlparse(value)
        return parsed.netloc.lower() or None

    def _allowed_hosts(self, request: Request) -> set[str]:
        allowed = set(self.settings.trusted_origin_hosts)
        host_header = request.headers.get("host")
        if host_header:
            allowed.add(host_header.lower())
        return allowed

    async def dispatch(self, request: Request, call_next) -> Response:
        if (
            not self.settings.csrf_protection
            or request.method in SAFE_METHODS
            or request.url.path.startswith(CSRF_EXEMPT_PREFIXES)
        ):
            return await call_next(request)

        origin = self._host_of(request.headers.get("origin"))
        referer = self._host_of(request.headers.get("referer"))
        source = origin or referer

        if source is None:
            logger.warning("CSRF: запрос %s без Origin и Referer отклонён", request.url.path)
            return PlainTextResponse(
                "Запрос отклонён: не указан источник (Origin/Referer). "
                "Если вы работаете через прокси, добавьте его домен в TRUSTED_ORIGINS.",
                status_code=403,
            )
        if source not in self._allowed_hosts(request):
            logger.warning("CSRF: чужой источник %s для %s", source, request.url.path)
            return PlainTextResponse("Запрос отклонён: недопустимый источник.", status_code=403)

        return await call_next(request)


class MaxBodySizeMiddleware(BaseHTTPMiddleware):
    """Отсечка по Content-Length до чтения тела.

    Импорт Excel/Word читает файл целиком в память; без лимита один большой
    файл кладёт процесс.
    """

    def __init__(self, app, max_bytes: int):
        super().__init__(app)
        self.max_bytes = max_bytes

    async def dispatch(self, request: Request, call_next) -> Response:
        content_length = request.headers.get("content-length")
        if content_length and content_length.isdigit() and int(content_length) > self.max_bytes:
            return PlainTextResponse(
                f"Файл слишком большой. Лимит: {self.max_bytes // (1024 * 1024)} МБ.",
                status_code=413,
            )
        return await call_next(request)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Базовые защитные заголовки.

    CSP намеренно допускает inline-стили и скрипты: шаблоны и app.js используют
    их повсеместно, а переписывание разметки выходит за рамки задачи.
    Внешние источники при этом запрещены.
    """

    CSP = (
        "default-src 'self'; "
        "img-src 'self' data:; "
        "style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; "
        "form-action 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'"
    )

    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault("Content-Security-Policy", self.CSP)
        return response
