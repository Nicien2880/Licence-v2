"""Версионированные миграции схемы.

Заменяет прежний ensure_schema(), который вслепую проверял пару колонок и
не помнил, что уже применено. Здесь каждый шаг имеет номер, применяется
ровно один раз и записывается в таблицу schema_migrations.

Почему не Alembic: для одного SQLite-файла и линейной истории он избыточен,
а его автогенерация под SQLite всё равно требует batch-режима. Если проект
переедет на PostgreSQL — переход прямой: текущее состояние фиксируется как
базовая ревизия, дальше alembic revision --autogenerate.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection, Engine

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    apply: Callable[[Connection], None]


def _columns(conn: Connection, table: str) -> set[str]:
    inspector = inspect(conn)
    if table not in inspector.get_table_names():
        return set()
    return {column["name"] for column in inspector.get_columns(table)}


def _add_column_if_missing(conn: Connection, table: str, column: str, ddl_type: str) -> None:
    existing = _columns(conn, table)
    if not existing or column in existing:
        return
    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl_type}"))
    logger.info("Миграция: добавлена колонка %s.%s", table, column)


def _m001_legacy_columns(conn: Connection) -> None:
    """Колонки, которые раньше добавлял ensure_schema() на лету."""
    _add_column_if_missing(conn, "hardware_support", "manufacturer", "VARCHAR(255)")
    _add_column_if_missing(conn, "software_licenses", "location", "VARCHAR(255)")
    _add_column_if_missing(conn, "software_licenses", "group_name", "VARCHAR(255)")


def _m002_session_version(conn: Connection) -> None:
    """Счётчик версии сессии для принудительного разлогина."""
    _add_column_if_missing(conn, "users", "session_version", "INTEGER NOT NULL DEFAULT 1")


def _m003_serial_normalized(conn: Connection) -> None:
    """Нормализованный серийный номер + индекс, с обратным заполнением."""
    if "hardware_support" not in inspect(conn).get_table_names():
        return
    _add_column_if_missing(conn, "hardware_support", "serial_normalized", "VARCHAR(255)")
    # UPPER/REPLACE есть и в SQLite, и в PostgreSQL — обходимся без Python-цикла.
    conn.execute(text(
        "UPDATE hardware_support "
        "SET serial_normalized = NULLIF(UPPER(REPLACE(REPLACE(REPLACE("
        "  COALESCE(serial_number, ''), ' ', ''), CHAR(9), ''), CHAR(10), '')), '') "
        "WHERE serial_normalized IS NULL"
    ))
    conn.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_hardware_support_serial_normalized "
        "ON hardware_support (serial_normalized)"
    ))


def _m004_changelog_index(conn: Connection) -> None:
    """Составной индекс под основной запрос истории (сортировка по дате)."""
    if "change_log" not in inspect(conn).get_table_names():
        return
    conn.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_change_log_section_created "
        "ON change_log (section, created_at)"
    ))


MIGRATIONS: list[Migration] = [
    Migration(1, "legacy_columns", _m001_legacy_columns),
    Migration(2, "user_session_version", _m002_session_version),
    Migration(3, "hardware_serial_normalized", _m003_serial_normalized),
    Migration(4, "change_log_index", _m004_changelog_index),
]


def _ensure_version_table(conn: Connection) -> None:
    conn.execute(text(
        "CREATE TABLE IF NOT EXISTS schema_migrations ("
        " version INTEGER PRIMARY KEY,"
        " name VARCHAR(255) NOT NULL,"
        " applied_at TIMESTAMP NOT NULL"
        ")"
    ))


def applied_versions(conn: Connection) -> set[int]:
    _ensure_version_table(conn)
    rows = conn.execute(text("SELECT version FROM schema_migrations")).fetchall()
    return {row[0] for row in rows}


def run_migrations(engine: Engine) -> list[str]:
    """Применяет недостающие миграции. Возвращает имена применённых."""
    from .core.parsing import utcnow

    applied: list[str] = []
    with engine.begin() as conn:
        done = applied_versions(conn)
        for migration in sorted(MIGRATIONS, key=lambda m: m.version):
            if migration.version in done:
                continue
            migration.apply(conn)
            conn.execute(
                text(
                    "INSERT INTO schema_migrations (version, name, applied_at) "
                    "VALUES (:version, :name, :applied_at)"
                ),
                {
                    "version": migration.version,
                    "name": migration.name,
                    "applied_at": utcnow().isoformat(),
                },
            )
            applied.append(f"{migration.version:03d}_{migration.name}")
    if applied:
        logger.info("Применены миграции: %s", ", ".join(applied))
    return applied
