"""Объекты уровня процесса, общие для роутеров."""
from __future__ import annotations

from pathlib import Path

from .services.importing import PreviewStore

PREVIEW_DIR = Path.cwd() / "data" / "import_previews"

# Черновики импорта Data Protection: пользователь сначала видит предпросмотр,
# затем подтверждает запись в базу.
preview_store = PreviewStore(PREVIEW_DIR)
