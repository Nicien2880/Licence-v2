"""Точка входа License Monitor.

Раньше здесь лежало 1800 строк: модели запросов, парсеры, HTML-страницы, API и
экспорт вперемешку. Теперь модуль только собирает приложение из роутеров и
управляет жизненным циклом; логика живёт в app/services и app/core.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from .auth import create_initial_admin_if_needed
from .database import Base, engine, session_scope
from .deps import BASE_DIR, LoginRedirect, templates
from .migrations import run_migrations
from .security import CSRFMiddleware, MaxBodySizeMiddleware, SecurityHeadersMiddleware
from .services.inventory import refresh_statuses
from .settings import get_settings
from .state import preview_store

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
)
logger = logging.getLogger("license_monitor")

settings = get_settings()


async def _status_refresh_loop() -> None:
    """Периодический пересчёт статусов.

    Статус — производная от даты окончания, поэтому меняется не чаще раза в сутки.
    Пересчёт по таймеру позволяет держать HTTP-обработчики чистыми на чтение.
    """
    interval = max(settings.status_refresh_minutes, 1) * 60
    while True:
        await asyncio.sleep(interval)
        try:
            with session_scope() as db:
                refresh_statuses(db)
            preview_store.purge_expired()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Фоновый пересчёт статусов завершился ошибкой")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Конфигурация: небезопасные значения роняют старт, а не всплывают через полгода.
    for warning in settings.validate_runtime():
        logger.warning("Конфигурация: %s", warning)

    # 2. Схема: create_all создаёт недостающие таблицы, миграции доводят существующие.
    Base.metadata.create_all(bind=engine)
    applied = run_migrations(engine)
    if applied:
        logger.info("Схема обновлена: %s", ", ".join(applied))

    # 3. Первичный администратор и стартовый пересчёт.
    with session_scope() as db:
        if create_initial_admin_if_needed(db):
            logger.info("Создан первичный администратор: %s", settings.initial_admin_username)
        refresh_statuses(db)

    removed = preview_store.purge_expired()
    if removed:
        logger.info("Удалено устаревших черновиков импорта: %d", removed)

    task = None
    if settings.status_refresh_minutes > 0:
        task = asyncio.create_task(_status_refresh_loop())
        logger.info("Фоновый пересчёт статусов: каждые %d мин.", settings.status_refresh_minutes)

    logger.info("%s запущен", settings.app_name)
    try:
        yield
    finally:
        if task is not None:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        logger.info("%s остановлен", settings.app_name)


app = FastAPI(
    title=settings.app_name,
    lifespan=lifespan,
    docs_url=None,       # схема API не должна быть доступна анонимно
    redoc_url=None,
    openapi_url=None,
)

app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CSRFMiddleware, settings=settings)
app.add_middleware(MaxBodySizeMiddleware, max_bytes=settings.max_upload_bytes)

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

# Роутеры подключаются после middleware; порядок между собой значения не имеет,
# т.к. пути не пересекаются.
from .routers import admin, api, auth, backup_monitor, data_protection, inventory  # noqa: E402

app.include_router(auth.router)
app.include_router(inventory.router)
app.include_router(backup_monitor.router)
app.include_router(data_protection.router)
app.include_router(admin.router)
app.include_router(api.router)
app.include_router(api.public_router)


@app.exception_handler(LoginRedirect)
async def login_redirect_handler(request: Request, exc: LoginRedirect):
    """Аноним на защищённой странице отправляется на форму входа, а не на 401."""
    next_url = request.url.path
    if request.url.query:
        next_url = f"{next_url}?{request.url.query}"
    return RedirectResponse(url="/login", status_code=303, headers={"X-Next": next_url})


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Понятная страница ошибки для браузера, JSON — для API-клиентов."""
    wants_json = (
        request.url.path.startswith(("/api/", "/metrics", "/health"))
        or "application/json" in request.headers.get("accept", "")
    )
    if wants_json:
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    if exc.status_code == 401:
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context={
            "app_name": settings.app_name,
            "status_code": exc.status_code,
            "detail": exc.detail,
            "current_user": None,
        },
        status_code=exc.status_code,
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Внутренние ошибки логируются целиком, наружу уходит нейтральный текст."""
    logger.exception("Необработанная ошибка на %s %s", request.method, request.url.path)
    if request.url.path.startswith(("/api/", "/metrics", "/health")):
        return JSONResponse({"detail": "Internal server error"}, status_code=500)
    return HTMLResponse(
        "<h1>500</h1><p>Внутренняя ошибка сервера. Подробности записаны в журнал.</p>",
        status_code=500,
    )
