"""Общие зависимости роутеров: шаблоны, контекст страниц, вспомогательные редиректы."""
from __future__ import annotations

from pathlib import Path

from fastapi import Depends, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .auth import get_current_user, user_can
from .core.parsing import format_dt_for_input, format_volume
from .core.status import STATUS_LABELS
from .database import get_db
from .models import User
from .settings import get_settings

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Хелперы, доступные во всех шаблонах, чтобы не прокидывать их в каждый контекст.
templates.env.globals.update(
    format_volume=format_volume,
    format_dt_for_input=format_dt_for_input,
    status_labels=STATUS_LABELS,
)


class LoginRedirect(Exception):
    """Страница требует входа: анонима отправляем на форму, а не отдаём 401."""


def page_user(request: Request, db: Session = Depends(get_db)) -> User:
    """Зависимость для HTML-страниц: возвращает пользователя либо бросает LoginRedirect."""
    user = get_current_user(request, db)
    if user is None:
        raise LoginRedirect()
    return user


def base_context(request: Request, current_user: User | None, **extra) -> dict:
    """Базовый контекст: имя приложения, пользователь и флаги прав."""
    context = {
        "app_name": get_settings().app_name,
        "current_user": current_user,
        "can_edit": user_can(current_user, "editor"),
        "can_manage": user_can(current_user, "manager"),
        "can_admin": user_can(current_user, "admin"),
    }
    context.update(extra)
    return context


def redirect(url: str) -> RedirectResponse:
    """303 после POST: предотвращает повторную отправку формы по F5."""
    return RedirectResponse(url=url, status_code=303)
