# Чек-лист перед вводом в эксплуатацию

Пройдите сверху вниз. Пункты 1–5 обязательны.

## 1. Секреты

- [ ] `SESSION_SECRET` сгенерирован (`docker compose run --rm license-monitor gen-secret`)
- [ ] `INITIAL_ADMIN_PASSWORD` задан и отличается от примеров
- [ ] `ZABBIX_API_KEY` задан и передан в Zabbix/Prometheus
- [ ] Файл `.env` не в git (`git check-ignore .env` должен вернуть `.env`)
- [ ] Права на `.env`: `chmod 600 .env`

Приложение не запустится, если пункты 1–3 не выполнены. Это ожидаемое поведение.

## 2. TLS

- [ ] Сертификат положен в `deploy/certs/`
- [ ] `COOKIE_SECURE=true` в `.env`
- [ ] `TRUSTED_ORIGINS` содержит внешний домен, если он отличается от `Host`
- [ ] Проверено, что HTTP редиректит на HTTPS

## 3. Сетевой доступ

- [ ] В `deploy/nginx-license-monitor.conf` подсети для `/api` и `/metrics`
      заменены на реальные адреса мониторинга
- [ ] Порт 8000 не опубликован наружу (в compose он привязан к `127.0.0.1`)
- [ ] Проверено: `curl https://<домен>/api/zabbix/summary` без ключа даёт 401

## 4. Данные

- [ ] `sudo chown -R 1001:1001 data`
- [ ] `docker compose ps` показывает `healthy`
- [ ] Создана и скачана пробная резервная копия через `/admin/backups`
- [ ] Проверено восстановление из копии на тестовом стенде
- [ ] Настроено внешнее резервное копирование каталога `data/`

## 5. Учётные записи

- [ ] Пароль первичного администратора сменён после первого входа
- [ ] Заведены рабочие учётные записи с минимально необходимыми ролями
- [ ] Проверено, что `viewer` не видит кнопок удаления и импорта

## 6. Эксплуатация

- [ ] Настроена ежедневная рассылка (`--profile tools run --rm notify`)
- [ ] В Zabbix заведены триггеры на `total_expired` и `total_urgent`
- [ ] Логи собираются (`docker compose logs` или journald)
- [ ] Прогон тестов после каждого обновления:
      `docker compose --profile tools run --rm tests`

## Быстрая проверка после запуска

```bash
curl -fsS http://127.0.0.1:8000/health                    # 200, database: ok
curl -si  http://127.0.0.1:8000/api/licenses | head -1     # 401 без ключа
curl -si -X POST -H "Origin: http://evil.local" \
     http://127.0.0.1:8000/logout | head -1                # 403, CSRF
docker compose logs license-monitor | grep -i "Конфигурация"
```
