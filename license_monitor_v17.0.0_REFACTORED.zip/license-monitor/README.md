# License Monitor

Внутренний веб-сервис для контроля сроков техподдержки оборудования, лицензий ПО
и состояния резервного копирования.

**Версия 17.0.0** — рефакторинг v16.50.1: разбиение монолита, исправление
критичных дефектов, тесты, безопасная упаковка в Docker.
Полный перечень изменений — в [CHANGELOG.md](CHANGELOG.md).

---

## Возможности

| Раздел | Путь | Назначение |
|---|---|---|
| Техподдержка оборудования | `/?section=hardware` | Сроки ТП, серийники, договоры, контрагенты |
| Лицензии ПО | `/?section=software` | Сертификаты, количество, сроки действия |
| Мониторинг бэкапов | `/backup-monitor` | Факт и давность копий по объектам |
| Data Protection | `/data-protection` | План резервирования ИС, heatmap расписаний |
| История изменений | `/history` | Журнал операций |
| Пользователи | `/admin/users` | Управление доступом |
| Резервные копии базы | `/admin/backups` | Создание и выгрузка копий SQLite |

Статусы считаются от даты окончания: `expired` → `urgent` → `critical` →
`warning` → `active`. Пороги задаются в `.env` и **действительно применяются**
(в v16 они игнорировались, значения были захардкожены).

---

## Быстрый старт в Docker

```bash
# 1. Конфигурация
cp .env.example .env

# 2. Секрет сессии (обязателен, иначе приложение не стартует)
docker compose run --rm license-monitor gen-secret
# полученную строку впишите в SESSION_SECRET

# 3. Заполните также INITIAL_ADMIN_PASSWORD и ZABBIX_API_KEY

# 4. Права на каталог данных: контейнер работает от UID 1001
mkdir -p data && sudo chown -R 1001:1001 data

# 5. Запуск
docker compose up -d --build

# 6. Проверка
curl -fsS http://127.0.0.1:8000/health
docker compose ps        # столбец STATUS должен показать healthy
```

Интерфейс: `http://127.0.0.1:8000/`, вход под `INITIAL_ADMIN_USERNAME`.

### С TLS через nginx

```bash
# Самоподписанный сертификат для проверки
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout deploy/certs/server.key -out deploy/certs/server.crt \
  -subj "/CN=license-monitor"

# В .env: COOKIE_SECURE=true и TRUSTED_ORIGINS=<ваш домен>
docker compose --profile proxy up -d
```

Перед вводом в эксплуатацию поправьте в `deploy/nginx-license-monitor.conf`
список подсетей, которым разрешён доступ к `/api` и `/metrics`.

### Прочие команды

```bash
docker compose --profile tools run --rm tests     # прогон тестов
docker compose --profile tools run --rm notify    # разовая рассылка писем
docker compose logs -f license-monitor            # логи
docker compose exec license-monitor sh            # оболочка в контейнере
```

---

## Запуск без Docker

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # заполнить SESSION_SECRET, пароль, API-ключ
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Для продуктивного стенда используйте `deploy/license-monitor.service` и
`deploy/nginx-license-monitor.conf`.

---

## Обязательные настройки

Приложение **намеренно падает на старте**, если найдено небезопасное значение.
Это заменяет прежнее поведение, при котором сервис молча работал с публично
известным секретом.

| Переменная | Требование |
|---|---|
| `SESSION_SECRET` | Не пустой, минимум 32 символа, не значение по умолчанию |
| `INITIAL_ADMIN_PASSWORD` | Не пустой, не из списка известных |
| `ZABBIX_API_KEY` | Задан, либо явно выставлен `ALLOW_UNAUTHENTICATED_API=true` |
| `URGENT_DAYS ≤ CRITICAL_DAYS ≤ WARNING_DAYS` | Пороги должны возрастать |

Предупреждения (старт не блокируют) выводятся в лог: например,
`COOKIE_SECURE=false` при работе через HTTP.

---

## Роли

```
viewer   просмотр
editor   viewer + добавление и редактирование
manager  editor + удаление, импорт и экспорт
admin    manager + пользователи и резервные копии базы
```

Смена пароля, смена роли и деактивация немедленно обрывают все активные сессии
пользователя.

---

## API

Все эндпоинты `/api/*` и `/metrics` требуют заголовок `X-API-Key`
(либо query-параметр `api_key`).

```
GET /api/licenses[?section=hardware|software]
GET /api/licenses/expiring?days=30[&section=...]
GET /api/hardware-support           GET /api/hardware-support/{id}
GET /api/software-licenses          GET /api/software-licenses/{id}
GET /api/backup-monitor             GET /api/backup-monitor/summary
GET /api/data-protection/plan       GET /api/data-protection/summary
GET /api/monitoring/summary
GET /api/zabbix/summary
GET /metrics                        (Prometheus text exposition)
GET /health                         (без ключа; делает SELECT 1 к базе)
```

```bash
curl -H "X-API-Key: $ZABBIX_API_KEY" http://127.0.0.1:8000/api/zabbix/summary
```

### Zabbix

Master item типа HTTP agent на `/api/zabbix/summary` с заголовком `X-API-Key`,
интервал 5–10 мин, тип информации Text. Далее dependent items через JSONPath:

```
$.total_expired         → license_monitor.total.expired
$.total_urgent          → license_monitor.total.urgent
$.hardware_critical     → license_monitor.hardware.critical
$.backup_health         → license_monitor.backup.health
```

Триггеры:

```
last(/License Monitor/license_monitor.total.expired)>0   → High
last(/License Monitor/license_monitor.total.urgent)>0    → Average
last(/License Monitor/license_monitor.total.critical)>0  → Warning
```

### Prometheus

`/metrics` отдаёт метрики с метками и блоками `HELP`/`TYPE`:

```
license_monitor_records{section="hardware",status="expired"} 3
license_monitor_backup{state="health"} 92.5
license_monitor_data_protection{metric="volume_gb"} 41216
```

---

## Импорт и экспорт

**Инвентарь** (`/export.xlsx`, `/import.xlsx`) — Excel с заголовками в первой
строке. Распознаются синонимы колонок (`Договор` / `Номер договора`,
`Ответственный` / `Описание`).

После импорта открывается отчёт: сколько строк загружено, сколько пропущено и
**почему именно** каждая проблемная строка не прошла. Раньше такие строки
исчезали молча.

**Data Protection** (`/data-protection`) — Excel и Word (`.docx`) с обязательным
предпросмотром перед записью. Порядок колонок:

```
№ | Тип backup | Наименование ИС | Информация, подлежащая резервированию |
Максимальный объём, ГБ | Периодичность | Срок хранения | Примечания | Ответственный
```

Тип backup принимается как `filesystem` / `internal_database` /
`ms_sql_server` / `virtual_environment` или в читаемом виде.
В Word-документах строки-заголовки блоков распознаются автоматически.

---

## Резервные копии базы

Создание и выгрузка — `/admin/backups` (только `admin`). Копия снимается через
`sqlite3.backup()`, то есть корректна и при активных записях.

Восстановление сознательно не вынесено в интерфейс:

```bash
docker compose stop license-monitor
cp data/backups/license_monitor_backup_YYYYMMDD_HHMMSS_admin.db data/licenses.db
docker compose start license-monitor
```

---

## Уведомления

`jobs/notify_email.py` собирает записи с истекающими сроками и отправляет письмо.

```bash
# cron на хосте, ежедневно в 09:00
0 9 * * * cd /opt/license-monitor && docker compose --profile tools run --rm notify
```

Без Docker — `deploy/license-monitor-notify.timer`.

---

## Архитектура

```
app/
├── main.py            сборка приложения, lifespan, обработчики ошибок
├── settings.py        конфигурация и её валидация
├── database.py        engine, сессии, PRAGMA для SQLite
├── models.py          ORM-модели
├── migrations.py      версионированные миграции схемы
├── auth.py            пароли, сессии, роли, троттлинг входа
├── security.py        middleware: CSRF, лимит тела, заголовки
├── deps.py            шаблоны и общие зависимости роутеров
├── state.py           объекты уровня процесса
├── core/              чистая логика без внешних зависимостей
│   ├── parsing.py     даты, числа, объёмы, серийники
│   ├── status.py      расчёт статусов по порогам
│   └── schedule.py    разбор периодичности, heatmap
├── services/          работа с данными
│   ├── inventory.py   оборудование и ПО
│   ├── backup_monitor.py
│   ├── data_protection.py
│   ├── importing.py   разбор Excel/Word, предпросмотр
│   ├── exporting.py   генерация Excel
│   ├── db_backup.py   копии SQLite
│   └── common.py      журнал, справочники
└── routers/           HTTP-слой
    ├── auth.py  inventory.py  backup_monitor.py
    ├── data_protection.py  admin.py  api.py
```

Слои `core` и `services` не импортируют FastAPI, поэтому логику можно
тестировать и переиспользовать вне веб-приложения.

### Схема развёртывания

```
Browser ──HTTPS──> nginx :443 ──> uvicorn 127.0.0.1:8000 ──> SQLite (WAL)
Zabbix  ──X-API-Key──> /api/zabbix/summary
```

---

## Тесты

```bash
docker compose --profile tools run --rm tests
# или локально
pytest
```

Покрыты: расчёт статусов и границы порогов, парсинг дат/объёмов/серийников,
разбор расписаний резервного копирования (склонения дней недели, AM/PM,
приоритет периодичностей, построение heatmap).

---

## Миграции схемы

Применяются автоматически при старте, история — в таблице `schema_migrations`.
Новый шаг добавляется в `MIGRATIONS` в `app/migrations.py`:

```python
def _m005_new_column(conn):
    _add_column_if_missing(conn, "hardware_support", "asset_tag", "VARCHAR(64)")

MIGRATIONS.append(Migration(5, "hardware_asset_tag", _m005_new_column))
```

Каждый шаг применяется однократно и обязан быть идемпотентным.

---

## Известные ограничения

- **Один воркер.** SQLite плохо переносит параллельную запись, а счётчик
  неудачных входов хранится в памяти процесса. Для горизонтального
  масштабирования нужны PostgreSQL и Redis.
- **CSRF через Origin/Referer**, а не через токен в форме. Работает в связке с
  `SameSite=Lax`. Если приложение стоит за прокси, который не передаёт `Host`,
  заполните `TRUSTED_ORIGINS`.
- **CSP допускает inline-стили и скрипты** — этого требуют текущие шаблоны.
- **Черновики импорта** лежат в `data/import_previews/` и удаляются через 24 часа.

---

## Обновление с v16

```bash
# 1. Копия текущего состояния
cp -r /opt/license_monitor /opt/license_monitor_backup_$(date +%F)

# 2. Развернуть новую версию, перенести data/licenses.db

# 3. Заполнить новые обязательные поля .env:
#    SESSION_SECRET, INITIAL_ADMIN_PASSWORD, ZABBIX_API_KEY

# 4. Запуск — миграции применятся автоматически
docker compose up -d --build
docker compose logs license-monitor | head -40
```

Данные сохраняются: миграции только добавляют колонки
(`serial_normalized`, `session_version`) и индексы.

**Важно:** после обновления все пользователи будут разлогинены — изменилась
схема токена сессии. Интеграции перестанут работать, пока в них не будет
прописан `X-API-Key`.
