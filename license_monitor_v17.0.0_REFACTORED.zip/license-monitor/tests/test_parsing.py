from datetime import date, datetime, timezone

import pytest

from app.core.parsing import (
    clean_cell,
    format_volume,
    normalize_serial,
    parse_bool,
    parse_date,
    parse_date_safe,
    parse_datetime_local,
    parse_int,
    parse_volume_gb,
    utcnow,
)


@pytest.mark.parametrize("value,expected", [
    ("2026-05-22", date(2026, 5, 22)),
    ("2026-05-22T10:30:00", date(2026, 5, 22)),
    ("22.05.2026", date(2026, 5, 22)),
    (date(2026, 5, 22), date(2026, 5, 22)),
    (datetime(2026, 5, 22, 3, 0), date(2026, 5, 22)),
    (None, None),
    ("", None),
])
def test_parse_date(value, expected):
    assert parse_date(value) == expected


def test_parse_date_raises_on_garbage():
    """Прежняя версия роняла date.fromisoformat необработанным ValueError."""
    with pytest.raises(ValueError):
        parse_date("не дата")


def test_parse_date_safe_swallows_error():
    assert parse_date_safe("не дата") is None


@pytest.mark.parametrize("value,expected", [
    ("42", 42), (7, 7), ("", None), (None, None), ("abc", None), ("  15  ", 15),
])
def test_parse_int(value, expected):
    assert parse_int(value) == expected


@pytest.mark.parametrize("value", ["1", "true", "YES", "да", "on", True])
def test_parse_bool_true(value):
    assert parse_bool(value) is True


@pytest.mark.parametrize("value", ["0", "false", "нет", "", None, False, "maybe"])
def test_parse_bool_false(value):
    assert parse_bool(value) is False


@pytest.mark.parametrize("value,expected", [
    ("100", 100),
    ("100 ГБ", 100),
    ("2 ТБ", 2048),
    ("1,5 ТБ", 1536),
    ("2 TB", 2048),
    ("", None),
    (None, None),
    ("нет данных", None),
])
def test_parse_volume_gb(value, expected):
    assert parse_volume_gb(value) == expected


def test_parse_volume_megabytes_rounds_up_to_one_gb():
    assert parse_volume_gb("200 МБ") == 1


@pytest.mark.parametrize("value,expected", [
    (None, ""), (100, "100 ГБ"), (1024, "1 ТБ"), (1536, "1.50 ТБ"),
])
def test_format_volume(value, expected):
    assert format_volume(value) == expected


def test_volume_roundtrip_is_stable():
    for gb in (1, 100, 1024, 5120):
        assert parse_volume_gb(format_volume(gb)) == gb


@pytest.mark.parametrize("value,expected", [
    ("  ab 12 ", "AB12"),
    ("ab-12", "AB-12"),
    (None, ""),
    ("\tSN\n001", "SN001"),
])
def test_normalize_serial(value, expected):
    assert normalize_serial(value) == expected


def test_clean_cell_collapses_whitespace_and_nbsp():
    assert clean_cell("  a\u00a0 b\n c ") == "a b c"


def test_parse_datetime_local_returns_aware():
    parsed = parse_datetime_local("2026-05-22T03:00")
    assert parsed == datetime(2026, 5, 22, 3, 0, tzinfo=timezone.utc)
    assert parsed.tzinfo is not None


def test_parse_datetime_local_invalid_returns_none():
    assert parse_datetime_local("что-то не то") is None


def test_utcnow_is_timezone_aware():
    """datetime.utcnow() возвращал naive-время и объявлен deprecated в 3.12."""
    assert utcnow().tzinfo is not None
