import pytest

from app.core.status import Thresholds, calc_status, stats_for


class FakeItem:
    def __init__(self, days):
        self._days = days

    def days_left(self, _today):
        return self._days


DEFAULT = Thresholds()


@pytest.mark.parametrize("days,expected", [
    (-100, "expired"),
    (-1, "expired"),
    (0, "urgent"),
    (7, "urgent"),
    (8, "critical"),
    (30, "critical"),
    (31, "warning"),
    (60, "warning"),
    (61, "active"),
    (10_000, "active"),
])
def test_calc_status_boundaries(days, expected):
    assert calc_status(days, DEFAULT) == expected


def test_custom_thresholds_are_respected():
    """Настройки WARNING_DAYS/CRITICAL_DAYS/URGENT_DAYS в старой версии игнорировались."""
    strict = Thresholds(urgent_days=1, critical_days=3, warning_days=5)
    assert calc_status(1, strict) == "urgent"
    assert calc_status(2, strict) == "critical"
    assert calc_status(4, strict) == "warning"
    assert calc_status(6, strict) == "active"


def test_inconsistent_thresholds_rejected():
    with pytest.raises(ValueError):
        Thresholds(urgent_days=60, critical_days=30, warning_days=7)


def test_stats_counts_every_bucket():
    items = [FakeItem(d) for d in (-5, -1, 0, 3, 20, 45, 200)]
    stats = stats_for(items, today=None, thresholds=DEFAULT)
    assert stats == {
        "total": 7, "expired": 2, "urgent": 2,
        "critical": 1, "warning": 1, "active": 1,
    }


def test_stats_total_equals_sum_of_buckets():
    items = [FakeItem(d) for d in range(-10, 100)]
    stats = stats_for(items, today=None, thresholds=DEFAULT)
    buckets = sum(v for k, v in stats.items() if k != "total")
    assert buckets == stats["total"]
