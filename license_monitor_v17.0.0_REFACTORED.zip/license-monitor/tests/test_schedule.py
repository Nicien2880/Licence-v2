"""Тесты разбора поля «Периодичность проведения процедуры».

Это самый хрупкий алгоритм проекта: 200 строк эвристик по русским склонениям.
До сих пор он не был покрыт ничем, и любая правка шла вслепую.
"""
import pytest

from app.core.schedule import (
    DAY_ALIASES,
    detect_cadence,
    detect_days,
    detect_modes,
    extract_hours,
    heat_bucket,
    normalize_backup_type,
    normalize_text,
    schedule_stats,
)


class Policy:
    def __init__(self, frequency, system_name="ИС", backup_type="filesystem", row_number=1, id=1):
        self.procedure_frequency = frequency
        self.system_name = system_name
        self.backup_type = backup_type
        self.row_number = row_number
        self.id = id


# --------------------------------------------------------------------------- #
# Тип backup
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("value,expected", [
    ("filesystem", "filesystem"),
    ("Filesystem", "filesystem"),
    ("MS SQL Server", "ms_sql_server"),
    ("mssql", "ms_sql_server"),
    ("Virtual Environment", "virtual_environment"),
    ("vm", "virtual_environment"),
    ("internal database", "internal_database"),
    (None, "filesystem"),
    ("нечто неизвестное", "filesystem"),
])
def test_normalize_backup_type(value, expected):
    assert normalize_backup_type(value) == expected


# --------------------------------------------------------------------------- #
# Часы
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("text,expected", [
    ("запуск в 02:00", [2]),
    ("02.00 и 14:30", [2, 14]),
    ("8:00 pm", [20]),
    ("12:15 am", [0]),
    ("12:15 pm", [12]),
    ("23:59", [23]),
    ("без времени", []),
])
def test_extract_hours(text, expected):
    assert extract_hours(normalize_text(text)) == expected


def test_extract_hours_ignores_invalid_time():
    assert extract_hours(normalize_text("в 25:00 и 07:61")) == []


# --------------------------------------------------------------------------- #
# Дни недели
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("text,expected", [
    ("по понедельникам", ["mon"]),
    ("вторник и четверг", ["tue", "thu"]),
    ("каждую субботу", ["sat"]),
    ("воскресенье", ["sun"]),
    ("saturday", ["sat"]),
    ("ежедневно", []),
])
def test_detect_days(text, expected):
    assert sorted(detect_days(normalize_text(text))) == sorted(expected)


def test_yo_is_normalized():
    """«четверг» пишут и через ё — normalize_text должен это сглаживать."""
    assert detect_days(normalize_text("по чётвергам")) == ["thu"]


# --------------------------------------------------------------------------- #
# Периодичность
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("text,expected", [
    ("ежедневно в 02:00", "daily"),
    ("через день", "daily"),
    ("2 раза в день", "multi_daily"),
    ("еженедельно по субботам", "weekly"),
    ("каждые 2 недели", "weekly"),
    ("раз в месяц", "monthly"),
    ("по мере необходимости", "unknown"),
])
def test_detect_cadence(text, expected):
    assert detect_cadence(normalize_text(text)) == expected


def test_multi_daily_wins_over_daily():
    """«2 раза в день» содержит признаки и того, и другого — приоритет важен."""
    assert detect_cadence(normalize_text("ежедневно, 2 раза в день")) == "multi_daily"


# --------------------------------------------------------------------------- #
# Тип копии
# --------------------------------------------------------------------------- #

def test_detect_modes():
    modes = detect_modes(normalize_text("Full backup по субботам, incremental в будни"))
    assert modes["full"] is True
    assert modes["incremental"] is True
    assert modes["differential"] is False


def test_detect_modes_russian():
    modes = detect_modes(normalize_text("полная копия, дифференциальная в среду"))
    assert modes["full"] is True
    assert modes["differential"] is True


# --------------------------------------------------------------------------- #
# Сводная аналитика
# --------------------------------------------------------------------------- #

def test_daily_policy_fills_whole_heatmap_row():
    stats = schedule_stats([Policy("Full ежедневно в 02:00")])
    for row in stats["heatmap"]["rows"]:
        cell = next(c for c in row["cells"] if c["hour"] == "02:00")
        assert cell["count"] == 1, f"день {row['label']} должен быть заполнен"
    assert stats["unparsed_count"] == 0


def test_weekly_policy_fills_only_named_day():
    stats = schedule_stats([Policy("Full еженедельно по субботам в 23:00")])
    counts = {
        row["label"]: next(c for c in row["cells"] if c["hour"] == "23:00")["count"]
        for row in stats["heatmap"]["rows"]
    }
    assert counts["Сб"] == 1
    assert sum(counts.values()) == 1


def test_empty_frequency_goes_to_unparsed():
    stats = schedule_stats([Policy(""), Policy(None)])
    assert stats["unparsed_count"] == 2
    assert all("пустое поле" in row["reason"] for row in stats["unparsed"])


def test_unparsed_reason_lists_all_problems():
    stats = schedule_stats([Policy("когда получится")])
    reason = stats["unparsed"][0]["reason"]
    assert "тип" in reason and "периодичность" in reason and "время" in reason


def test_peak_points_at_busiest_cell():
    items = [Policy("Full еженедельно по субботам в 23:00") for _ in range(3)]
    items.append(Policy("Full еженедельно по вторникам в 01:00"))
    stats = schedule_stats(items)
    assert stats["heatmap"]["peak"]["label"] == "Сб"
    assert stats["heatmap"]["peak"]["hour"] == "23:00"
    assert stats["heatmap"]["peak"]["count"] == 3


def test_counters_are_consistent():
    items = [
        Policy("Full ежедневно в 02:00"),
        Policy("Incremental по понедельникам и четвергам в 03:00"),
        Policy("Differential раз в месяц"),
        Policy(""),
    ]
    stats = schedule_stats(items)
    assert sum(row["count"] for row in stats["cadence"]) == len(items)
    assert len(stats["heatmap"]["rows"]) == len(DAY_ALIASES)
    assert len(stats["heatmap"]["hours"]) == 24


def test_empty_input_does_not_divide_by_zero():
    stats = schedule_stats([])
    assert stats["unparsed_count"] == 0
    assert stats["heatmap"]["max"] == 1
    assert all(cell["level"] == 0 for row in stats["heatmap"]["rows"] for cell in row["cells"])


@pytest.mark.parametrize("count,bucket", [
    (0, "empty"), (1, "low"), (5, "low"), (6, "medium"),
    (10, "medium"), (11, "high"), (20, "high"), (21, "peak"),
])
def test_heat_bucket(count, bucket):
    assert heat_bucket(count) == bucket
