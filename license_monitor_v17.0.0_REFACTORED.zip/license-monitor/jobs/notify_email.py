"""Email-уведомления о заканчивающихся сроках.

Запускается из cron или systemd timer раз в сутки.

Что было сломано в прежней версии:
  - скрипт читал /api/monitoring/summary и ожидал там ключ "items" со списком
    записей, но этот эндпоинт возвращает только агрегаты — письмо всегда
    уходило пустым или падало;
  - поля брались из модели v13 (product_name, target_system, end_date),
    которых в текущей схеме нет;
  - API-ключ не передавался, поэтому после включения ZABBIX_API_KEY скрипт
    получал 401.

Переменные окружения — см. .env.example (секция Email notifications).
Дополнительно:
  NOTIFY_DAYS=60          горизонт в днях
  NOTIFY_MIN_STATUS=warning   минимальный статус для попадания в письмо
"""
from __future__ import annotations

import json
import os
import smtplib
import sys
import urllib.error
import urllib.request
from email.message import EmailMessage
from html import escape

BASE_URL = os.getenv("LICENSE_MONITOR_URL", "http://127.0.0.1:8000").rstrip("/")
API_KEY = os.getenv("ZABBIX_API_KEY", "")
NOTIFY_DAYS = int(os.getenv("NOTIFY_DAYS", "60"))
NOTIFY_MIN_STATUS = os.getenv("NOTIFY_MIN_STATUS", "warning").strip().lower()

SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER") or None
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD") or None
SMTP_FROM = os.getenv("SMTP_FROM") or SMTP_USER or "license-monitor@localhost"
SMTP_TO = [x.strip() for x in os.getenv("SMTP_TO", "").split(",") if x.strip()]
SMTP_STARTTLS = os.getenv("SMTP_STARTTLS", "true").lower() in {"1", "true", "yes", "on"}
SMTP_SSL = os.getenv("SMTP_SSL", "false").lower() in {"1", "true", "yes", "on"}
SMTP_TIMEOUT = int(os.getenv("SMTP_TIMEOUT", "20"))

STATUS_RU = {
    "expired": "Просрочено",
    "urgent": "Срочно",
    "critical": "Критично",
    "warning": "Предупреждение",
}
STATUS_WEIGHT = {"expired": 4, "urgent": 3, "critical": 2, "warning": 1, "active": 0}
STATUS_COLOR = {
    "expired": "#b91c1c",
    "urgent": "#c2410c",
    "critical": "#a16207",
    "warning": "#1d4ed8",
}
MAX_ROWS = 100


def get_json(path: str):
    """Запрос к API с передачей ключа, если он задан."""
    request = urllib.request.Request(f"{BASE_URL}{path}")
    if API_KEY:
        request.add_header("X-API-Key", API_KEY)
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def item_title(item: dict) -> str:
    """Человекочитаемое название: у разделов разный набор полей."""
    if item.get("section") == "hardware":
        parts = [item.get("equipment_model"), item.get("serial_number")]
        prefix = "Оборудование"
    else:
        parts = [item.get("code"), item.get("certificate_number")]
        prefix = "Лицензия ПО"
    name = " / ".join(str(p) for p in parts if p and p != "-")
    return f"{prefix}: {name or 'без названия'}"


def item_end_date(item: dict) -> str:
    value = item.get("support_end_date") or item.get("cert_end_date")
    return str(value)[:10] if value else "—"


def collect_items() -> list[dict]:
    threshold = STATUS_WEIGHT.get(NOTIFY_MIN_STATUS, 1)
    items = get_json(f"/api/licenses/expiring?days={NOTIFY_DAYS}")
    filtered = [x for x in items if STATUS_WEIGHT.get(x.get("status"), 0) >= threshold]
    filtered.sort(key=lambda x: x.get("days_left", 0))
    return filtered


def days_text(days_left) -> str:
    if not isinstance(days_left, int):
        return "срок неизвестен"
    if days_left < 0:
        return f"просрочено на {abs(days_left)} дн."
    if days_left == 0:
        return "истекает сегодня"
    return f"осталось {days_left} дн."


def build_plain_text(items: list[dict]) -> str:
    lines = [
        f"License Monitor: {len(items)} записей требуют внимания",
        "",
        f"Горизонт: {NOTIFY_DAYS} дней. Источник: {BASE_URL}",
        "",
    ]
    for item in items[:MAX_ROWS]:
        status = STATUS_RU.get(item.get("status"), item.get("status", "unknown"))
        lines.append(
            f"[{status}] {item_title(item)} — {days_text(item.get('days_left'))}, "
            f"до {item_end_date(item)}, ответственный: {item.get('responsible') or '—'}"
        )
    if len(items) > MAX_ROWS:
        lines.append(f"...и ещё {len(items) - MAX_ROWS} записей, см. интерфейс.")
    return "\n".join(lines)


def build_html(items: list[dict]) -> str:
    rows = []
    for item in items[:MAX_ROWS]:
        status = item.get("status", "unknown")
        rows.append(
            "<tr>"
            f'<td style="padding:6px 10px;border-bottom:1px solid #e5e7eb;color:{STATUS_COLOR.get(status, "#111")}">'
            f"<b>{escape(STATUS_RU.get(status, status))}</b></td>"
            f'<td style="padding:6px 10px;border-bottom:1px solid #e5e7eb">{escape(item_title(item))}</td>'
            f'<td style="padding:6px 10px;border-bottom:1px solid #e5e7eb">{escape(item_end_date(item))}</td>'
            f'<td style="padding:6px 10px;border-bottom:1px solid #e5e7eb">{escape(days_text(item.get("days_left")))}</td>'
            f'<td style="padding:6px 10px;border-bottom:1px solid #e5e7eb">{escape(str(item.get("responsible") or "—"))}</td>'
            "</tr>"
        )
    more = (
        f'<p style="color:#6b7280">…и ещё {len(items) - MAX_ROWS} записей.</p>'
        if len(items) > MAX_ROWS else ""
    )
    return f"""<html><body style="font-family:system-ui,Segoe UI,Arial,sans-serif;color:#111">
<h2 style="margin-bottom:4px">License Monitor</h2>
<p style="color:#6b7280;margin-top:0">
  {len(items)} записей требуют внимания в ближайшие {NOTIFY_DAYS} дней.
</p>
<table style="border-collapse:collapse;font-size:14px">
  <thead><tr style="background:#f3f4f6;text-align:left">
    <th style="padding:8px 10px">Статус</th><th style="padding:8px 10px">Объект</th>
    <th style="padding:8px 10px">Дата окончания</th><th style="padding:8px 10px">Остаток</th>
    <th style="padding:8px 10px">Ответственный</th>
  </tr></thead>
  <tbody>{"".join(rows)}</tbody>
</table>
{more}
<p><a href="{escape(BASE_URL)}">Открыть License Monitor</a></p>
</body></html>"""


def send_email(items: list[dict]) -> None:
    message = EmailMessage()
    urgent = sum(1 for x in items if x.get("status") in {"expired", "urgent"})
    marker = f" ({urgent} срочных)" if urgent else ""
    message["Subject"] = f"License Monitor: {len(items)} записей требуют внимания{marker}"
    message["From"] = SMTP_FROM
    message["To"] = ", ".join(SMTP_TO)
    message.set_content(build_plain_text(items))
    message.add_alternative(build_html(items), subtype="html")

    if SMTP_SSL:
        server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT)
    else:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT)
    with server:
        server.ehlo()
        if SMTP_STARTTLS and not SMTP_SSL:
            server.starttls()
            server.ehlo()
        if SMTP_USER and SMTP_PASSWORD:
            server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(message)


def main() -> int:
    if not SMTP_HOST or not SMTP_TO:
        print("Не заданы SMTP_HOST или SMTP_TO — отправка пропущена.", file=sys.stderr)
        return 2
    try:
        items = collect_items()
    except urllib.error.HTTPError as exc:
        hint = " Проверьте ZABBIX_API_KEY." if exc.code == 401 else ""
        print(f"API вернул {exc.code}: {exc.reason}.{hint}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"Не удалось обратиться к {BASE_URL}: {exc}", file=sys.stderr)
        return 1

    if not items:
        print("Записей с риском не найдено — письмо не отправляется.")
        return 0

    try:
        send_email(items)
    except (smtplib.SMTPException, OSError) as exc:
        print(f"Ошибка отправки письма: {exc}", file=sys.stderr)
        return 1
    print(f"Письмо отправлено на {', '.join(SMTP_TO)}: записей {len(items)}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
