#!/bin/sh
# Точка входа контейнера.
#
# Режимы:
#   serve      (по умолчанию) — запуск веб-сервиса
#   notify     — разовая отправка email-уведомлений (для cron на хосте)
#   test       — прогон тестов
#   gen-secret — печатает готовый SESSION_SECRET
#   shell      — интерактивная оболочка
#
# set -e: любая ошибка подготовки останавливает контейнер, а не приводит
# к запуску сервиса в полуготовом состоянии.
set -e

DATA_DIR="${DATA_DIR:-/app/data}"

prepare_dirs() {
    mkdir -p "$DATA_DIR/backups" "$DATA_DIR/import_previews"
    if [ ! -w "$DATA_DIR" ]; then
        echo "ОШИБКА: каталог $DATA_DIR недоступен для записи." >&2
        echo "На хосте выполните: sudo chown -R 1001:1001 ./data" >&2
        exit 1
    fi
}

case "${1:-serve}" in
    serve)
        prepare_dirs
        # Один воркер осознанно: SQLite плохо переносит параллельную запись,
        # а счётчик неудачных входов хранится в памяти процесса.
        # Для нескольких воркеров нужен PostgreSQL и Redis под троттлинг.
        exec uvicorn app.main:app \
            --host "${HOST:-0.0.0.0}" \
            --port "${PORT:-8000}" \
            --workers "${WEB_CONCURRENCY:-1}" \
            --proxy-headers \
            --forwarded-allow-ips "${FORWARDED_ALLOW_IPS:-*}" \
            --timeout-graceful-shutdown 20 \
            --no-server-header
        ;;
    notify)
        exec python -m jobs.notify_email
        ;;
    test)
        exec python -m pytest -q
        ;;
    gen-secret)
        exec python -c "import secrets; print(secrets.token_urlsafe(48))"
        ;;
    shell)
        exec /bin/sh
        ;;
    *)
        exec "$@"
        ;;
esac
