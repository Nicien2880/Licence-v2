(function () {
  const root = document.documentElement;
  const canEdit = document.body.dataset.canEdit !== "false";
  const canManage = document.body.dataset.canManage !== "false";

  function applyTheme(theme) {
    root.dataset.theme = theme;
    localStorage.setItem("lm_theme", theme);
  }

  const savedTheme = localStorage.getItem("lm_theme") || "light";
  applyTheme(savedTheme);

  const themeToggle = document.getElementById("themeToggle");
  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      applyTheme(root.dataset.theme === "dark" ? "light" : "dark");
    });
  }

  function applySidebarState() {
    const collapsed = localStorage.getItem("lm_sidebar_collapsed") === "true";
    document.body.classList.toggle("sidebar-collapsed", collapsed);
  }

  applySidebarState();
  document.querySelectorAll("[data-sidebar-toggle]").forEach((button) => {
    button.addEventListener("click", function () {
      const next = !(localStorage.getItem("lm_sidebar_collapsed") === "true");
      localStorage.setItem("lm_sidebar_collapsed", String(next));
      applySidebarState();
    });
  });

  const filtersForm = document.getElementById("filtersForm");
  if (filtersForm) {
    const section = filtersForm.dataset.section || "default";
    const key = "lm_filters_" + section;
    const currentParams = new URLSearchParams(window.location.search);

    if (!currentParams.has("q") && !currentParams.has("status") && !currentParams.has("responsible") && !currentParams.has("group") && !currentParams.has("manufacturer")) {
      const saved = JSON.parse(localStorage.getItem(key) || "{}");
      const savedGroups = Array.isArray(saved.group) ? saved.group : [];
      const savedManufacturers = Array.isArray(saved.manufacturer) ? saved.manufacturer : [];
      const hasSaved = saved.q || saved.status || saved.responsible || savedGroups.length || savedManufacturers.length;
      if (hasSaved) {
        const target = new URL(window.location.href);
        target.searchParams.set("section", section);
        ["q", "status", "responsible"].forEach((name) => {
          if (saved[name]) target.searchParams.set(name, saved[name]);
        });
        savedGroups.forEach((group) => {
          if (group) target.searchParams.append("group", group);
        });
        savedManufacturers.forEach((manufacturer) => {
          if (manufacturer) target.searchParams.append("manufacturer", manufacturer);
        });
        window.location.replace(target.toString());
      }
    }

    filtersForm.addEventListener("submit", function () {
      const data = new FormData(filtersForm);
      localStorage.setItem(key, JSON.stringify({
        q: data.get("q") || "",
        status: data.get("status") || "",
        responsible: data.get("responsible") || "",
        group: data.getAll("group") || [],
        manufacturer: data.getAll("manufacturer") || [],
      }));
    });

    const reset = document.getElementById("resetFilters");
    if (reset) {
      reset.addEventListener("click", function () {
        localStorage.removeItem(key);
      });
    }
  }

  function sortTable(table, columnIndex, direction) {
    const tbody = table.tBodies[0];
    const rows = Array.from(tbody.querySelectorAll("tr")).filter((row) => !row.querySelector(".empty"));

    rows.sort((a, b) => {
      const aCell = a.children[columnIndex];
      const bCell = b.children[columnIndex];
      const aValue = (aCell?.dataset.sort || aCell?.innerText || "").trim();
      const bValue = (bCell?.dataset.sort || bCell?.innerText || "").trim();
      const aNum = Number(aValue.replace(",", "."));
      const bNum = Number(bValue.replace(",", "."));

      let result;
      if (!Number.isNaN(aNum) && !Number.isNaN(bNum) && aValue !== "" && bValue !== "") {
        result = aNum - bNum;
      } else {
        result = aValue.localeCompare(bValue, "ru", { numeric: true, sensitivity: "base" });
      }
      return direction === "asc" ? result : -result;
    });

    rows.forEach((row) => tbody.appendChild(row));
  }

  function getTableSortKey(table) {
    return "lm_table_sort_" + (table.dataset.tableId || window.location.pathname + "_" + (new URLSearchParams(window.location.search).get("section") || "default"));
  }

  document.querySelectorAll(".sortable-table").forEach((table) => {
    const sortKey = getTableSortKey(table);
    const savedSort = JSON.parse(localStorage.getItem(sortKey) || "null");

    table.querySelectorAll("thead th").forEach((th, index) => {
      if (th.dataset.noSort === "true") return;
      th.classList.add("sortable");

      th.addEventListener("click", function () {
        const current = th.dataset.direction === "asc" ? "desc" : "asc";

        table.querySelectorAll("th").forEach((x) => {
          x.classList.remove("sort-asc", "sort-desc");
          delete x.dataset.direction;
        });

        th.dataset.direction = current;
        th.classList.add(current === "asc" ? "sort-asc" : "sort-desc");

        localStorage.setItem(sortKey, JSON.stringify({
          columnIndex: index,
          direction: current
        }));

        sortTable(table, index, current);
      });
    });

    if (savedSort && Number.isInteger(savedSort.columnIndex)) {
      const th = table.querySelectorAll("thead th")[savedSort.columnIndex];
      if (th && th.dataset.noSort !== "true") {
        const direction = savedSort.direction === "desc" ? "desc" : "asc";
        th.dataset.direction = direction;
        th.classList.add(direction === "asc" ? "sort-asc" : "sort-desc");
        sortTable(table, savedSort.columnIndex, direction);
      }
    }
  });


  function initResizableColumns(table) {
    const headers = Array.from(table.querySelectorAll("thead th"));
    if (!headers.length) return;

    const tableKey = "lm_col_widths_" + (table.dataset.tableId || window.location.pathname + "_" + (new URLSearchParams(window.location.search).get("section") || "default"));
    const savedWidths = JSON.parse(localStorage.getItem(tableKey) || "{}");

    let colgroup = table.querySelector("colgroup");
    if (!colgroup) {
      colgroup = document.createElement("colgroup");
      headers.forEach(() => colgroup.appendChild(document.createElement("col")));
      table.insertBefore(colgroup, table.firstChild);
    }

    const cols = Array.from(colgroup.children);

    function currentWidths() {
      return headers.map((th, index) => {
        const saved = Number(savedWidths[index]);
        return saved > 0 ? saved : Math.max(80, Math.round(th.getBoundingClientRect().width));
      });
    }

    function applyWidths(widths) {
      let total = 0;
      widths.forEach((width, index) => {
        const px = Math.max(70, Math.round(width));
        total += px;
        if (cols[index]) cols[index].style.width = px + "px";
      });
      table.style.width = Math.max(total, table.parentElement.clientWidth) + "px";
    }

    applyWidths(currentWidths());

    headers.forEach((th, index) => {
      if (th.querySelector(".col-resizer")) return;
      th.classList.add("resizable-th");
      const handle = document.createElement("span");
      handle.className = "col-resizer";
      handle.title = "Потяни, чтобы изменить ширину столбца";
      th.appendChild(handle);

      handle.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
      });

      handle.addEventListener("dblclick", function (event) {
        event.preventDefault();
        event.stopPropagation();
        delete savedWidths[index];
        localStorage.setItem(tableKey, JSON.stringify(savedWidths));
        table.style.width = "";
        cols[index].style.width = "";
        applyWidths(currentWidths());
      });

      handle.addEventListener("pointerdown", function (event) {
        event.preventDefault();
        event.stopPropagation();

        const startX = event.clientX;
        const widths = currentWidths();
        const startWidth = widths[index];
        document.body.classList.add("resizing-column");
        handle.setPointerCapture(event.pointerId);

        function onMove(moveEvent) {
          const nextWidth = Math.max(70, startWidth + moveEvent.clientX - startX);
          widths[index] = nextWidth;
          applyWidths(widths);
        }

        function onUp() {
          widths.forEach((width, i) => savedWidths[i] = Math.round(width));
          localStorage.setItem(tableKey, JSON.stringify(savedWidths));
          document.body.classList.remove("resizing-column");
          handle.removeEventListener("pointermove", onMove);
          handle.removeEventListener("pointerup", onUp);
          handle.removeEventListener("pointercancel", onUp);
        }

        handle.addEventListener("pointermove", onMove);
        handle.addEventListener("pointerup", onUp);
        handle.addEventListener("pointercancel", onUp);
      });
    });
  }

  document.querySelectorAll(".resizable-table").forEach(initResizableColumns);


  document.querySelectorAll("[data-toggle-panel]").forEach((button) => {
    button.addEventListener("click", function () {
      const id = button.getAttribute("data-toggle-panel");
      const panel = document.getElementById(id);
      if (!panel) return;
      panel.classList.toggle("open");
      if (panel.classList.contains("open")) {
        panel.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  const modal = document.getElementById("detailModal");
  const modalTitle = document.getElementById("modalTitle");
  const modalDetails = document.getElementById("modalDetails");
  const modalActions = document.getElementById("modalActions");

  function normalizeHeader(text) {
    return (text || "").replace(/\s+/g, " ").trim();
  }

  function collectEditableFields(row) {
    const table = row.closest("table");
    const headers = Array.from(table.querySelectorAll("thead th"));
    const cells = Array.from(row.children);
    return headers.map((headerCell, index) => {
      const normalizedHeader = normalizeHeader(headerCell.innerText);
      const normalizedLower = normalizedHeader.toLowerCase();
      const cell = cells[index];
      if (!cell || !normalizedHeader) return null;
      if (headerCell?.dataset.detailExclude === "true") return null;
      if (headerCell?.classList.contains("actions-col")) return null;
      if (normalizedLower.includes("действ")) return null;

      return {
        label: normalizedHeader,
        field: headerCell.dataset.field || "",
        input: headerCell.dataset.input || "text",
        value: cell.dataset.value ?? cell.innerText.trim(),
        readonly: !headerCell.dataset.field,
      };
    }).filter(Boolean);
  }

  function renderView(fields) {
    modalDetails.innerHTML = "";
    fields.forEach((field) => {
      const block = document.createElement("div");
      block.className = "detail-item";
      const label = document.createElement("span");
      label.innerText = field.label;
      const value = document.createElement("strong");
      if (field.input === "checkbox") {
        value.innerText = field.value === "true" ? "да" : "нет";
      } else {
        value.innerText = field.value || "—";
      }
      block.appendChild(label);
      block.appendChild(value);
      modalDetails.appendChild(block);
    });
  }

  function renderEditForm(fields, updateUrl) {
    modalDetails.innerHTML = "";
    const form = document.createElement("form");
    form.method = "post";
    form.action = updateUrl;
    form.className = "detail-grid detail-edit-form";
    form.id = "modalEditForm";

    fields.forEach((field) => {
      const block = document.createElement("label");
      block.className = "detail-edit-item";
      const label = document.createElement("span");
      label.innerText = field.label;
      block.appendChild(label);

      if (field.readonly) {
        const readonly = document.createElement("strong");
        readonly.innerText = field.value || "—";
        block.appendChild(readonly);
        form.appendChild(block);
        return;
      }

      let input;
      if (field.input === "textarea") {
        input = document.createElement("textarea");
      } else {
        input = document.createElement("input");
        input.type = field.input === "checkbox" ? "checkbox" : field.input;
      }

      input.name = field.field;
      if (field.input === "checkbox") {
        input.value = "true";
        input.checked = field.value === "true";
        block.classList.add("detail-edit-checkbox");
      } else {
        input.value = field.value || "";
      }
      block.appendChild(input);
      form.appendChild(block);
    });

    modalDetails.appendChild(form);
  }

  function openModal(row) {
    if (!modal || !modalDetails) return;
    modalTitle.innerText = row.dataset.title || "Карточка объекта";
    const fields = collectEditableFields(row);
    const updateUrl = row.dataset.updateUrl;
    const deleteUrl = row.dataset.deleteUrl;

    renderView(fields);

    if (modalActions) {
      modalActions.innerHTML = "";

      if (updateUrl && canEdit) {
        const editButton = document.createElement("button");
        editButton.type = "button";
        editButton.className = "button secondary";
        editButton.innerText = "Редактировать";
        editButton.addEventListener("click", function () {
          renderEditForm(fields, updateUrl);
          modalActions.innerHTML = "";

          const saveButton = document.createElement("button");
          saveButton.type = "submit";
          saveButton.className = "button";
          saveButton.innerText = "Сохранить";
          saveButton.setAttribute("form", "modalEditForm");

          const cancelButton = document.createElement("button");
          cancelButton.type = "button";
          cancelButton.className = "button secondary";
          cancelButton.innerText = "Отмена";
          cancelButton.addEventListener("click", function () {
            renderView(fields);
            openModal(row);
          });

          modalActions.appendChild(saveButton);
          modalActions.appendChild(cancelButton);
        });
        modalActions.appendChild(editButton);
      }

      if (deleteUrl && canManage) {
        const form = document.createElement("form");
        form.method = "post";
        form.action = deleteUrl;
        form.onsubmit = function () {
          return confirm("Удалить запись?");
        };

        const button = document.createElement("button");
        button.type = "submit";
        button.className = "danger";
        button.innerText = "Удалить запись";

        form.appendChild(button);
        modalActions.appendChild(form);
      }
    }

    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }

  document.querySelectorAll(".clickable-row").forEach((row) => {
    row.addEventListener("click", function (event) {
      if (event.target.closest("button, a, form, input, select, textarea")) return;
      openModal(row);
    });
  });

  document.querySelectorAll("[data-modal-close]").forEach((el) => {
    el.addEventListener("click", function () {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    });
  });
})();


/* === v16.48: Tools page calculators === */
(function () {
  function ipToInt(ip) {
    const parts = ip.trim().split(".");
    if (parts.length !== 4) throw new Error("IP должен состоять из 4 октетов");
    let n = 0;
    for (const part of parts) {
      if (!/^\d+$/.test(part)) throw new Error("IP содержит некорректный октет");
      const v = Number(part);
      if (v < 0 || v > 255) throw new Error("Октеты IP должны быть от 0 до 255");
      n = (n << 8) + v;
    }
    return n >>> 0;
  }
  function intToIp(n) {
    return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join(".");
  }
  function calcNetwork() {
    const ipInput = document.getElementById("toolIpAddress");
    const cidrInput = document.getElementById("toolCidr");
    const error = document.getElementById("networkError");
    const result = document.getElementById("networkResult");
    if (!ipInput || !cidrInput || !result) return;
    try {
      const ip = ipToInt(ipInput.value);
      const cidr = Number(cidrInput.value);
      const mask = cidr === 0 ? 0 : (0xffffffff << (32 - cidr)) >>> 0;
      const wildcard = (~mask) >>> 0;
      const network = (ip & mask) >>> 0;
      const broadcast = (network | wildcard) >>> 0;
      const total = Math.pow(2, 32 - cidr);
      const usable = cidr >= 31 ? (cidr === 31 ? 2 : 1) : Math.max(total - 2, 0);
      const firstHost = cidr >= 31 ? network : network + 1;
      const lastHost = cidr >= 31 ? broadcast : broadcast - 1;
      const set = (name, value) => {
        const el = result.querySelector(`[data-field="${name}"]`);
        if (el) el.textContent = value;
      };
      set("network", intToIp(network));
      set("broadcast", intToIp(broadcast));
      set("mask", intToIp(mask));
      set("wildcard", intToIp(wildcard));
      set("firstHost", intToIp(firstHost >>> 0));
      set("lastHost", intToIp(lastHost >>> 0));
      set("total", total.toLocaleString("ru-RU"));
      set("usable", usable.toLocaleString("ru-RU"));
      if (error) error.textContent = "";
    } catch (e) {
      if (error) error.textContent = e.message || "Ошибка расчёта";
    }
  }
  function formatNumber(n) {
    if (!Number.isFinite(n)) return "—";
    return new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 6 }).format(n);
  }
  function convertSize() {
    const value = Number(document.getElementById("sizeValue")?.value || 0);
    const from = document.getElementById("sizeFrom")?.value;
    const to = document.getElementById("sizeTo")?.value;
    const mode = document.getElementById("sizeMode")?.value || "1000";
    const out = document.getElementById("sizeResult");
    if (!out || !from || !to) return;

    const normalBase = Number(mode);
    const units = {
      B: 1,
      KB: normalBase,
      MB: normalBase ** 2,
      GB: normalBase ** 3,
      TB: normalBase ** 4,
      KiB: 1024,
      MiB: 1024 ** 2,
      GiB: 1024 ** 3,
      TiB: 1024 ** 4,
    };

    const bytes = value * units[from];
    const result = bytes / units[to];
    out.textContent = `${formatNumber(value)} ${from} = ${formatNumber(result)} ${to}`;
  }

  function convertSpeed() {
    const value = Number(document.getElementById("speedValue")?.value || 0);
    const from = document.getElementById("speedFrom")?.value;
    const to = document.getElementById("speedTo")?.value;
    const out = document.getElementById("speedResult");
    if (!out || !from || !to) return;
    const k = {Kbit:1000, Mbit:1000**2, Gbit:1000**3, KB:8*1000, MB:8*1000**2, GB:8*1000**3};
    const label = {Kbit:"Kbit/s", Mbit:"Mbit/s", Gbit:"Gbit/s", KB:"KB/s", MB:"MB/s", GB:"GB/s"};
    const bits = value * k[from];
    const res = bits / k[to];
    out.textContent = `${formatNumber(value)} ${label[from]} = ${formatNumber(res)} ${label[to]}`;
  }
  document.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById("calcNetworkBtn")) {
      document.getElementById("calcNetworkBtn").addEventListener("click", calcNetwork);
      document.getElementById("toolIpAddress")?.addEventListener("input", calcNetwork);
      document.getElementById("toolCidr")?.addEventListener("change", calcNetwork);
      calcNetwork();
    }
    ["sizeValue","sizeFrom","sizeTo","sizeMode"].forEach(id => {
      document.getElementById(id)?.addEventListener("input", convertSize);
      document.getElementById(id)?.addEventListener("change", convertSize);
    });
    convertSize();
    ["speedValue","speedFrom","speedTo"].forEach(id => {
      document.getElementById(id)?.addEventListener("input", convertSpeed);
      document.getElementById(id)?.addEventListener("change", convertSpeed);
    });
    convertSpeed();
  });
})();
