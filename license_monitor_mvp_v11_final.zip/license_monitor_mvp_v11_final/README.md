# License Monitor v7

Внутренний веб-сервис для контроля сроков техподдержки оборудования и лицензий ПО.

## Что нового в v7

- широкие таблицы с горизонтальным скроллом;
- скрывающееся левое меню;
- светлая и тёмная тема с сохранением выбора в браузере;
- сохранение фильтров отдельно для каждого раздела;
- карточка объекта по клику на строку таблицы;
- сортировка по столбцам в таблице;
- в интерфейсе оставлено только название `License Monitor`;
- добавлен плоский API `/api/zabbix/summary` для Zabbix.

## Быстрый запуск

```bash
cd license_monitor_mvp_v7
pip install -r requirements.txt
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Проверка:

```bash
curl http://127.0.0.1:8000/health
```

## Основные страницы

```text
/                         веб-интерфейс
/?section=hardware         техподдержка оборудования
/?section=software         лицензии ПО
/history                  история изменений
/export.xlsx?section=hardware
/export.xlsx?section=software
```

## API

```text
/api/licenses
/api/licenses?section=hardware
/api/licenses?section=software
/api/licenses/expiring?days=30
/api/licenses/expiring?days=30&section=hardware
/api/hardware-support
/api/software-licenses
/api/monitoring/summary
/api/zabbix/summary
/metrics
```

## Инструкция: как дергать API из Zabbix

### Вариант 1. HTTP agent + JSONPath

Создай отдельный host, например:

```text
License Monitor
```

Добавь item:

```text
Name: License Monitor: Zabbix summary raw
Type: HTTP agent
Key: license_monitor.summary.raw
URL: http://IP_СЕРВЕРА:8000/api/zabbix/summary
Request method: GET
Type of information: Text
Update interval: 5m или 10m
```

Проверь, что item возвращает JSON вида:

```json
{
  "hardware_total": 10,
  "hardware_warning": 2,
  "hardware_critical": 1,
  "hardware_urgent": 0,
  "hardware_expired": 0,
  "software_total": 15,
  "software_warning": 3,
  "software_critical": 1,
  "software_urgent": 1,
  "software_expired": 0,
  "total_expired": 0,
  "total_urgent": 1,
  "total_critical": 2,
  "total_warning": 5
}
```

Дальше сделай dependent items от master item `license_monitor.summary.raw`.

Примеры dependent items:

```text
Name: License Monitor: total expired
Type: Dependent item
Key: license_monitor.total.expired
Master item: License Monitor: Zabbix summary raw
Preprocessing: JSONPath -> $.total_expired
Type of information: Numeric unsigned
```

```text
Name: License Monitor: software urgent
Type: Dependent item
Key: license_monitor.software.urgent
Master item: License Monitor: Zabbix summary raw
Preprocessing: JSONPath -> $.software_urgent
Type of information: Numeric unsigned
```

```text
Name: License Monitor: hardware critical
Type: Dependent item
Key: license_monitor.hardware.critical
Master item: License Monitor: Zabbix summary raw
Preprocessing: JSONPath -> $.hardware_critical
Type of information: Numeric unsigned
```

### Примеры триггеров в Zabbix

Просроченные записи есть:

```text
last(/License Monitor/license_monitor.total.expired)>0
```

Критичные записи есть:

```text
last(/License Monitor/license_monitor.total.urgent)>0
```

Истекают за 8–30 дней:

```text
last(/License Monitor/license_monitor.total.critical)>0
```

Можно сделать разные severity:

```text
Expired > 0   -> High
Urgent > 0    -> Average
Critical > 0  -> Warning
```

### Вариант 2. Prometheus-like metrics

Можно использовать endpoint:

```text
http://IP_СЕРВЕРА:8000/metrics
```

Он отдаёт строки вида:

```text
license_monitor_total{section="hardware"} 10
license_monitor_expired{section="hardware"} 0
license_monitor_urgent{section="software"} 1
```

Для простого Zabbix обычно удобнее `/api/zabbix/summary`, потому что JSONPath проще и нагляднее.

## Важно перед обновлением

Перед заменой рабочей версии сделай бэкап папки проекта и базы:

```bash
cp -r /opt/license_monitor /opt/license_monitor_backup_$(date +%F)
```

Если база уже рабочая, не удаляй папку `data/` без резервной копии.


## v9: изменение ширины столбцов

В таблицах добавлены resizable columns: потяни правую границу заголовка столбца, чтобы изменить ширину. Двойной клик по границе сбрасывает ширину выбранного столбца. Настройки ширины сохраняются в localStorage браузера отдельно для разделов hardware/software.


## v9

Добавлено удаление записи из карточки объекта. Ячейка «Действия» в таблице выровнена по центру, а в модальном окне карточки появилась отдельная кнопка «Удалить запись».
