from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "License Monitor"
    host: str = "0.0.0.0"
    port: int = 8000
    database_url: str = "sqlite:///./data/licenses.db"
    warning_days: int = 60
    critical_days: int = 30
    urgent_days: int = 7

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


@lru_cache
def get_settings() -> Settings:
    return Settings()
