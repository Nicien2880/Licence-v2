# v16.11 Schedule Dashboard

Добавлено:
- визуальный dashboard по столбцу «Периодичность проведения процедуры»;
- блок «Когда выполняются бэкапы» в Data Protection;
- распределение по дням недели;
- подсчёт Full / Incremental;
- распределение по периодичности;
- распределение по времени запуска;
- пункт «Резервные копии объектов» скрыт из бокового меню, но маршрут `/backup-monitor` и код не удалены.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
