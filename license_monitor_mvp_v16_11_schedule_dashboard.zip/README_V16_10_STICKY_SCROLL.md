# v16.10 sticky scrollbar fix

Проблема v16.9:
- верхний горизонтальный скролл был только над таблицей;
- если пользователь находится в середине длинной таблицы, до скролла нужно было подниматься наверх.

Исправление v16.10:
- `.top-scroll` теперь `position: sticky`;
- горизонтальный скролл остаётся доступным при вертикальной прокрутке таблицы;
- если скролл налезает на верхнюю панель, в `static/style.css` поменяй `top: 0` на `top: 64px` или `top: 72px`.

Обновление:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
