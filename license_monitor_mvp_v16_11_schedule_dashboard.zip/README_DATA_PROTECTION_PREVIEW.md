# Data Protection import preview

В этой версии импорт Word/Excel для раздела Data Protection работает через предпросмотр.

## Сценарий

1. Откройте `Data Protection`.
2. В блоке импорта выберите `.docx` или `.xlsx`.
3. Нажмите `Предпросмотр Word` или `Предпросмотр Excel`.
4. Система покажет:
   - сколько строк будет импортировано;
   - общий объём;
   - распределение по типам backup;
   - первые 100 строк.
5. Если всё корректно, нажмите `Подтвердить импорт`.
6. Если нужно заменить старые данные, включите галочку `Очистить таблицу перед импортом`.
7. Если данные распарсились криво, нажмите `Отмена` — в БД ничего не попадёт.

## Важно

Импорт больше не записывает данные сразу в базу. Сначала создаётся временный preview-файл в:

```text
data/import_previews/
```

После подтверждения строки переносятся в SQLite.

## После обновления

```bash
pip3 install python-docx
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
