document.addEventListener("DOMContentLoaded", function () {
  function initScrollSync() {
    document.querySelectorAll(".top-scroll[data-scroll-sync]").forEach(function (topScroll) {
      const key = topScroll.getAttribute("data-scroll-sync");

      const tableScroll =
        document.querySelector('.table-scroll[data-scroll-sync="' + key + '"]') ||
        document.querySelector('.table-wrap[data-scroll-sync="' + key + '"]');

      if (!tableScroll || tableScroll === topScroll) return;

      const inner = topScroll.querySelector(".top-scroll-inner");
      const table = tableScroll.querySelector("table");

      if (!inner || !table) return;

      function refreshWidth() {
        inner.style.width = table.scrollWidth + "px";
      }

      refreshWidth();
      window.addEventListener("resize", refreshWidth);

      let syncing = false;

      topScroll.addEventListener("scroll", function () {
        if (syncing) return;
        syncing = true;
        tableScroll.scrollLeft = topScroll.scrollLeft;
        syncing = false;
      });

      tableScroll.addEventListener("scroll", function () {
        if (syncing) return;
        syncing = true;
        topScroll.scrollLeft = tableScroll.scrollLeft;
        syncing = false;
      });

      if (window.ResizeObserver) {
        const observer = new ResizeObserver(refreshWidth);
        observer.observe(table);
      }

      setTimeout(refreshWidth, 300);
    });
  }

  initScrollSync();
});
