# v16.9 full build

Добавлено:
- верхний горизонтальный скролл в разделе Data Protection;
- скролл синхронизирован с нижним скроллом таблицы;
- закреплена шапка таблицы;
- закреплена первая колонка;
- исправлена стилизация кнопок импорта/очистки из v16.8.

Обновление поверх текущей установки:

```bash
rsync -av --exclude 'data/' --exclude '.env' новая_папка/ /opt/license-monitor/
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```

Если nginx включён:

```bash
sudo systemctl reload nginx
```
