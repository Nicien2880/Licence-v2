from app.wiki.search import MIN_QUERY_LENGTH, escape_query, highlight


def test_escape_query_builds_and_expression():
    assert escape_query("продление лицензий") == '"продление" AND "лицензий"'


def test_short_words_are_dropped():
    assert escape_query("на и в") == ""
    assert escape_query("ab") == ""


def test_fts_operators_are_neutralised():
    """Спецсинтаксис FTS5 не должен ни ломать запрос, ни менять его логику."""
    assert "OR" not in escape_query("продление OR NEAR(x)").replace('"', "")
    assert escape_query('"; DROP TABLE wiki_pages_fts; --') == '"DROP" AND "TABLE" AND "wiki_pages_fts"'
    assert escape_query("*****") == ""


def test_query_is_capped_at_eight_words():
    assert escape_query(" ".join(f"слово{i}" for i in range(20))).count(" AND ") == 7


def test_highlight_marks_matches_with_control_chars():
    result = highlight("Инструкция по продлению лицензий", "продление")
    assert "\x02" in result and "\x03" in result


def test_highlight_returns_plain_text_when_no_match():
    result = highlight("Текст без совпадений", "вообщенету")
    assert "\x02" not in result


def test_highlight_centres_on_match_and_caps_length():
    body = "начало " * 60 + "ключевое " + "конец " * 60
    result = highlight(body, "ключевое", max_length=120)
    assert "ключевое" in result.replace("\x02", "").replace("\x03", "")
    assert len(result) < 160


def test_highlight_handles_empty_input():
    assert highlight("", "запрос") == ""
    assert highlight("текст", "") == "текст"


def test_min_query_length_is_three_for_trigram():
    # Токенизатор trigram индексирует тройки символов: запросы короче
    # трёх символов дали бы шум по всей базе.
    assert MIN_QUERY_LENGTH == 3


def test_highlight_matches_inflected_forms():
    """Подсветка должна совпадать с логикой trigram-поиска.

    Статья с «продлению» находится по запросу «продление» — значит и
    подсветиться она обязана, иначе человек не поймёт, почему она в выдаче.
    """
    result = highlight("Инструкция по продлению лицензий", "продление")
    assert "\x02продлению\x03" in result


def test_highlight_does_not_match_unrelated_words():
    result = highlight("Совершенно другой текст", "продление")
    assert "\x02" not in result
