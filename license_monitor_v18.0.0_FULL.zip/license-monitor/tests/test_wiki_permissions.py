import pytest

from app.wiki.permissions import (
    can_delete_page,
    can_edit_space,
    can_manage_spaces,
    can_pin,
    can_view_space,
)


class FakeUser:
    def __init__(self, id, role):
        self.id = id
        self.role = role


class FakeSpace:
    def __init__(self, visibility="shared", owner_id=None):
        self.visibility = visibility
        self.owner_id = owner_id


class FakePage:
    def __init__(self, author_id=None):
        self.author_id = author_id


VIEWER = FakeUser(1, "viewer")
EDITOR = FakeUser(2, "editor")
MANAGER = FakeUser(3, "manager")
ADMIN = FakeUser(4, "admin")
SHARED = FakeSpace()


@pytest.mark.parametrize("user,expected", [
    (VIEWER, True), (EDITOR, True), (MANAGER, True), (ADMIN, True), (None, False),
])
def test_shared_space_is_visible_to_everyone_logged_in(user, expected):
    assert can_view_space(user, SHARED) is expected


@pytest.mark.parametrize("user,expected", [
    (VIEWER, False), (EDITOR, True), (MANAGER, True), (ADMIN, True),
])
def test_editing_shared_space_needs_editor(user, expected):
    assert can_edit_space(user, SHARED) is expected


def test_personal_space_is_invisible_even_to_admin():
    """Сознательное решение: «личное» должно означать личное.

    Иначе люди перестают пользоваться разделом и уносят заметки обратно
    в блокнот, а именно этого раздел и должен избежать.
    """
    personal = FakeSpace(visibility="personal", owner_id=VIEWER.id)
    assert can_view_space(VIEWER, personal) is True
    assert can_view_space(ADMIN, personal) is False
    assert can_edit_space(ADMIN, personal) is False


def test_owner_can_edit_own_personal_space_even_as_viewer():
    personal = FakeSpace(visibility="personal", owner_id=VIEWER.id)
    assert can_edit_space(VIEWER, personal) is True


def test_author_can_delete_own_page_but_not_others():
    mine = FakePage(author_id=EDITOR.id)
    foreign = FakePage(author_id=999)
    assert can_delete_page(EDITOR, mine, SHARED) is True
    assert can_delete_page(EDITOR, foreign, SHARED) is False


def test_manager_can_delete_any_page():
    assert can_delete_page(MANAGER, FakePage(author_id=999), SHARED) is True


def test_viewer_cannot_delete_even_own_page():
    assert can_delete_page(VIEWER, FakePage(author_id=VIEWER.id), SHARED) is False


@pytest.mark.parametrize("user,expected", [
    (VIEWER, False), (EDITOR, False), (MANAGER, True), (ADMIN, True),
])
def test_pinning_and_space_management_need_manager(user, expected):
    assert can_pin(user, SHARED) is expected
    assert can_manage_spaces(user) is expected


def test_anonymous_can_do_nothing():
    assert can_view_space(None, SHARED) is False
    assert can_edit_space(None, SHARED) is False
    assert can_delete_page(None, FakePage(), SHARED) is False
