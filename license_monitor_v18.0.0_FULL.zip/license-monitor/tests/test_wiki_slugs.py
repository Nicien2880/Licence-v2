import pytest

from app.wiki.slugs import normalize_tag, parse_tags, slugify, unique_slug


@pytest.mark.parametrize("title,expected", [
    ("Продление лицензий Kaspersky", "prodlenie-licenziy-kaspersky"),
    ("Что делать, если Veeam упал?", "chto-delat-esli-veeam-upal"),
    ("  Ёлка   и  ЖЖ  ", "elka-i-zhzh"),
    ("Щука", "shchuka"),
    ("", "page"),
    ("!!!", "page"),
    ("Backup 2026", "backup-2026"),
])
def test_slugify(title, expected):
    assert slugify(title) == expected


def test_slug_is_capped_at_word_boundary():
    slug = slugify("слово " * 40)
    assert len(slug) <= 90
    assert not slug.endswith("-")


def test_unique_slug_appends_counter():
    assert unique_slug("Тест", set()) == "test"
    assert unique_slug("Тест", {"test"}) == "test-2"
    assert unique_slug("Тест", {"test", "test-2", "test-3"}) == "test-4"


@pytest.mark.parametrize("raw,expected", [
    ("Kaspersky, продление", ["kaspersky", "продление"]),
    ("a,,  b ;c", ["a", "b", "c"]),
    ("Дубль, дубль, ДУБЛЬ", ["дубль"]),
    ("", []),
])
def test_parse_tags(raw, expected):
    assert parse_tags(raw) == expected


def test_parse_tags_is_capped():
    assert len(parse_tags(",".join(f"tag{i}" for i in range(50)))) == 12


def test_normalize_tag_trims_and_lowercases():
    assert normalize_tag("  KASPERSKY  Lab ") == "kaspersky lab"
