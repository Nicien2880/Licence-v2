"""Безопасность рендера — главное, что здесь проверяется.

Статьи пишут несколько человек, поэтому текст статьи считается
недоверенным вводом.
"""
import pytest

from app.wiki.markdown import extract_headings, make_excerpt, render


def test_raw_html_is_escaped_not_executed():
    html = render("<script>alert(1)</script>").html
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_img_onerror_is_escaped():
    html = render('<img src=x onerror="alert(1)">').html
    assert "onerror" not in html or "&lt;img" in html
    assert "<img" not in html


@pytest.mark.parametrize("scheme", [
    "javascript:alert(1)",
    "JaVaScRiPt:alert(1)",
    "vbscript:msgbox(1)",
    "data:text/html,<script>alert(1)</script>",
    "file:///etc/passwd",
])
def test_dangerous_link_schemes_never_become_href(scheme):
    html = render(f"[клик]({scheme})").html
    assert 'href="' + scheme.split(":")[0] not in html.lower()
    assert "<a href" not in html.lower() or "http" in html.lower()


def test_safe_links_still_work():
    html = render("[норм](https://example.com) и [почта](mailto:a@b.ru)").html
    assert 'href="https://example.com"' in html
    assert 'href="mailto:a@b.ru"' in html


def test_relative_links_work():
    assert 'href="/wiki/space/page"' in render("[тут](/wiki/space/page)").html


def test_headings_get_anchors():
    result = render("## Когда применять\n\ntext\n\n### Детали")
    assert [h.anchor for h in result.headings] == ["kogda-primenyat", "detali"]
    assert 'id="kogda-primenyat"' in result.html
    assert 'id="detali"' in result.html


def test_duplicate_headings_get_unique_anchors():
    headings = extract_headings("## Итог\n\n## Итог\n\n## Итог")
    assert [h.anchor for h in headings] == ["itog", "itog-2", "itog-3"]


def test_headings_inside_code_fence_are_ignored():
    headings = extract_headings("## Настоящий\n\n```\n## В коде\n```\n\n## Второй")
    assert [h.text for h in headings] == ["Настоящий", "Второй"]


def test_h1_is_not_in_toc():
    # H1 — это заголовок статьи, он выводится отдельно и в оглавление не идёт.
    assert extract_headings("# Заголовок\n\n## Раздел") == extract_headings("## Раздел")


def test_tables_and_code_render():
    html = render("| a | b |\n|---|---|\n| 1 | 2 |\n\n```\ncode\n```").html
    assert "<table>" in html
    assert "<pre>" in html


def test_excerpt_strips_markup():
    excerpt = make_excerpt("## Заголовок\n\n**Жирный** текст со [ссылкой](http://x) и `кодом`.")
    assert "**" not in excerpt and "##" not in excerpt and "[" not in excerpt
    assert "Жирный текст" in excerpt


def test_excerpt_is_capped():
    assert len(make_excerpt("слово " * 500, limit=100)) <= 101


def test_huge_content_is_truncated_not_crashing():
    assert render("а" * 500_000).html
