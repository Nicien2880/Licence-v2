/*
 * Тесты калькулятора НДС.
 *
 * Запуск:  node --test tests/js/*.test.mjs
 *
 * Почему не pytest: калькулятор целиком клиентский, дублировать его на
 * Python ради тестов означало бы два источника правды и неизбежное
 * расхождение. В образе python:3.12-slim нет Node, поэтому эти тесты
 * не входят в `docker compose run tests` — гоняйте их локально перед
 * правкой vat.js.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const vat = require("../../app/static/vat.js");

// --------------------------------------------------------------------------- //
// Разбор ввода
// --------------------------------------------------------------------------- //

test("числа принимаются в том виде, в каком их копируют из Excel", () => {
  assert.equal(vat.parseNumber("1250.50"), 1250.5);
  assert.equal(vat.parseNumber("1250,50"), 1250.5);
  assert.equal(vat.parseNumber("1 250,50"), 1250.5);
  assert.equal(vat.parseNumber("1 250,50"), 1250.5); // неразрывный пробел из Excel
});

test("пустое поле и мусор различаются", () => {
  assert.equal(vat.parseNumber(""), null, "пустое поле — не ошибка");
  assert.ok(Number.isNaN(vat.parseNumber("abc")));
  assert.ok(Number.isNaN(vat.parseNumber("12абв")));
});

// --------------------------------------------------------------------------- //
// Расчёт
// --------------------------------------------------------------------------- //

test("начисление сверху при ставке 22%", () => {
  const r = vat.calculate(100000, 22, "add");
  assert.equal(r.net, 100000);
  assert.equal(r.vat, 22000);
  assert.equal(r.gross, 122000);
});

test("выделение из суммы использует расчётную ставку, а не прямую", () => {
  const r = vat.calculate(122000, 22, "extract");
  assert.equal(r.vat, 22000, "22000, а не 26840 — это главная ошибка в таких расчётах");
  assert.equal(r.net, 100000);
  assert.equal(r.gross, 122000);
});

test("режимы обратны друг другу", () => {
  const up = vat.calculate(100000, 22, "add");
  const down = vat.calculate(up.gross, 22, "extract");
  assert.ok(Math.abs(down.net - 100000) < 1e-9);
  assert.ok(Math.abs(down.vat - up.vat) < 1e-9);
});

test("нулевая ставка не меняет сумму", () => {
  assert.deepEqual(vat.calculate(5000, 0, "add"), { net: 5000, vat: 0, gross: 5000 });
  assert.deepEqual(vat.calculate(5000, 0, "extract"), { net: 5000, vat: 0, gross: 5000 });
});

test("дробная ставка считается точно", () => {
  const r = vat.calculate(1000, 7.5, "add");
  assert.equal(r.vat, 75);
  assert.equal(r.gross, 1075);
});

test("сумма частей сходится с итогом без расхождения на копейку", () => {
  // Промежуточные значения не округляются именно ради этого.
  for (const amount of [0.01, 33.33, 1234.56, 99999.99, 7777777.77]) {
    for (const rate of [22, 10, 7, 5, 7.5]) {
      const r = vat.calculate(amount, rate, "extract");
      const sum = Math.round(r.net * 100) + Math.round(r.vat * 100);
      const total = Math.round(r.gross * 100);
      assert.ok(Math.abs(sum - total) <= 1,
        `${amount} при ${rate}%: ${sum} против ${total}`);
    }
  }
});

// --------------------------------------------------------------------------- //
// Проверка ввода
// --------------------------------------------------------------------------- //

test("ошибки ввода", () => {
  assert.match(vat.validate(NaN, 22), /Сумма/);
  assert.match(vat.validate(100, NaN), /Ставка/);
  assert.match(vat.validate(-5, 22), /отрицательной/);
  assert.match(vat.validate(100, 101), /от 0 до 100/);
  assert.match(vat.validate(100, -1), /от 0 до 100/);
});

test("пустые поля ошибкой не считаются", () => {
  assert.equal(vat.validate(null, 22), "");
  assert.equal(vat.validate(100, null), "");
});

test("граничные ставки 0 и 100 допустимы", () => {
  assert.equal(vat.validate(100, 0), "");
  assert.equal(vat.validate(100, 100), "");
});

// --------------------------------------------------------------------------- //
// Форматирование ставки
// --------------------------------------------------------------------------- //

test("ставка показывается без лишних нулей и с десятичной запятой", () => {
  assert.equal(vat.formatRate(22), "22");
  assert.equal(vat.formatRate(22.0), "22", "не «22.00»");
  assert.equal(vat.formatRate(7.5), "7,5", "запятая, как в суммах рядом");
  assert.equal(vat.formatRate(null), "0");
  assert.equal(vat.formatRate(NaN), "0");
});

// --------------------------------------------------------------------------- //
// Склонения
// --------------------------------------------------------------------------- //

test("11-19 берут множественное число, хотя последняя цифра говорит иначе", () => {
  const forms = ["рубль", "рубля", "рублей"];
  assert.equal(vat.plural(11, forms), "рублей", "не «одиннадцать рубль»");
  assert.equal(vat.plural(12, forms), "рублей");
  assert.equal(vat.plural(14, forms), "рублей");
  assert.equal(vat.plural(111, forms), "рублей");
});

test("обычные окончания", () => {
  const forms = ["рубль", "рубля", "рублей"];
  assert.equal(vat.plural(1, forms), "рубль");
  assert.equal(vat.plural(21, forms), "рубль");
  assert.equal(vat.plural(2, forms), "рубля");
  assert.equal(vat.plural(24, forms), "рубля");
  assert.equal(vat.plural(5, forms), "рублей");
  assert.equal(vat.plural(0, forms), "рублей");
});

// --------------------------------------------------------------------------- //
// Сумма прописью
// --------------------------------------------------------------------------- //

test("тысяча женского рода, миллион мужского", () => {
  assert.equal(vat.amountInWords(21000), "Двадцать одна тысяча рублей 00 копеек");
  assert.equal(vat.amountInWords(22000), "Двадцать две тысячи рублей 00 копеек");
  assert.equal(vat.amountInWords(21000000), "Двадцать один миллион рублей 00 копеек");
  assert.equal(vat.amountInWords(22000000), "Двадцать два миллиона рублей 00 копеек");
});

test("нулевая младшая группа не теряет слово «рублей»", () => {
  assert.equal(vat.amountInWords(122000), "Сто двадцать две тысячи рублей 00 копеек");
  assert.equal(vat.amountInWords(1000000), "Один миллион рублей 00 копеек");
});

test("копейки склоняются отдельно от рублей", () => {
  assert.equal(vat.amountInWords(100.01), "Сто рублей 01 копейка");
  assert.equal(vat.amountInWords(100.02), "Сто рублей 02 копейки");
  assert.equal(vat.amountInWords(100.05), "Сто рублей 05 копеек");
  assert.equal(vat.amountInWords(100.11), "Сто рублей 11 копеек");
});

test("ноль и мелкие суммы", () => {
  assert.equal(vat.amountInWords(0), "Ноль рублей 00 копеек");
  assert.equal(vat.amountInWords(0.99), "Ноль рублей 99 копеек");
  assert.equal(vat.amountInWords(1), "Один рубль 00 копеек");
});

test("пропись не расходится с округлением цифр", () => {
  // 0.005 округляется до копейки один раз, по всей сумме.
  assert.equal(vat.amountInWords(0.005), "Ноль рублей 01 копейка");
  assert.equal(vat.amountInWords(2.345), "Два рубля 35 копеек");
});

test("крупные суммы", () => {
  assert.equal(
    vat.amountInWords(1234567.89),
    "Один миллион двести тридцать четыре тысячи пятьсот шестьдесят семь рублей 89 копеек"
  );
  assert.equal(vat.amountInWords(1000000000), "Один миллиард рублей 00 копеек");
});

test("пропись итога согласована с расчётом", () => {
  const r = vat.calculate(100000, 22, "add");
  assert.equal(vat.amountInWords(r.gross), "Сто двадцать две тысячи рублей 00 копеек");
  assert.equal(vat.amountInWords(r.vat), "Двадцать две тысячи рублей 00 копеек");
});
