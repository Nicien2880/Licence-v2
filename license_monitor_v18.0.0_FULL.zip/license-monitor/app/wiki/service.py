"""Операции над статьями: выборки, сохранение, ревизии, связи, теги."""
from __future__ import annotations

import logging
from dataclasses import dataclass

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload

from ..core.parsing import utcnow
from . import search
from .markdown import make_excerpt
from .models import (
    LINK_OBJECT_TYPES,
    PAGE_STATUSES,
    STATUS_ARCHIVED,
    STATUS_DRAFT,
    STATUS_PUBLISHED,
    VISIBILITY_PERSONAL,
    WikiLink,
    WikiPage,
    WikiPageTag,
    WikiRevision,
    WikiSpace,
    WikiTag,
)
from .permissions import visible_space_filter
from .slugs import parse_tags, unique_slug

logger = logging.getLogger(__name__)


class WikiError(RuntimeError):
    """Базовая ошибка раздела."""


class ConcurrentEditError(WikiError):
    """Статью изменили, пока открыт редактор.

    Несёт актуальную версию, чтобы интерфейс мог показать, кто и что поменял,
    и предложить объединить правки вручную.
    """

    def __init__(self, current: WikiPage):
        self.current = current
        who = current.updated_by.username if current.updated_by else "кто-то"
        super().__init__(
            f"Статью уже изменил {who} — ваша копия устарела (версия "
            f"{current.version}). Объедините правки, чтобы ничего не потерять."
        )


@dataclass
class SearchHit:
    """Результат поиска.

    snippet — текст с управляющими маркерами (удобно тестировать),
    snippet_html — он же, уже экранированный и с <mark>, для вывода в шаблоне.
    """

    page: WikiPage
    score: float
    snippet: str
    snippet_html: object = ""


# --------------------------------------------------------------------------- #
# Пространства
# --------------------------------------------------------------------------- #

def visible_spaces(db: Session, user) -> list[WikiSpace]:
    """Пространства, доступные пользователю: все общие плюс его личное."""
    return (
        db.query(WikiSpace)
        .filter(visible_space_filter(user, WikiSpace))
        .order_by(WikiSpace.position.asc(), WikiSpace.name.asc())
        .all()
    )


def get_space(db: Session, slug: str) -> WikiSpace | None:
    return db.query(WikiSpace).filter(WikiSpace.slug == slug).first()


def ensure_personal_space(db: Session, user) -> WikiSpace:
    """Личное пространство создаётся при первом обращении, а не заранее для всех."""
    space = (
        db.query(WikiSpace)
        .filter(WikiSpace.visibility == VISIBILITY_PERSONAL, WikiSpace.owner_id == user.id)
        .first()
    )
    if space:
        return space
    taken = {row[0] for row in db.query(WikiSpace.slug).all()}
    space = WikiSpace(
        slug=unique_slug(f"personal-{user.username}", taken, "personal"),
        name=f"Заметки: {user.full_name or user.username}",
        description="Видно только вам",
        visibility=VISIBILITY_PERSONAL,
        owner_id=user.id,
        position=900,
    )
    db.add(space)
    db.flush()
    return space


def space_page_counts(db: Session, user) -> dict[int, int]:
    """Число статей по каждому доступному пространству — для дерева в интерфейсе."""
    rows = (
        db.query(WikiPage.space_id, func.count(WikiPage.id))
        .join(WikiSpace, WikiSpace.id == WikiPage.space_id)
        .filter(visible_space_filter(user, WikiSpace))
        .filter(WikiPage.status != STATUS_ARCHIVED)
        .group_by(WikiPage.space_id)
        .all()
    )
    return {space_id: count for space_id, count in rows}


# --------------------------------------------------------------------------- #
# Статьи
# --------------------------------------------------------------------------- #

def _page_query(db: Session, user):
    """Базовая выборка статей, уже ограниченная доступными пространствами."""
    return (
        db.query(WikiPage)
        .join(WikiSpace, WikiSpace.id == WikiPage.space_id)
        .options(joinedload(WikiPage.space), joinedload(WikiPage.updated_by))
        .filter(visible_space_filter(user, WikiSpace))
    )


def get_page(db: Session, space_slug: str, page_slug: str, user) -> WikiPage | None:
    return (
        _page_query(db, user)
        .filter(WikiSpace.slug == space_slug, WikiPage.slug == page_slug)
        .first()
    )


def get_page_by_id(db: Session, page_id: int, user) -> WikiPage | None:
    return _page_query(db, user).filter(WikiPage.id == page_id).first()


def list_pages(
    db: Session,
    user,
    space_id: int | None = None,
    tag: str | None = None,
    include_drafts: bool = True,
    limit: int = 200,
) -> list[WikiPage]:
    query = _page_query(db, user).filter(WikiPage.status != STATUS_ARCHIVED)
    if space_id:
        query = query.filter(WikiPage.space_id == space_id)
    if not include_drafts:
        query = query.filter(WikiPage.status == STATUS_PUBLISHED)
    if tag:
        query = (
            query.join(WikiPageTag, WikiPageTag.page_id == WikiPage.id)
            .join(WikiTag, WikiTag.id == WikiPageTag.tag_id)
            .filter(WikiTag.name == tag)
        )
    return query.order_by(WikiPage.updated_at.desc()).limit(limit).all()


def pinned_pages(db: Session, user, limit: int = 6) -> list[WikiPage]:
    return (
        _page_query(db, user)
        .filter(WikiPage.is_pinned.is_(True), WikiPage.status == STATUS_PUBLISHED)
        .order_by(WikiPage.updated_at.desc())
        .limit(limit)
        .all()
    )


def create_page(
    db: Session,
    space: WikiSpace,
    title: str,
    content_md: str,
    user,
    status: str = STATUS_DRAFT,
    tags_raw: str = "",
    comment: str | None = None,
) -> WikiPage:
    title = (title or "").strip() or "Без названия"
    taken = {row[0] for row in db.query(WikiPage.slug).filter(WikiPage.space_id == space.id).all()}
    page = WikiPage(
        space_id=space.id,
        slug=unique_slug(title, taken),
        title=title,
        content_md=content_md or "",
        excerpt=make_excerpt(content_md),
        status=status if status in PAGE_STATUSES else STATUS_DRAFT,
        author_id=user.id,
        updated_by_id=user.id,
        version=1,
    )
    db.add(page)
    db.flush()

    set_tags(db, page, tags_raw)
    _write_revision(db, page, user, comment or "Создана")
    search.index_page(db, page.id, page.title, page.content_md, _tags_text(page))
    return page


def update_page(
    db: Session,
    page: WikiPage,
    title: str,
    content_md: str,
    user,
    base_version: int,
    status: str | None = None,
    tags_raw: str | None = None,
    comment: str | None = None,
) -> WikiPage:
    """Сохранение с оптимистической блокировкой.

    Редактор присылает base_version — номер версии, которую он открывал.
    Если за это время статью сохранил кто-то другой, версия в базе выросла,
    и сохранение отклоняется: иначе правка коллеги исчезнет молча, а узнают
    об этом через месяц, когда инструкция окажется неверной.
    """
    if int(base_version) != page.version:
        raise ConcurrentEditError(page)

    page.title = (title or "").strip() or page.title
    page.content_md = content_md or ""
    page.excerpt = make_excerpt(page.content_md)
    page.updated_by_id = user.id
    page.updated_at = utcnow()
    page.version += 1
    if status in PAGE_STATUSES:
        page.status = status
    if tags_raw is not None:
        set_tags(db, page, tags_raw)

    _write_revision(db, page, user, comment)
    search.index_page(db, page.id, page.title, page.content_md, _tags_text(page))
    return page


def delete_page(db: Session, page: WikiPage) -> None:
    search.remove_page(db, page.id)
    db.delete(page)


def set_pinned(db: Session, page: WikiPage, pinned: bool) -> None:
    page.is_pinned = bool(pinned)
    page.updated_at = utcnow()


# --------------------------------------------------------------------------- #
# Ревизии
# --------------------------------------------------------------------------- #

def _write_revision(db: Session, page: WikiPage, user, comment: str | None) -> WikiRevision:
    """Снимок статьи.

    author_name дублирует имя автора строкой: пользователя могут удалить, а
    история должна остаться читаемой — «кто это правил» важнее ссылочной
    целостности.
    """
    revision = WikiRevision(
        page_id=page.id,
        version=page.version,
        title=page.title,
        content_md=page.content_md,
        comment=(comment or "").strip()[:300] or None,
        author_id=getattr(user, "id", None),
        author_name=getattr(user, "full_name", None) or getattr(user, "username", "—"),
    )
    db.add(revision)
    return revision


def list_revisions(db: Session, page: WikiPage, limit: int = 50) -> list[WikiRevision]:
    return (
        db.query(WikiRevision)
        .filter(WikiRevision.page_id == page.id)
        .order_by(WikiRevision.version.desc())
        .limit(limit)
        .all()
    )


def get_revision(db: Session, page: WikiPage, version: int) -> WikiRevision | None:
    return (
        db.query(WikiRevision)
        .filter(WikiRevision.page_id == page.id, WikiRevision.version == version)
        .first()
    )


def restore_revision(db: Session, page: WikiPage, revision: WikiRevision, user) -> WikiPage:
    """Откат — это новая версия поверх, а не стирание истории."""
    page.title = revision.title
    page.content_md = revision.content_md
    page.excerpt = make_excerpt(page.content_md)
    page.updated_by_id = user.id
    page.updated_at = utcnow()
    page.version += 1
    _write_revision(db, page, user, f"Откат к версии {revision.version}")
    search.index_page(db, page.id, page.title, page.content_md, _tags_text(page))
    return page


# --------------------------------------------------------------------------- #
# Теги
# --------------------------------------------------------------------------- #

def _tags_text(page: WikiPage) -> str:
    return " ".join(tag.name for tag in page.tags)


def set_tags(db: Session, page: WikiPage, tags_raw: str) -> list[WikiTag]:
    names = parse_tags(tags_raw)
    db.query(WikiPageTag).filter(WikiPageTag.page_id == page.id).delete(synchronize_session=False)
    result: list[WikiTag] = []
    for name in names:
        tag = db.query(WikiTag).filter(WikiTag.name == name).first()
        if tag is None:
            tag = WikiTag(name=name)
            db.add(tag)
            db.flush()
        db.add(WikiPageTag(page_id=page.id, tag_id=tag.id))
        result.append(tag)
    db.flush()
    db.refresh(page)
    return result


def popular_tags(db: Session, user, limit: int = 12) -> list[tuple[str, int]]:
    rows = (
        db.query(WikiTag.name, func.count(WikiPageTag.id).label("uses"))
        .join(WikiPageTag, WikiPageTag.tag_id == WikiTag.id)
        .join(WikiPage, WikiPage.id == WikiPageTag.page_id)
        .join(WikiSpace, WikiSpace.id == WikiPage.space_id)
        .filter(visible_space_filter(user, WikiSpace))
        .group_by(WikiTag.name)
        .order_by(func.count(WikiPageTag.id).desc())
        .limit(limit)
        .all()
    )
    return [(name, uses) for name, uses in rows]


def cleanup_unused_tags(db: Session) -> int:
    """Теги без статей засоряют подсказки. Вызывается после удаления статьи."""
    unused = (
        db.query(WikiTag.id)
        .outerjoin(WikiPageTag, WikiPageTag.tag_id == WikiTag.id)
        .group_by(WikiTag.id)
        .having(func.count(WikiPageTag.id) == 0)
        .all()
    )
    ids = [row[0] for row in unused]
    if ids:
        db.query(WikiTag).filter(WikiTag.id.in_(ids)).delete(synchronize_session=False)
    return len(ids)


# --------------------------------------------------------------------------- #
# Связи с реестром
# --------------------------------------------------------------------------- #

def link_object(db: Session, page: WikiPage, object_type: str, object_id: int) -> WikiLink | None:
    if object_type not in LINK_OBJECT_TYPES:
        raise WikiError(f"Неизвестный тип объекта: {object_type}")
    existing = (
        db.query(WikiLink)
        .filter(
            WikiLink.page_id == page.id,
            WikiLink.object_type == object_type,
            WikiLink.object_id == object_id,
        )
        .first()
    )
    if existing:
        return existing
    link = WikiLink(page_id=page.id, object_type=object_type, object_id=int(object_id))
    db.add(link)
    db.flush()
    return link


def unlink_object(db: Session, page: WikiPage, link_id: int) -> None:
    db.query(WikiLink).filter(WikiLink.id == link_id, WikiLink.page_id == page.id).delete(
        synchronize_session=False
    )


def pages_for_object(db: Session, object_type: str, object_id: int, user) -> list[WikiPage]:
    """Статьи, привязанные к объекту реестра — для вкладки «Статьи» в карточке."""
    if object_type not in LINK_OBJECT_TYPES:
        return []
    return (
        _page_query(db, user)
        .join(WikiLink, WikiLink.page_id == WikiPage.id)
        .filter(
            WikiLink.object_type == object_type,
            WikiLink.object_id == object_id,
            WikiPage.status != STATUS_ARCHIVED,
        )
        .order_by(WikiPage.is_pinned.desc(), WikiPage.updated_at.desc())
        .all()
    )


def prune_orphan_links(db: Session, model_by_type: dict[str, type]) -> int:
    """Удаляет связи с несуществующими объектами.

    Связь полиморфная, внешнего ключа нет, поэтому удаление лицензии оставляет
    висячую запись. Вызывается при удалении объекта и фоновой задачей.
    `model_by_type` передаётся снаружи, чтобы модуль не зависел от моделей
    реестра и оставался тестируемым.
    """
    removed = 0
    for object_type, model in model_by_type.items():
        alive = select(model.id).where(model.id == WikiLink.object_id)
        stale = (
            db.query(WikiLink.id)
            .filter(WikiLink.object_type == object_type, ~alive.exists())
            .all()
        )
        ids = [row[0] for row in stale]
        if ids:
            db.query(WikiLink).filter(WikiLink.id.in_(ids)).delete(synchronize_session=False)
            removed += len(ids)
    if removed:
        logger.info("Удалено висячих связей вики: %d", removed)
    return removed


def objects_without_pages(db: Session, model, object_type: str, limit: int = 20) -> list:
    """Объекты реестра, по которым не написано ни одной статьи.

    Ради этой выборки раздел и затевался: она показывает места, где знание
    существует только в голове у человека.
    """
    linked = select(WikiLink.object_id).where(WikiLink.object_type == object_type)
    return db.query(model).filter(~model.id.in_(linked)).limit(limit).all()


# --------------------------------------------------------------------------- #
# Поиск
# --------------------------------------------------------------------------- #

def search_pages(db: Session, query: str, user, limit: int = 50) -> list[SearchHit]:
    """Поиск по индексу с фильтром по доступным пространствам.

    Права проверяются после FTS: индекс общий, а выдача — только то, что
    человеку видно. Личные заметки коллеги в результаты не попадут.
    """
    ranked = search.search_page_ids(db, query, limit=limit * 2)
    if not ranked:
        return _fallback_search(db, query, user, limit)

    scores = dict(ranked)
    pages = _page_query(db, user).filter(WikiPage.id.in_(list(scores))).all()
    hits = [
        SearchHit(
            page=page,
            score=scores.get(page.id, 0.0),
            snippet=search.highlight(page.content_md, query),
            snippet_html=search.highlight_html(page.content_md, query),
        )
        for page in pages
    ]
    hits.sort(key=lambda hit: hit.score, reverse=True)
    return hits[:limit]


def _fallback_search(db: Session, query: str, user, limit: int) -> list[SearchHit]:
    """Если FTS5 недоступен — обычный LIKE.

    Медленнее и без ранжирования, но раздел остаётся рабочим на сборках
    SQLite без FTS5.
    """
    term = (query or "").strip()
    if len(term) < search.MIN_QUERY_LENGTH:
        return []
    pattern = f"%{term}%"
    pages = (
        _page_query(db, user)
        .filter(or_(WikiPage.title.ilike(pattern), WikiPage.content_md.ilike(pattern)))
        .order_by(WikiPage.updated_at.desc())
        .limit(limit)
        .all()
    )
    return [
        SearchHit(
            page=page,
            score=0.0,
            snippet=search.highlight(page.content_md, term),
            snippet_html=search.highlight_html(page.content_md, term),
        )
        for page in pages
    ]
