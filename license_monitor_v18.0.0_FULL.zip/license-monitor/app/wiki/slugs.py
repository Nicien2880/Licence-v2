"""Построение URL-слагов из русских заголовков.

Статьи адресуются по слагу, а не по id: ссылка /wiki/instructions/prodlenie-kaspersky
читается человеком и переживает переименование раздела. Транслитерация нужна,
потому что кириллица в URL превращается в процентную кашу при копировании
в почту или чат.
"""
from __future__ import annotations

import re

# ГОСТ-подобная таблица: щ→shch, ж→zh. Для слага важна не обратимость,
# а узнаваемость и стабильность.
TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "shch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}

MAX_SLUG_LENGTH = 90


def transliterate(text: str) -> str:
    return "".join(TRANSLIT.get(char, TRANSLIT.get(char.lower(), char)) if char.lower() in TRANSLIT else char
                   for char in text)


def slugify(text: str, fallback: str = "page") -> str:
    """«Продление лицензий Kaspersky» → «prodlenie-licenziy-kaspersky»."""
    value = transliterate((text or "").strip().lower())
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    value = re.sub(r"-{2,}", "-", value)
    if len(value) > MAX_SLUG_LENGTH:
        # Режем по границе слова, чтобы слаг не обрывался на полуслове.
        value = value[:MAX_SLUG_LENGTH].rsplit("-", 1)[0] or value[:MAX_SLUG_LENGTH]
    return value.strip("-") or fallback


def unique_slug(base: str, taken: set[str], fallback: str = "page") -> str:
    """Добавляет -2, -3… пока слаг занят.

    `taken` передаёт вызывающий код, уже отфильтровав по пространству:
    одинаковые заголовки в разных пространствах — норма.
    """
    slug = slugify(base, fallback)
    if slug not in taken:
        return slug
    suffix = 2
    while f"{slug}-{suffix}" in taken:
        suffix += 1
    return f"{slug}-{suffix}"


def normalize_tag(name: str) -> str:
    """Тег приводится к единому виду, чтобы «Kaspersky» и «kaspersky» не плодили дубли."""
    return re.sub(r"\s+", " ", (name or "").strip().lower())[:40]


def parse_tags(raw: str) -> list[str]:
    """Разбирает строку «kaspersky, продление,, закупка» в список без пустых и дублей."""
    seen: list[str] = []
    for part in re.split(r"[,;]", raw or ""):
        tag = normalize_tag(part)
        if tag and tag not in seen:
            seen.append(tag)
    return seen[:12]
