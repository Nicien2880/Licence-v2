"""Константы раздела без зависимостей.

Отдельный модуль нужен, чтобы permissions.py и другие чистые модули могли
брать значения видимости и статусов, не импортируя models.py, а вместе с ним
и SQLAlchemy. Это сохраняет их тестируемыми в изоляции.
"""
from __future__ import annotations

# Видимость пространства
VISIBILITY_SHARED = "shared"      # видно всем вошедшим; правка по роли
VISIBILITY_PERSONAL = "personal"  # видно только владельцу, включая администраторов
VISIBILITIES = {VISIBILITY_SHARED, VISIBILITY_PERSONAL}

# Статусы статьи
STATUS_DRAFT = "draft"
STATUS_PUBLISHED = "published"
STATUS_ARCHIVED = "archived"
PAGE_STATUSES = {STATUS_DRAFT, STATUS_PUBLISHED, STATUS_ARCHIVED}

# Разделы реестра, к которым можно привязать статью
LINK_HARDWARE = "hardware"
LINK_SOFTWARE = "software"
LINK_BACKUP = "backup"
LINK_DATA_PROTECTION = "data_protection"
LINK_OBJECT_TYPES = {LINK_HARDWARE, LINK_SOFTWARE, LINK_BACKUP, LINK_DATA_PROTECTION}

LINK_TYPE_LABELS = {
    LINK_HARDWARE: "Техподдержка оборудования",
    LINK_SOFTWARE: "Лицензии ПО",
    LINK_BACKUP: "Мониторинг бэкапов",
    LINK_DATA_PROTECTION: "План резервирования",
}

# Роли проекта и их уровни
ROLE_LEVEL = {"viewer": 10, "editor": 20, "manager": 30, "admin": 40}
