"""Раздел «База знаний».

Пакет намеренно пуст: здесь нет импортов подмодулей.

Если бы __init__ импортировал models и router, то любой импорт из пакета —
включая `from app.wiki.slugs import slugify` — тянул бы за собой SQLAlchemy
и FastAPI. Это ломает изоляцию чистых модулей (slugs, markdown, permissions,
search), которые специально написаны без зависимости от фреймворка, чтобы
их можно было тестировать и переиспользовать отдельно.

Подключение к приложению — явными импортами, см. INTEGRATION.md:

    from .wiki import models as wiki_models          # регистрация таблиц в ORM
    from .wiki.router import router as wiki_router   # маршруты
    from .wiki.migrations import WIKI_MIGRATIONS     # миграции схемы
"""
