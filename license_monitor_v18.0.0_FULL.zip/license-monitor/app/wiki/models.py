"""ORM-модели раздела «База знаний».

Модели лежат отдельным модулем, но используют тот же Base, что и остальной
проект, поэтому Base.metadata.create_all() создаёт их заодно с основными
таблицами — отдельного шага инициализации не нужно.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..core.parsing import utcnow
from ..database import Base

from .constants import (  # noqa: F401 — реэкспорт для удобства импорта
    LINK_BACKUP,
    LINK_DATA_PROTECTION,
    LINK_HARDWARE,
    LINK_OBJECT_TYPES,
    LINK_SOFTWARE,
    LINK_TYPE_LABELS,
    PAGE_STATUSES,
    STATUS_ARCHIVED,
    STATUS_DRAFT,
    STATUS_PUBLISHED,
    VISIBILITIES,
    VISIBILITY_PERSONAL,
    VISIBILITY_SHARED,
)


class WikiSpace(Base):
    """Раздел верхнего уровня: Регламенты, Инструкции, Личные заметки.

    Вложенность — один уровень (parent_id), сознательно. Глубокое дерево в
    вики на два десятка человек почти всегда превращается в свалку, из которой
    ищут поиском; плоская структура с тегами работает лучше.
    """

    __tablename__ = "wiki_spaces"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    slug: Mapped[str] = mapped_column(String(120), nullable=False, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(String(400), nullable=True)
    parent_id: Mapped[int | None] = mapped_column(
        ForeignKey("wiki_spaces.id", ondelete="SET NULL"), nullable=True, index=True
    )
    visibility: Mapped[str] = mapped_column(
        String(20), nullable=False, default=VISIBILITY_SHARED, index=True
    )
    # Заполняется только для personal: чьё это пространство.
    owner_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    position: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow
    )

    parent = relationship("WikiSpace", remote_side=[id], backref="children")
    pages = relationship("WikiPage", back_populates="space", cascade="all, delete-orphan")

    @property
    def is_personal(self) -> bool:
        return self.visibility == VISIBILITY_PERSONAL


class WikiPage(Base):
    """Статья."""

    __tablename__ = "wiki_pages"
    __table_args__ = (
        # Слаг уникален внутри пространства: одинаковые заголовки в разных
        # разделах — нормальная ситуация.
        UniqueConstraint("space_id", "slug", name="uq_wiki_pages_space_slug"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    space_id: Mapped[int] = mapped_column(
        ForeignKey("wiki_spaces.id", ondelete="CASCADE"), nullable=False, index=True
    )
    slug: Mapped[str] = mapped_column(String(120), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    content_md: Mapped[str] = mapped_column(Text, nullable=False, default="")
    excerpt: Mapped[str | None] = mapped_column(String(400), nullable=True)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=STATUS_DRAFT, index=True
    )
    is_pinned: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, index=True)

    author_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    updated_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )

    # Номер текущей версии. Редактор присылает его обратно вместе с текстом;
    # несовпадение означает, что статью успели изменить, и сохранение
    # отклоняется вместо молчаливого затирания чужой правки.
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow, index=True
    )

    space = relationship("WikiSpace", back_populates="pages")
    author = relationship("User", foreign_keys=[author_id])
    updated_by = relationship("User", foreign_keys=[updated_by_id])
    revisions = relationship(
        "WikiRevision",
        back_populates="page",
        cascade="all, delete-orphan",
        order_by="WikiRevision.version.desc()",
    )
    links = relationship("WikiLink", back_populates="page", cascade="all, delete-orphan")
    tags = relationship("WikiTag", secondary="wiki_page_tags", back_populates="pages")

    @property
    def url(self) -> str:
        return f"/wiki/{self.space.slug}/{self.slug}" if self.space else f"/wiki/p/{self.id}"


class WikiRevision(Base):
    """Снимок статьи на момент сохранения.

    Храним полный текст, а не дельту: статьи небольшие, а восстановление и
    сравнение из полного снимка не требует проигрывать цепочку патчей.
    """

    __tablename__ = "wiki_revisions"
    __table_args__ = (
        UniqueConstraint("page_id", "version", name="uq_wiki_revisions_page_version"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    page_id: Mapped[int] = mapped_column(
        ForeignKey("wiki_pages.id", ondelete="CASCADE"), nullable=False, index=True
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    content_md: Mapped[str] = mapped_column(Text, nullable=False)
    comment: Mapped[str | None] = mapped_column(String(300), nullable=True)
    author_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    author_name: Mapped[str] = mapped_column(String(120), nullable=False, default="—")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow, index=True
    )

    page = relationship("WikiPage", back_populates="revisions")


class WikiTag(Base):
    __tablename__ = "wiki_tags"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(40), nullable=False, unique=True, index=True)

    pages = relationship("WikiPage", secondary="wiki_page_tags", back_populates="tags")


class WikiPageTag(Base):
    __tablename__ = "wiki_page_tags"
    __table_args__ = (UniqueConstraint("page_id", "tag_id", name="uq_wiki_page_tags"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    page_id: Mapped[int] = mapped_column(
        ForeignKey("wiki_pages.id", ondelete="CASCADE"), nullable=False, index=True
    )
    tag_id: Mapped[int] = mapped_column(
        ForeignKey("wiki_tags.id", ondelete="CASCADE"), nullable=False, index=True
    )


class WikiLink(Base):
    """Связь статьи с объектом реестра.

    Связь полиморфная: object_type + object_id вместо четырёх внешних ключей.
    Цена решения — целостность не обеспечивается базой, поэтому висячие связи
    убирает prune_orphan_links() (см. service.py), который вызывается при
    удалении объекта и раз в сутки фоновой задачей.
    """

    __tablename__ = "wiki_links"
    __table_args__ = (
        UniqueConstraint("page_id", "object_type", "object_id", name="uq_wiki_links"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    page_id: Mapped[int] = mapped_column(
        ForeignKey("wiki_pages.id", ondelete="CASCADE"), nullable=False, index=True
    )
    object_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    object_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utcnow
    )

    page = relationship("WikiPage", back_populates="links")
