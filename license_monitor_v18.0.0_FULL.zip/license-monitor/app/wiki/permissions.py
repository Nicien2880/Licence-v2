"""Права доступа к пространствам и статьям.

Правила держатся в одном модуле и возвращают bool — их можно покрыть тестами
без поднятия приложения и без базы.

Базовый принцип: роли проекта (viewer → editor → manager → admin) определяют,
что человек может делать, а видимость пространства — что он вообще видит.

Отдельное решение, которое стоит проговорить: личное пространство не видит
никто, кроме владельца, включая администратора. Админ может удалить
пространство целиком (это видно в журнале), но не прочитать чужие заметки
мимо владельца. Иначе «личное» — просто ярлык, и люди перестают им
пользоваться, возвращая заметки в блокнот.
"""
from __future__ import annotations

from .constants import ROLE_LEVEL, VISIBILITY_PERSONAL


def _level(user) -> int:
    if user is None:
        return 0
    return ROLE_LEVEL.get(getattr(user, "role", ""), 0)


def _is_owner(user, space) -> bool:
    if user is None or space is None:
        return False
    owner_id = getattr(space, "owner_id", None)
    return owner_id is not None and owner_id == getattr(user, "id", None)


def can_view_space(user, space) -> bool:
    """Личное пространство — только владельцу. Общее — любому вошедшему."""
    if user is None or space is None:
        return False
    if getattr(space, "visibility", None) == VISIBILITY_PERSONAL:
        return _is_owner(user, space)
    return _level(user) >= ROLE_LEVEL["viewer"]


def can_edit_space(user, space) -> bool:
    """Создавать и править статьи: editor и выше; в личном — владелец."""
    if not can_view_space(user, space):
        return False
    if getattr(space, "visibility", None) == VISIBILITY_PERSONAL:
        return _is_owner(user, space)
    return _level(user) >= ROLE_LEVEL["editor"]


def can_delete_page(user, page, space) -> bool:
    """Удаление — manager и выше, либо автор своей же статьи, либо владелец личного."""
    if not can_view_space(user, space):
        return False
    if getattr(space, "visibility", None) == VISIBILITY_PERSONAL:
        return _is_owner(user, space)
    if _level(user) >= ROLE_LEVEL["manager"]:
        return True
    # Автор может удалить свою статью, но только если вообще имеет право писать:
    # иначе понижение роли до viewer оставило бы человеку возможность удалять.
    if _level(user) < ROLE_LEVEL["editor"]:
        return False
    author_id = getattr(page, "author_id", None)
    return author_id is not None and author_id == getattr(user, "id", None)


def can_manage_spaces(user) -> bool:
    """Создание, переименование и удаление общих пространств."""
    return _level(user) >= ROLE_LEVEL["manager"]


def can_pin(user, space) -> bool:
    """Закрепление статьи в разделе видно всем, поэтому требует manager."""
    if getattr(space, "visibility", None) == VISIBILITY_PERSONAL:
        return _is_owner(user, space)
    return _level(user) >= ROLE_LEVEL["manager"]


def visible_space_filter(user, space_model):
    """Условие SQLAlchemy для выборки доступных пространств.

    Возвращает выражение для .filter(): общие пространства плюс личные,
    принадлежащие этому пользователю.
    """
    from sqlalchemy import or_

    user_id = getattr(user, "id", None)
    return or_(
        space_model.visibility != VISIBILITY_PERSONAL,
        space_model.owner_id == user_id,
    )
