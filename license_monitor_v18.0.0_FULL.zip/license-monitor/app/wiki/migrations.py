"""Миграции раздела «База знаний».

Регистрируются в общем списке проекта (app/migrations.py), поэтому
применяются один раз и фиксируются в schema_migrations вместе с остальными.

Таблицы создаёт Base.metadata.create_all() — здесь только то, чего ORM не
умеет: виртуальная таблица FTS5 и наполнение пространств по умолчанию.
"""
from __future__ import annotations

import logging

from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection

logger = logging.getLogger(__name__)

DEFAULT_SPACES = [
    ("reglamenty", "Регламенты", "Утверждённые порядки и политики", 10),
    ("instrukcii", "Инструкции", "Как что делается на практике", 20),
    ("postmortem", "Постмортемы", "Разборы инцидентов", 30),
]


def m010_wiki_fts(conn: Connection) -> None:
    """Виртуальная таблица полнотекстового поиска.

    FTS5 есть не во всех сборках SQLite, поэтому отсутствие модуля не должно
    ронять миграцию: поиск в этом случае деградирует до LIKE (см. search.py).
    """
    try:
        conn.execute(text(
            "CREATE VIRTUAL TABLE IF NOT EXISTS wiki_pages_fts "
            "USING fts5(title, body, tags, page_id UNINDEXED, tokenize='trigram')"
        ))
    except Exception as exc:
        logger.warning(
            "FTS5 недоступен (%s). Поиск по вики будет работать через LIKE.", exc
        )


def m011_wiki_default_spaces(conn: Connection) -> None:
    """Три общих пространства, чтобы раздел не встречал пустотой."""
    if "wiki_spaces" not in inspect(conn).get_table_names():
        return
    existing = conn.execute(text("SELECT COUNT(*) FROM wiki_spaces")).scalar() or 0
    if existing:
        return
    from ..core.parsing import utcnow

    now = utcnow().isoformat()
    for slug, name, description, position in DEFAULT_SPACES:
        conn.execute(
            text(
                "INSERT INTO wiki_spaces "
                "(slug, name, description, visibility, position, created_at) "
                "VALUES (:slug, :name, :description, 'shared', :position, :created_at)"
            ),
            {
                "slug": slug,
                "name": name,
                "description": description,
                "position": position,
                "created_at": now,
            },
        )
    logger.info("Созданы пространства вики по умолчанию: %d", len(DEFAULT_SPACES))


def m012_wiki_indexes(conn: Connection) -> None:
    """Индексы под основные запросы раздела."""
    if "wiki_pages" not in inspect(conn).get_table_names():
        return
    statements = [
        "CREATE INDEX IF NOT EXISTS ix_wiki_pages_space_updated "
        "ON wiki_pages (space_id, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS ix_wiki_links_object "
        "ON wiki_links (object_type, object_id)",
    ]
    for statement in statements:
        try:
            conn.execute(text(statement))
        except Exception as exc:
            logger.warning("Индекс не создан: %s", exc)


# Список для подключения в app/migrations.py (см. INTEGRATION.md).
WIKI_MIGRATIONS = [
    (10, "wiki_fts", m010_wiki_fts),
    (11, "wiki_default_spaces", m011_wiki_default_spaces),
    (12, "wiki_indexes", m012_wiki_indexes),
]
