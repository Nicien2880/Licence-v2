"""HTTP-слой раздела «База знаний»."""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from ..auth import require_login
from ..database import get_db
from ..deps import base_context, page_user, redirect, templates
from ..models import User
from ..services.common import log_change
from . import service
from .markdown import render
from .models import (
    LINK_OBJECT_TYPES,
    LINK_TYPE_LABELS,
    STATUS_DRAFT,
    STATUS_PUBLISHED,
    WikiSpace,
)
from .permissions import (
    can_delete_page,
    can_edit_space,
    can_manage_spaces,
    can_pin,
    can_view_space,
)
from .service import ConcurrentEditError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/wiki", tags=["wiki"])

# Шаблоны статей: пустая страница — худший способ начать писать.
PAGE_TEMPLATES = {
    "blank": ("Пустая", ""),
    "runbook": (
        "Инструкция",
        "## Когда применять\n\n\n## Порядок действий\n\n1. \n2. \n3. \n\n"
        "## Подводные камни\n\n- \n",
    ),
    "postmortem": (
        "Постмортем",
        "## Что произошло\n\n\n## Хронология\n\n| Время | Событие |\n|---|---|\n|  |  |\n\n"
        "## Причина\n\n\n## Что сделать, чтобы не повторилось\n\n- \n",
    ),
    "policy": (
        "Регламент",
        "## Область действия\n\n\n## Требования\n\n\n## Ответственные\n\n\n"
        "## Исключения\n\n",
    ),
}


def _space_or_404(db: Session, slug: str, user: User) -> WikiSpace:
    space = service.get_space(db, slug)
    # Отсутствующее и недоступное пространство отдают одинаковый 404:
    # иначе по коду ответа можно перебрать чужие личные разделы.
    if space is None or not can_view_space(user, space):
        raise HTTPException(status_code=404, detail="Пространство не найдено")
    return space


def _nav_context(db: Session, user: User) -> dict:
    spaces = service.visible_spaces(db, user)
    return {
        "spaces": spaces,
        "space_counts": service.space_page_counts(db, user),
        "tags": service.popular_tags(db, user),
        "can_manage_spaces": can_manage_spaces(user),
    }


# --------------------------------------------------------------------------- #
# Просмотр
# --------------------------------------------------------------------------- #

@router.get("", response_class=HTMLResponse)
def wiki_index(
    request: Request,
    space: str | None = None,
    tag: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    selected_space = _space_or_404(db, space, current_user) if space else None
    pages = service.list_pages(
        db, current_user, space_id=selected_space.id if selected_space else None, tag=tag
    )
    return templates.TemplateResponse(
        request=request,
        name="wiki/index.html",
        context=base_context(
            request,
            current_user,
            pages=pages,
            pinned=service.pinned_pages(db, current_user),
            selected_space=selected_space,
            selected_tag=tag,
            templates_list=PAGE_TEMPLATES,
            **_nav_context(db, current_user),
        ),
    )


@router.get("/search", response_class=HTMLResponse)
def wiki_search(
    request: Request,
    q: str = "",
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    hits = service.search_pages(db, q, current_user) if q.strip() else []
    return templates.TemplateResponse(
        request=request,
        name="wiki/search.html",
        context=base_context(
            request, current_user, query=q, hits=hits, **_nav_context(db, current_user)
        ),
    )


@router.get("/new", response_class=HTMLResponse)
def wiki_new(
    request: Request,
    space: str | None = None,
    template: str = "blank",
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    spaces = [s for s in service.visible_spaces(db, current_user) if can_edit_space(current_user, s)]
    if not spaces:
        raise HTTPException(status_code=403, detail="Нет пространств, доступных для записи")
    selected = next((s for s in spaces if s.slug == space), spaces[0])
    _label, body = PAGE_TEMPLATES.get(template, PAGE_TEMPLATES["blank"])
    return templates.TemplateResponse(
        request=request,
        name="wiki/edit.html",
        context=base_context(
            request,
            current_user,
            page=None,
            editable_spaces=spaces,
            selected_space=selected,
            content=body,
            conflict=None,
            templates_list=PAGE_TEMPLATES,
            **_nav_context(db, current_user),
        ),
    )


@router.get("/{space_slug}/{page_slug}", response_class=HTMLResponse)
def wiki_page(
    request: Request,
    space_slug: str,
    page_slug: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    rendered = render(page.content_md)
    return templates.TemplateResponse(
        request=request,
        name="wiki/page.html",
        context=base_context(
            request,
            current_user,
            page=page,
            rendered=rendered,
            links=page.links,
            link_labels=LINK_TYPE_LABELS,
            can_edit=can_edit_space(current_user, page.space),
            can_delete=can_delete_page(current_user, page, page.space),
            can_pin_page=can_pin(current_user, page.space),
            **_nav_context(db, current_user),
        ),
    )


@router.get("/{space_slug}/{page_slug}/history", response_class=HTMLResponse)
def wiki_history(
    request: Request,
    space_slug: str,
    page_slug: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    return templates.TemplateResponse(
        request=request,
        name="wiki/history.html",
        context=base_context(
            request,
            current_user,
            page=page,
            revisions=service.list_revisions(db, page),
            can_edit=can_edit_space(current_user, page.space),
            **_nav_context(db, current_user),
        ),
    )


@router.get("/{space_slug}/{page_slug}/edit", response_class=HTMLResponse)
def wiki_edit(
    request: Request,
    space_slug: str,
    page_slug: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(page_user),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_edit_space(current_user, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав для редактирования")
    spaces = [s for s in service.visible_spaces(db, current_user) if can_edit_space(current_user, s)]
    return templates.TemplateResponse(
        request=request,
        name="wiki/edit.html",
        context=base_context(
            request,
            current_user,
            page=page,
            editable_spaces=spaces,
            selected_space=page.space,
            content=page.content_md,
            conflict=None,
            templates_list=PAGE_TEMPLATES,
            **_nav_context(db, current_user),
        ),
    )


# --------------------------------------------------------------------------- #
# Изменение
# --------------------------------------------------------------------------- #

@router.post("/new")
def wiki_create(
    space_id: int = Form(...),
    title: str = Form(...),
    content_md: str = Form(""),
    tags: str = Form(""),
    status: str = Form(STATUS_DRAFT),
    comment: str = Form(""),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    space = db.get(WikiSpace, space_id)
    if space is None or not can_edit_space(current_user, space):
        raise HTTPException(status_code=403, detail="Нет прав на запись в это пространство")
    page = service.create_page(
        db, space, title, content_md, current_user,
        status=status, tags_raw=tags, comment=comment,
    )
    log_change(db, "wiki", page.id, "create", f"Создана статья: {page.title}",
               actor=current_user.username)
    db.commit()
    return redirect(f"/wiki/{space.slug}/{page.slug}")


@router.post("/{space_slug}/{page_slug}/edit")
def wiki_save(
    request: Request,
    space_slug: str,
    page_slug: str,
    title: str = Form(...),
    content_md: str = Form(""),
    tags: str = Form(""),
    status: str = Form(STATUS_PUBLISHED),
    comment: str = Form(""),
    base_version: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_edit_space(current_user, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав для редактирования")

    try:
        service.update_page(
            db, page, title, content_md, current_user,
            base_version=base_version, status=status, tags_raw=tags, comment=comment,
        )
    except ConcurrentEditError as conflict:
        # Форма возвращается с текстом пользователя и актуальной версией рядом,
        # чтобы человек сам решил, что оставить. Ничего не теряется.
        db.rollback()
        spaces = [s for s in service.visible_spaces(db, current_user)
                  if can_edit_space(current_user, s)]
        return templates.TemplateResponse(
            request=request,
            name="wiki/edit.html",
            context=base_context(
                request,
                current_user,
                page=conflict.current,
                editable_spaces=spaces,
                selected_space=conflict.current.space,
                content=content_md,
                conflict={
                    "message": str(conflict),
                    "their_content": conflict.current.content_md,
                    "their_version": conflict.current.version,
                },
                templates_list=PAGE_TEMPLATES,
                **_nav_context(db, current_user),
            ),
            status_code=409,
        )

    log_change(db, "wiki", page.id, "update",
               f"Изменена статья: {page.title} (версия {page.version})",
               actor=current_user.username)
    db.commit()
    return redirect(f"/wiki/{page.space.slug}/{page.slug}")


@router.post("/{space_slug}/{page_slug}/delete")
def wiki_delete(
    space_slug: str,
    page_slug: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_delete_page(current_user, page, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав для удаления")
    title = page.title
    service.delete_page(db, page)
    service.cleanup_unused_tags(db)
    log_change(db, "wiki", None, "delete", f"Удалена статья: {title}",
               actor=current_user.username)
    db.commit()
    return redirect("/wiki")


@router.post("/{space_slug}/{page_slug}/pin")
def wiki_pin(
    space_slug: str,
    page_slug: str,
    pinned: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_pin(current_user, page.space):
        raise HTTPException(status_code=403, detail="Закрепление доступно менеджерам")
    service.set_pinned(db, page, pinned)
    db.commit()
    return redirect(f"/wiki/{space_slug}/{page_slug}")


@router.post("/{space_slug}/{page_slug}/restore")
def wiki_restore(
    space_slug: str,
    page_slug: str,
    version: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_edit_space(current_user, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав")
    revision = service.get_revision(db, page, version)
    if revision is None:
        raise HTTPException(status_code=404, detail="Версия не найдена")
    service.restore_revision(db, page, revision, current_user)
    log_change(db, "wiki", page.id, "restore",
               f"Откат статьи «{page.title}» к версии {version}",
               actor=current_user.username)
    db.commit()
    return redirect(f"/wiki/{space_slug}/{page_slug}")


# --------------------------------------------------------------------------- #
# Связи с реестром
# --------------------------------------------------------------------------- #

@router.post("/{space_slug}/{page_slug}/link")
def wiki_link(
    space_slug: str,
    page_slug: str,
    object_type: str = Form(...),
    object_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_edit_space(current_user, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав")
    if object_type not in LINK_OBJECT_TYPES:
        raise HTTPException(status_code=400, detail="Неизвестный тип объекта")
    service.link_object(db, page, object_type, object_id)
    db.commit()
    return redirect(f"/wiki/{space_slug}/{page_slug}")


@router.post("/{space_slug}/{page_slug}/unlink")
def wiki_unlink(
    space_slug: str,
    page_slug: str,
    link_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    page = service.get_page(db, space_slug, page_slug, current_user)
    if page is None:
        raise HTTPException(status_code=404, detail="Статья не найдена")
    if not can_edit_space(current_user, page.space):
        raise HTTPException(status_code=403, detail="Недостаточно прав")
    service.unlink_object(db, page, link_id)
    db.commit()
    return redirect(f"/wiki/{space_slug}/{page_slug}")


# --------------------------------------------------------------------------- #
# Пространства
# --------------------------------------------------------------------------- #

@router.post("/spaces")
def wiki_create_space(
    name: str = Form(...),
    description: str = Form(""),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    if not can_manage_spaces(current_user):
        raise HTTPException(status_code=403, detail="Создание пространств доступно менеджерам")
    name = name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Название обязательно")
    from .slugs import unique_slug

    taken = {row[0] for row in db.query(WikiSpace.slug).all()}
    space = WikiSpace(
        slug=unique_slug(name, taken, "space"),
        name=name,
        description=description.strip() or None,
        position=500,
    )
    db.add(space)
    log_change(db, "wiki", None, "space_create", f"Создано пространство: {name}",
               actor=current_user.username)
    db.commit()
    return redirect(f"/wiki?space={space.slug}")


@router.post("/spaces/personal")
def wiki_personal_space(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_login),
):
    """Личное пространство создаётся по требованию самим владельцем."""
    space = service.ensure_personal_space(db, current_user)
    db.commit()
    return redirect(f"/wiki?space={space.slug}")
