"""Рендер Markdown в безопасный HTML + оглавление.

Про безопасность. Статьи пишут несколько человек, поэтому текст статьи —
недоверенный ввод, даже если все авторы свои: учётную запись могут увести,
а разметку — вставить копипастом из письма.

Защита строится на том, что markdown-it запускается с html=False: сырой HTML
в тексте экранируется и до читателя доезжает как видимый текст, а не как
разметка. Это надёжнее постобработки через allowlist (bleach): нечего
обходить, если HTML вообще не парсится. Ссылки markdown-it проверяет сам —
javascript:, vbscript: и data: он не пропускает; на всякий случай
валидатор продублирован здесь явно.

Шаблоны обязаны выводить результат через |safe — иначе читатель увидит код.
Это единственное место в проекте, где |safe допустим, и только для вывода
этой функции.
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass, field

from markdown_it import MarkdownIt

from .slugs import slugify

ALLOWED_SCHEMES = {"http", "https", "mailto", "tel", ""}
MAX_CONTENT_CHARS = 200_000


@dataclass
class Heading:
    level: int
    text: str
    anchor: str


@dataclass
class RenderedPage:
    html: str
    headings: list[Heading] = field(default_factory=list)
    excerpt: str = ""


def _validate_link(url: str) -> bool:
    """Пропускаем только безопасные схемы и относительные ссылки."""
    cleaned = url.strip().lower()
    cleaned = cleaned.replace("\t", "").replace("\n", "").replace("\r", "")
    if cleaned.startswith(("javascript:", "vbscript:", "data:", "file:")):
        return False
    match = re.match(r"^([a-z][a-z0-9+.-]*):", cleaned)
    scheme = match.group(1) if match else ""
    return scheme in ALLOWED_SCHEMES


def _linkify_available() -> bool:
    """linkify-it-py — необязательная зависимость.

    Без неё markdown-it падает при включённом linkify, поэтому опцию
    включаем только когда пакет действительно установлен: автоссылки —
    удобство, а не причина ронять рендер всей вики.
    """
    try:
        import linkify_it  # noqa: F401
    except ImportError:
        return False
    return True


def _build_parser() -> MarkdownIt:
    linkify = _linkify_available()
    parser = MarkdownIt(
        "commonmark", {"html": False, "linkify": linkify, "typographer": True}
    )
    rules = ["table", "strikethrough"]
    if linkify:
        rules.append("linkify")
    parser.enable(rules)
    parser.validateLink = _validate_link
    return parser


_parser = _build_parser()


def extract_headings(text: str) -> list[Heading]:
    """Собирает ## и ### для оглавления, пропуская заголовки внутри блоков кода."""
    headings: list[Heading] = []
    used: dict[str, int] = {}
    in_fence = False
    for line in (text or "").splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        match = re.match(r"^(#{2,3})\s+(.+?)\s*#*$", line)
        if not match:
            continue
        level = len(match.group(1))
        title = match.group(2).strip()
        anchor = slugify(title, "section")
        # Два одинаковых заголовка в статье — обычное дело; якоря должны различаться.
        if anchor in used:
            used[anchor] += 1
            anchor = f"{anchor}-{used[anchor]}"
        else:
            used[anchor] = 1
        headings.append(Heading(level=level, text=title, anchor=anchor))
    return headings


def _inject_anchors(rendered: str, headings: list[Heading]) -> str:
    """Проставляет id в <h2>/<h3>, чтобы оглавление и ссылки #anchor работали."""
    queue = list(headings)

    def replace(match: re.Match) -> str:
        if not queue:
            return match.group(0)
        heading = queue.pop(0)
        return f'<h{heading.level} id="{html.escape(heading.anchor, quote=True)}">'

    return re.sub(r"<h([23])>", replace, rendered)


def make_excerpt(text: str, limit: int = 220) -> str:
    """Короткая выжимка для списков и результатов поиска — без разметки."""
    plain = re.sub(r"```.*?```", " ", text or "", flags=re.DOTALL)
    plain = re.sub(r"^#{1,6}\s+.*$", " ", plain, flags=re.MULTILINE)
    plain = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", plain)
    # Остатки экранированного HTML в выжимке только мешают читать список.
    plain = re.sub(r"</?[a-zA-Z][^>]*>?", " ", plain)
    plain = re.sub(r"[*_`>#|<>-]+", " ", plain)
    plain = re.sub(r"\s+", " ", plain).strip()
    if len(plain) <= limit:
        return plain
    return plain[:limit].rsplit(" ", 1)[0] + "…"


def render(text: str) -> RenderedPage:
    """Главная точка входа: Markdown → безопасный HTML, оглавление и выжимка."""
    source = (text or "")[:MAX_CONTENT_CHARS]
    headings = extract_headings(source)
    rendered = _parser.render(source)
    rendered = _inject_anchors(rendered, headings)
    return RenderedPage(html=rendered, headings=headings, excerpt=make_excerpt(source))
