"""Полнотекстовый поиск по статьям на SQLite FTS5.

Про морфологию. Стандартный токенизатор unicode61 ищет по точным словоформам:
запрос «продление» не найдёт «продлению». Для русского это неприемлемо.

Используется токенизатор trigram: индексируются тройки символов, поэтому
«продлен» найдётся внутри «продлению», «продления» и «продлением». Платы две:
индекс крупнее (примерно втрое от объёма текста) и возможны ложные
срабатывания на коротких запросах — поэтому запросы короче 3 символов
отклоняются. Для вики на тысячи статей это рабочий компромисс; полноценная
лемматизация (pymorphy3) добавляется позже без смены схемы — меняется только
то, что кладётся в индекс.

Таблица заполняется явными вызовами из service.py, а не триггерами: текст в
индекс кладётся уже очищенный от разметки, и в триггере это не сделать.
"""
from __future__ import annotations

import logging
import re

from sqlalchemy import text
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

FTS_TABLE = "wiki_pages_fts"
MIN_QUERY_LENGTH = 3
MAX_RESULTS = 100


def fts_available(db: Session) -> bool:
    """FTS5 собран не во всех сборках SQLite; поиск должен деградировать, а не падать."""
    try:
        db.execute(text("SELECT 1 FROM wiki_pages_fts LIMIT 1"))
        return True
    except Exception:
        return False


def create_fts(connection) -> None:
    """Создаёт виртуальную таблицу. Вызывается из миграции."""
    connection.execute(text(
        f"CREATE VIRTUAL TABLE IF NOT EXISTS {FTS_TABLE} "
        "USING fts5(title, body, tags, page_id UNINDEXED, tokenize='trigram')"
    ))


def index_page(db: Session, page_id: int, title: str, body: str, tags: str = "") -> None:
    """Переиндексирует одну статью (удаление + вставка: FTS5 не умеет UPDATE по ключу)."""
    try:
        db.execute(
            text(f"DELETE FROM {FTS_TABLE} WHERE page_id = :pid"), {"pid": page_id}
        )
        db.execute(
            text(
                f"INSERT INTO {FTS_TABLE} (title, body, tags, page_id) "
                "VALUES (:title, :body, :tags, :pid)"
            ),
            {"title": title or "", "body": body or "", "tags": tags or "", "pid": page_id},
        )
    except Exception:
        # Поиск — не причина терять сохранённую статью.
        logger.exception("Не удалось проиндексировать статью %s", page_id)


def remove_page(db: Session, page_id: int) -> None:
    try:
        db.execute(text(f"DELETE FROM {FTS_TABLE} WHERE page_id = :pid"), {"pid": page_id})
    except Exception:
        logger.exception("Не удалось удалить статью %s из индекса", page_id)


def escape_query(raw: str) -> str:
    """Готовит пользовательский ввод для match-синтаксиса FTS5.

    Спецсимволы FTS5 (кавычки, звёздочки, скобки, NEAR, OR) в пользовательском
    запросе ведут к синтаксической ошибке или к неожиданной логике. Поэтому
    строка разбивается на слова, каждое оборачивается в кавычки, и слова
    соединяются через AND — поведение совпадает с ожиданием «найди всё сразу».
    """
    words = re.findall(r"[\wЀ-ӿ]+", raw or "", flags=re.UNICODE)
    words = [w for w in words if len(w) >= MIN_QUERY_LENGTH][:8]
    if not words:
        return ""
    return " AND ".join(f'"{w}"' for w in words)


def search_page_ids(db: Session, query: str, limit: int = MAX_RESULTS) -> list[tuple[int, float]]:
    """Возвращает [(page_id, релевантность)] в порядке убывания.

    bm25() в SQLite возвращает отрицательные значения (меньше — релевантнее),
    поэтому знак переворачивается: наружу уходит «больше — релевантнее».
    Заголовок весит вчетверо больше тела, теги — вдвое.
    """
    match = escape_query(query)
    if not match:
        return []
    try:
        rows = db.execute(
            text(
                f"SELECT page_id, bm25({FTS_TABLE}, 4.0, 1.0, 2.0) AS rank "
                f"FROM {FTS_TABLE} WHERE {FTS_TABLE} MATCH :q "
                "ORDER BY rank LIMIT :limit"
            ),
            {"q": match, "limit": limit},
        ).fetchall()
    except Exception:
        logger.exception("Ошибка поиска по запросу %r", query)
        return []
    return [(int(row[0]), -float(row[1])) for row in rows]


def rebuild_index(db: Session, pages) -> int:
    """Полная переиндексация. Нужна после импорта или смены токенизатора."""
    db.execute(text(f"DELETE FROM {FTS_TABLE}"))
    count = 0
    for page_id, title, body, tags in pages:
        index_page(db, page_id, title, body, tags)
        count += 1
    return count


def highlight(snippet_text: str, query: str, max_length: int = 240) -> str:
    """Вырезает фрагмент вокруг первого совпадения и помечает совпадения маркерами.

    Возвращает текст с \x02…\x03 вокруг совпадений — шаблон превращает их в
    <mark>. Готовый HTML тут не собирается намеренно: экранирование остаётся
    на стороне Jinja, иначе выдача поиска станет дырой для инъекции.
    """
    words = [w for w in re.findall(r"[\wЀ-ӿ]+", query or "") if len(w) >= MIN_QUERY_LENGTH]
    body = re.sub(r"\s+", " ", snippet_text or "").strip()
    if not words or not body:
        return body[:max_length]

    # Подсветка должна совпадать с логикой поиска. Токенизатор trigram находит
    # «продлению» по запросу «продление», поэтому искать слово целиком нельзя:
    # статья нашлась бы, а подсветки в ней не было. Отсекаем окончание —
    # у слов от 6 символов берём основу без двух последних букв.
    stems = [w[:-2] if len(w) >= 6 else w for w in words]
    pattern = re.compile(
        "|".join(re.escape(stem) + r"[\wЀ-ӿ]*" for stem in stems),
        re.IGNORECASE,
    )
    found = pattern.search(body)
    if not found:
        return body[:max_length]

    start = max(0, found.start() - max_length // 3)
    fragment = body[start:start + max_length]
    if start > 0:
        fragment = "…" + fragment
    if start + max_length < len(body):
        fragment = fragment + "…"
    return pattern.sub(lambda m: f"\x02{m.group(0)}\x03", fragment)


def highlight_html(snippet_text: str, query: str, max_length: int = 240):
    """Готовый безопасный HTML-фрагмент с подсветкой.

    Порядок критичен: сначала экранируем текст статьи целиком, и только потом
    подставляем теги <mark>. Обратный порядок привёл бы к тому, что теги
    экранируются вместе с текстом (и подсветка пропадает), а при небрежной
    реализации — к инъекции.

    Возвращает Markup, поэтому в шаблоне не нужен |safe.
    """
    from markupsafe import Markup, escape

    marked = highlight(snippet_text, query, max_length)
    escaped = str(escape(marked))
    return Markup(escaped.replace("\x02", "<mark>").replace("\x03", "</mark>"))
