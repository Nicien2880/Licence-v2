/*
 * Переключение вкладок на странице «Инструменты».
 *
 * Без маршрутов и перезагрузки: все панели уже в разметке, скрипт только
 * показывает нужную. Выбранная вкладка пишется в адресную строку
 * (?tab=vat), чтобы ссылку на калькулятор можно было отправить коллеге
 * и сохранить в закладках.
 */
(function () {
  "use strict";

  function initToolsTabs() {
    const tabs = Array.prototype.slice.call(document.querySelectorAll("[data-tools-tab]"));
    if (!tabs.length) return;
    const panels = Array.prototype.slice.call(document.querySelectorAll("[data-tools-panel]"));

    function activate(name, pushState) {
      let matched = false;
      tabs.forEach(function (tab) {
        const active = tab.getAttribute("data-tools-tab") === name;
        tab.classList.toggle("active", active);
        tab.setAttribute("aria-selected", active ? "true" : "false");
        tab.setAttribute("tabindex", active ? "0" : "-1");
        if (active) matched = true;
      });
      if (!matched) return false;

      panels.forEach(function (panel) {
        panel.hidden = panel.getAttribute("data-tools-panel") !== name;
      });

      if (pushState && window.history && window.history.replaceState) {
        const url = new URL(window.location.href);
        url.searchParams.set("tab", name);
        window.history.replaceState({}, "", url);
      }
      return true;
    }

    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        activate(tab.getAttribute("data-tools-tab"), true);
      });
    });

    // Открываем вкладку из адреса; если её нет — первую.
    const requested = new URL(window.location.href).searchParams.get("tab");
    if (!requested || !activate(requested, false)) {
      activate(tabs[0].getAttribute("data-tools-tab"), false);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initToolsTabs);
  } else {
    initToolsTabs();
  }
})();
