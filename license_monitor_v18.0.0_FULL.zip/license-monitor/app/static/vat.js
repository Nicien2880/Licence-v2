/*
 * Калькулятор НДС для страницы «Инструменты».
 *
 * Модуль автономный: не трогает app.js и подключается отдельным тегом.
 * Расчёт целиком на клиенте — серверу тут считать нечего, а мгновенный
 * пересчёт при вводе важнее, чем запрос на каждую цифру.
 *
 * Внизу файла — экспорт для Node, чтобы логику можно было покрыть тестами
 * (tests/js/vat.test.mjs). В браузере эта ветка не выполняется.
 */
(function () {
  "use strict";

  // ----------------------------------------------------------------------- //
  // Разбор ввода
  // ----------------------------------------------------------------------- //

  /**
   * Числа копируют из Excel и писем, поэтому принимаем «1 250,50»,
   * «1250.50» и «1 250.5» одинаково. Неразрывный пробел тоже убираем —
   * именно его вставляет Excel при копировании.
   *
   * Возвращает null для пустой строки и NaN для мусора: это разные
   * ситуации, пустое поле ошибкой не считается.
   */
  function parseNumber(text) {
    const cleaned = String(text === undefined || text === null ? "" : text)
      .replace(/[\s  ]/g, "")
      .replace(",", ".");
    if (cleaned === "") return null;
    const value = Number(cleaned);
    return Number.isFinite(value) ? value : NaN;
  }

  // ----------------------------------------------------------------------- //
  // Расчёт
  // ----------------------------------------------------------------------- //

  /**
   * Режим "add": известна сумма без НДС, налог начисляется сверху.
   * Режим "extract": известна сумма с НДС, налог выделяется изнутри —
   * применяется расчётная ставка rate/(100+rate), а не rate/100.
   * Это место, где чаще всего ошибаются, умножая сумму с НДС на 22 %.
   *
   * Округление НЕ делается здесь: промежуточные значения остаются точными,
   * иначе «без НДС + НДС» разойдётся с «с НДС» на копейку при сверке.
   */
  function calculate(amount, rate, mode) {
    if (mode === "extract") {
      const gross = amount;
      const vat = amount * rate / (100 + rate);
      return { net: gross - vat, vat: vat, gross: gross };
    }
    const net = amount;
    const vat = amount * rate / 100;
    return { net: net, vat: vat, gross: net + vat };
  }

  function validate(amount, rate) {
    if (Number.isNaN(amount)) return "Сумма: введите число, например 100000 или 1 250,50";
    if (Number.isNaN(rate)) return "Ставка: введите число, например 22 или 7,5";
    if (amount === null || rate === null) return "";
    if (amount < 0) return "Сумма не может быть отрицательной";
    if (rate < 0 || rate > 100) return "Ставка должна быть от 0 до 100";
    return "";
  }

  // ----------------------------------------------------------------------- //
  // Форматирование
  // ----------------------------------------------------------------------- //

  function money(value) {
    return value.toLocaleString("ru-RU", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }) + " ₽";
  }

  /**
   * Ставка без хвостовых нулей и с десятичной запятой: «22», «7,5».
   * Точка смотрелась бы инородно рядом с суммами, которые
   * toLocaleString("ru-RU") уже выводит через запятую.
   */
  function formatRate(rate) {
    if (rate === null || Number.isNaN(rate)) return "0";
    return String(Math.round(rate * 100) / 100).replace(".", ",");
  }

  // ----------------------------------------------------------------------- //
  // Сумма прописью
  // ----------------------------------------------------------------------- //

  const ONES_M = ["", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"];
  const ONES_F = ["", "одна", "две", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"];
  const TEENS = ["десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать",
                 "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать"];
  const TENS = ["", "", "двадцать", "тридцать", "сорок", "пятьдесят",
                "шестьдесят", "семьдесят", "восемьдесят", "девяносто"];
  const HUNDREDS = ["", "сто", "двести", "триста", "четыреста", "пятьсот",
                    "шестьсот", "семьсот", "восемьсот", "девятьсот"];

  // Разряды. female отмечает женский род: «двадцать одна тысяча»,
  // но «двадцать один миллион».
  const SCALES = [
    { forms: ["рубль", "рубля", "рублей"], female: false },
    { forms: ["тысяча", "тысячи", "тысяч"], female: true },
    { forms: ["миллион", "миллиона", "миллионов"], female: false },
    { forms: ["миллиард", "миллиарда", "миллиардов"], female: false },
    { forms: ["триллион", "триллиона", "триллионов"], female: false }
  ];

  /**
   * Выбор формы слова. Проверка остатка от 100 идёт первой: 11–19
   * берут форму множественного числа, хотя по последней цифре
   * попали бы в «один рубль» и «два рубля».
   */
  function plural(n, forms) {
    const mod100 = n % 100;
    const mod10 = n % 10;
    if (mod100 >= 11 && mod100 <= 19) return forms[2];
    if (mod10 === 1) return forms[0];
    if (mod10 >= 2 && mod10 <= 4) return forms[1];
    return forms[2];
  }

  function groupToWords(n, female) {
    const words = [];
    const hundreds = Math.floor(n / 100);
    const tens = Math.floor((n % 100) / 10);
    const ones = n % 10;
    if (hundreds) words.push(HUNDREDS[hundreds]);
    if (tens === 1) {
      words.push(TEENS[ones]);
    } else {
      if (tens) words.push(TENS[tens]);
      if (ones) words.push(female ? ONES_F[ones] : ONES_M[ones]);
    }
    return words;
  }

  function rublesToWords(rubles) {
    if (rubles === 0) return "ноль рублей";
    const groups = [];
    let rest = rubles;
    while (rest > 0) {
      groups.push(rest % 1000);
      rest = Math.floor(rest / 1000);
    }
    const parts = [];
    for (let i = groups.length - 1; i >= 0; i--) {
      if (groups[i] === 0) continue;
      const scale = SCALES[i] || SCALES[SCALES.length - 1];
      parts.push.apply(parts, groupToWords(groups[i], scale.female));
      parts.push(plural(groups[i], scale.forms));
    }
    // Младшая группа нулевая (122 000) — слово «рублей» ещё не добавлено,
    // иначе вышло бы «сто двадцать две тысячи 00 копеек».
    if (groups[0] === 0) parts.push(plural(0, SCALES[0].forms));
    return parts.join(" ");
  }

  /**
   * «Сто двадцать две тысячи рублей 00 копеек».
   * Копейки цифрами — так принято в счетах и актах.
   *
   * Округление одно, по всей сумме: если округлять рубли и копейки
   * по отдельности, пропись разойдётся с цифрами.
   */
  function amountInWords(value) {
    const totalKopeks = Math.round(Math.abs(value) * 100);
    const rubles = Math.floor(totalKopeks / 100);
    const kopeks = totalKopeks % 100;

    let text = rublesToWords(rubles);
    text = text.charAt(0).toUpperCase() + text.slice(1);
    const result = text + " " + String(kopeks).padStart(2, "0") + " " +
                   plural(kopeks, ["копейка", "копейки", "копеек"]);
    return value < 0 ? "Минус " + result.charAt(0).toLowerCase() + result.slice(1) : result;
  }

  // ----------------------------------------------------------------------- //
  // Привязка к интерфейсу
  // ----------------------------------------------------------------------- //

  const api = {
    parseNumber: parseNumber,
    calculate: calculate,
    validate: validate,
    money: money,
    formatRate: formatRate,
    plural: plural,
    amountInWords: amountInWords
  };

  function initVatCalculator() {
    const root = document.getElementById("vatCalc");
    if (!root) return;

    const amountInput = document.getElementById("vatAmount");
    const rateInput = document.getElementById("vatRate");
    const amountLabel = document.getElementById("vatAmountLabel");
    const modeButtons = Array.prototype.slice.call(root.querySelectorAll("[data-vat-mode]"));
    const presetButtons = Array.prototype.slice.call(root.querySelectorAll("[data-vat-preset]"));
    const errorBox = document.getElementById("vatError");

    const out = {
      net: document.getElementById("vatNet"),
      vat: document.getElementById("vatAmountOut"),
      gross: document.getElementById("vatGross"),
      vatLabel: document.getElementById("vatOutLabel"),
      rowRate: document.getElementById("vatRowRate"),
      rowNet: document.getElementById("vatRowNet"),
      rowVat: document.getElementById("vatRowVat"),
      rowGross: document.getElementById("vatRowGross"),
      fraction: document.getElementById("vatFraction"),
      fractionDecimal: document.getElementById("vatFractionDecimal"),
      formula: document.getElementById("vatFormula"),
      invoice: document.getElementById("vatInvoice"),
      grossWords: document.getElementById("vatGrossWords"),
      vatWords: document.getElementById("vatVatWords")
    };

    let mode = "add";
    const DASH = "—";

    function setText(node, text) {
      if (node) node.textContent = text;
    }

    function recalc() {
      const amount = parseNumber(amountInput.value);
      const rate = parseNumber(rateInput.value);
      const error = validate(amount, rate);
      const valid = !error && amount !== null && rate !== null;

      setText(errorBox, error);
      if (errorBox) errorBox.hidden = !error;

      const rateLabel = formatRate(rate);
      setText(amountLabel, mode === "extract" ? "Сумма с НДС" : "Сумма без НДС");
      setText(out.vatLabel, "НДС " + rateLabel + "%");
      setText(out.rowRate, "НДС " + rateLabel + "%");

      // Расчётная ставка показывается всегда: по ней видно, что при
      // выделении из суммы множитель не 0,22, а 0,1803.
      const safeRate = rate === null || Number.isNaN(rate) ? 0 : rate;
      // И числитель, и знаменатель через formatRate: иначе «7,5 / 107.5».
      setText(out.fraction, formatRate(safeRate) + " / " + formatRate(100 + safeRate));
      setText(out.fractionDecimal,
        100 + safeRate === 0 ? DASH : "= " + (safeRate / (100 + safeRate)).toFixed(4).replace(".", ","));

      if (!valid) {
        [out.net, out.vat, out.gross, out.rowNet, out.rowVat, out.rowGross,
         out.formula, out.invoice, out.grossWords, out.vatWords]
          .forEach(function (node) { setText(node, DASH); });
        return;
      }

      const result = calculate(amount, rate, mode);

      setText(out.net, money(result.net));
      setText(out.vat, money(result.vat));
      setText(out.gross, money(result.gross));
      setText(out.rowNet, money(result.net));
      setText(out.rowVat, money(result.vat));
      setText(out.rowGross, money(result.gross));

      setText(out.formula, mode === "extract"
        ? "НДС  = " + result.gross.toLocaleString("ru-RU") + " × " + rateLabel +
          " / (100 + " + rateLabel + ")\nБаза = сумма с НДС − НДС"
        : "НДС   = " + result.net.toLocaleString("ru-RU") + " × " + rateLabel + " / 100\n" +
          "Итого = сумма без НДС + НДС");

      setText(out.invoice, "Сумма " + money(result.gross) + ", в том числе НДС " +
                           rateLabel + "% — " + money(result.vat) + ".");
      setText(out.grossWords, amountInWords(result.gross));
      setText(out.vatWords, amountInWords(result.vat));
    }

    modeButtons.forEach(function (button) {
      button.addEventListener("click", function () {
        mode = button.getAttribute("data-vat-mode");
        modeButtons.forEach(function (other) {
          const active = other === button;
          other.classList.toggle("active", active);
          other.setAttribute("aria-pressed", active ? "true" : "false");
        });
        recalc();
      });
    });

    presetButtons.forEach(function (button) {
      button.addEventListener("click", function () {
        // Пресет только подставляет значение в поле — дальше его можно
        // дописать вручную, поле остаётся главным способом ввода.
        rateInput.value = button.getAttribute("data-vat-preset");
        recalc();
      });
    });

    [amountInput, rateInput].forEach(function (input) {
      if (input) input.addEventListener("input", recalc);
    });

    recalc();
  }

  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initVatCalculator);
    } else {
      initVatCalculator();
    }
    window.VatCalc = api;
  }

  // Экспорт для тестов в Node; в браузере module не определён.
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})();
