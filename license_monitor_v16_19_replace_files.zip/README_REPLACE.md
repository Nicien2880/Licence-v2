# v16.19 replace files

Скопировать поверх текущих:

- app/main.py -> /opt/license-monitor/app/main.py
- app/models.py -> /opt/license-monitor/app/models.py
- app/templates/index.html -> /opt/license-monitor/app/templates/index.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:

```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
sudo systemctl restart license-monitor
```
