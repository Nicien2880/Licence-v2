# v16.47 replace files

Скопировать поверх текущих:
- app/main.py -> /opt/license-monitor/app/main.py
- app/templates/users.html -> /opt/license-monitor/app/templates/users.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```

Если кнопка всё равно не видна, принудительно обнови страницу:
Ctrl+F5
