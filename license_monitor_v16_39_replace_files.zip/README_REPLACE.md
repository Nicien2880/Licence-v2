# v16.39 replace files

Скопировать поверх текущих:
- app/templates/data_protection.html -> /opt/license-monitor/app/templates/data_protection.html
- app/static/style.css -> /opt/license-monitor/app/static/style.css
- app/static/app.js -> /opt/license-monitor/app/static/app.js

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
