from datetime import date, datetime
from io import BytesIO
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import inspect, or_, text
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .models import ChangeLog, HardwareSupport, SoftwareLicense, User
from .settings import get_settings
from .auth import (
    ROLE_LABELS, SESSION_COOKIE, create_initial_admin_if_needed, create_session_token,
    get_current_user, hash_password, require_api_key, require_login, require_role,
    user_can, verify_password,
)

settings = get_settings()
app = FastAPI(title=settings.app_name)
BASE_DIR = Path(__file__).resolve().parent
Base.metadata.create_all(bind=engine)


def ensure_schema() -> None:
    """Мини-миграция для существующей SQLite-базы после обновления проекта."""
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    if "software_licenses" in tables:
        columns = {column["name"] for column in inspector.get_columns("software_licenses")}
        if "location" not in columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE software_licenses ADD COLUMN location VARCHAR(255)"))


ensure_schema()
with next(get_db()) as _db:
    create_initial_admin_if_needed(_db)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def parse_date(value) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value).strip()[:10])


def parse_int(value, default=None):
    if value in (None, ""):
        return default
    try:
        return int(value)
    except Exception:
        return default


def parse_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y", "да", "истина", "on"}


def calc_status(days_left: int) -> str:
    if days_left < 0:
        return "expired"
    if days_left <= 7:
        return "urgent"
    if days_left <= 30:
        return "critical"
    if days_left <= 60:
        return "warning"
    return "active"


def update_status(item) -> None:
    item.status = calc_status(item.days_left(date.today()))


def log_change(db: Session, section: str, record_id: int | None, action: str, description: str, actor: str = "web") -> None:
    db.add(ChangeLog(section=section, record_id=record_id, action=action, description=description, actor=actor))


def hardware_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None):
    query = db.query(HardwareSupport)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            HardwareSupport.dzo.ilike(pattern), HardwareSupport.serial_number.ilike(pattern),
            HardwareSupport.equipment_model.ilike(pattern), HardwareSupport.contract_number.ilike(pattern),
            HardwareSupport.contractor.ilike(pattern), HardwareSupport.responsible.ilike(pattern),
            HardwareSupport.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(HardwareSupport.status == status)
    if responsible:
        query = query.filter(HardwareSupport.responsible == responsible)
    items = query.order_by(HardwareSupport.support_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def software_query(db: Session, q: str | None = None, status: str | None = None, responsible: str | None = None):
    query = db.query(SoftwareLicense)
    if q:
        pattern = f"%{q}%"
        query = query.filter(or_(
            SoftwareLicense.location.ilike(pattern), SoftwareLicense.code.ilike(pattern), SoftwareLicense.certificate_number.ilike(pattern),
            SoftwareLicense.contract_number.ilike(pattern), SoftwareLicense.contractor.ilike(pattern),
            SoftwareLicense.responsible.ilike(pattern), SoftwareLicense.comment.ilike(pattern),
        ))
    if status:
        query = query.filter(SoftwareLicense.status == status)
    if responsible:
        query = query.filter(SoftwareLicense.responsible == responsible)
    items = query.order_by(SoftwareLicense.cert_end_date.asc()).all()
    changed = False
    for item in items:
        old = item.status
        update_status(item)
        changed = changed or old != item.status
    if changed:
        db.commit()
    return items


def stats_for(items):
    today = date.today()
    return {
        "total": len(items),
        "expired": sum(1 for x in items if x.days_left(today) < 0),
        "urgent": sum(1 for x in items if 0 <= x.days_left(today) <= 7),
        "critical": sum(1 for x in items if 8 <= x.days_left(today) <= 30),
        "warning": sum(1 for x in items if 31 <= x.days_left(today) <= 60),
    }


def distinct_responsibles(db: Session, model):
    values = db.query(model.responsible).distinct().order_by(model.responsible).all()
    return [x[0] for x in values if x[0]]


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if not settings.auth_enabled:
        return RedirectResponse(url="/", status_code=303)
    return templates.TemplateResponse(request=request, name="login.html", context={"app_name": settings.app_name, "error": None})


@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        return templates.TemplateResponse(request=request, name="login.html", context={"app_name": settings.app_name, "error": "Неверный логин или пароль"}, status_code=401)
    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie(SESSION_COOKIE, create_session_token(user.id), httponly=True, samesite="lax", max_age=60 * 60 * 12)
    return response


@app.post("/logout")
def logout():
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(SESSION_COOKIE)
    return response


@app.get("/admin/users", response_class=HTMLResponse)
def users_page(request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role("admin"))):
    users = db.query(User).order_by(User.username).all()
    return templates.TemplateResponse(request=request, name="users.html", context={"app_name": settings.app_name, "users": users, "roles": ROLE_LABELS, "current_user": current_user})


@app.post("/admin/users")
def create_user(
    username: str = Form(...), password: str = Form(...), full_name: str | None = Form(None),
    email: str | None = Form(None), role: str = Form("viewer"), is_active: bool = Form(False),
    db: Session = Depends(get_db), current_user: User = Depends(require_role("admin")),
):
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Invalid role")
    existing = db.query(User).filter(User.username == username).first()
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")
    db.add(User(username=username, password_hash=hash_password(password), full_name=full_name or None, email=email or None, role=role, is_active=is_active))
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@app.post("/admin/users/{user_id}/update")
def update_user(
    user_id: int, full_name: str | None = Form(None), email: str | None = Form(None), role: str = Form("viewer"),
    is_active: bool = Form(False), password: str | None = Form(None), db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin")),
):
    if role not in ROLE_LABELS:
        raise HTTPException(status_code=400, detail="Invalid role")
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    user.full_name = full_name or None
    user.email = email or None
    user.role = role
    user.is_active = is_active
    if password:
        user.password_hash = hash_password(password)
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@app.get("/", response_class=HTMLResponse)
def index(request: Request, section: str = "hardware", q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    current_user = get_current_user(request, db)
    if settings.auth_enabled and current_user is None:
        return RedirectResponse(url="/login", status_code=303)
    if section not in {"hardware", "software"}:
        section = "hardware"
    hw_all = hardware_query(db)
    sw_all = software_query(db)
    items = hardware_query(db, q, status, responsible) if section == "hardware" else software_query(db, q, status, responsible)
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "app_name": settings.app_name,
            "section": section,
            "items": items,
            "today": date.today(),
            "stats": stats_for(hw_all if section == "hardware" else sw_all),
            "global_stats": {"hardware": stats_for(hw_all), "software": stats_for(sw_all)},
            "selected": {"q": q or "", "status": status or "", "responsible": responsible or ""},
            "responsibles": distinct_responsibles(db, HardwareSupport if section == "hardware" else SoftwareLicense),
            "statuses": ["active", "warning", "critical", "urgent", "expired"],
            "current_user": current_user,
            "can_edit": user_can(current_user, "editor"),
            "can_manage": user_can(current_user, "manager"),
            "can_admin": user_can(current_user, "admin"),
        },
    )


@app.post("/hardware")
def create_hardware(
    dzo: str = Form("-"), serial_number: str = Form("-"), equipment_model: str = Form("-"), delivery_year: str | None = Form(None),
    support_end_date: str = Form(...), purchase_period: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), auto_renewal: bool = Form(False),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    end = parse_date(support_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания ТП обязательна")
    item = HardwareSupport(
        dzo=dzo or "-", serial_number=serial_number or "-", equipment_model=equipment_model or "-", delivery_year=parse_int(delivery_year),
        support_end_date=end, purchase_period=purchase_period or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None, auto_renewal=auto_renewal, comment=comment or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "hardware", item.id, "create", f"Добавлена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software")
def create_software(
    location: str | None = Form(None), code: str = Form("-"), quantity: int = Form(1), cert_start_date: str | None = Form(None), cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None), comment: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    end = parse_date(cert_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания сертификата обязательна")
    item = SoftwareLicense(
        location=location or None, code=code or "-", quantity=quantity or 1, cert_start_date=parse_date(cert_start_date), cert_end_date=end,
        certificate_number=certificate_number or None, comment=comment or None, contract_number=contract_number or None,
        contractor=contractor or None, responsible=responsible or None,
    )
    update_status(item)
    db.add(item)
    db.flush()
    log_change(db, "software", item.id, "create", f"Добавлена лицензия ПО: {item.code}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.post("/hardware/{item_id}/delete")
def delete_hardware(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(HardwareSupport, item_id)
    if item:
        log_change(db, "hardware", item.id, "delete", f"Удалена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software/{item_id}/delete")
def delete_software(item_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    item = db.get(SoftwareLicense, item_id)
    if item:
        log_change(db, "software", item.id, "delete", f"Удалена лицензия ПО: {item.code}", actor=current_user.username)
        db.delete(item)
        db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.post("/hardware/{item_id}/update")
def update_hardware(
    item_id: int,
    dzo: str = Form("-"), serial_number: str = Form("-"), equipment_model: str = Form("-"), delivery_year: str | None = Form(None),
    support_end_date: str = Form(...), purchase_period: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), auto_renewal: bool = Form(False),
    comment: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    end = parse_date(support_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания ТП обязательна")
    item.dzo = dzo or "-"
    item.serial_number = serial_number or "-"
    item.equipment_model = equipment_model or "-"
    item.delivery_year = parse_int(delivery_year)
    item.support_end_date = end
    item.purchase_period = purchase_period or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    item.auto_renewal = auto_renewal
    item.comment = comment or None
    update_status(item)
    log_change(db, "hardware", item.id, "update", f"Обновлена ТП оборудования: {item.equipment_model} / {item.serial_number}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=hardware", status_code=303)


@app.post("/software/{item_id}/update")
def update_software(
    item_id: int,
    location: str | None = Form(None), code: str = Form("-"), quantity: int = Form(1), cert_start_date: str | None = Form(None), cert_end_date: str = Form(...),
    certificate_number: str | None = Form(None), comment: str | None = Form(None), contract_number: str | None = Form(None),
    contractor: str | None = Form(None), responsible: str | None = Form(None), db: Session = Depends(get_db), current_user: User = Depends(require_role("editor")),
):
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    end = parse_date(cert_end_date)
    if not end:
        raise HTTPException(status_code=400, detail="Дата окончания сертификата обязательна")
    item.location = location or None
    item.code = code or "-"
    item.quantity = quantity or 1
    item.cert_start_date = parse_date(cert_start_date)
    item.cert_end_date = end
    item.certificate_number = certificate_number or None
    item.comment = comment or None
    item.contract_number = contract_number or None
    item.contractor = contractor or None
    item.responsible = responsible or None
    update_status(item)
    log_change(db, "software", item.id, "update", f"Обновлена лицензия ПО: {item.code}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url="/?section=software", status_code=303)


@app.get("/history", response_class=HTMLResponse)
def history_page(request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_login)):
    history = db.query(ChangeLog).order_by(ChangeLog.created_at.desc()).limit(200).all()
    return templates.TemplateResponse(request=request, name="history.html", context={"history": history, "app_name": settings.app_name, "current_user": current_user, "can_admin": user_can(current_user, "admin") })


def hardware_to_api(item: HardwareSupport) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "hardware",
        "section_name": "Техподдержка оборудования",
        "number": None,
        "dzo": item.dzo,
        "serial_number": item.serial_number,
        "equipment_model": item.equipment_model,
        "delivery_year": item.delivery_year,
        "support_end_date": item.support_end_date,
        "purchase_period": item.purchase_period,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "auto_renewal": item.auto_renewal,
        "comment": item.comment,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def software_to_api(item: SoftwareLicense) -> dict:
    today = date.today()
    return {
        "id": item.id,
        "section": "software",
        "section_name": "Лицензии ПО",
        "number": None,
        "location": item.location,
        "code": item.code,
        "quantity": item.quantity,
        "cert_start_date": item.cert_start_date,
        "cert_end_date": item.cert_end_date,
        "certificate_number": item.certificate_number,
        "comment": item.comment,
        "contract_number": item.contract_number,
        "contractor": item.contractor,
        "responsible": item.responsible,
        "days_left": item.days_left(today),
        "status": item.status,
        "created_at": item.created_at,
        "updated_at": item.updated_at,
    }


def combined_api_items(db: Session, days: int | None = None) -> list[dict]:
    result = []
    for item in hardware_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(hardware_to_api(item))
    for item in software_query(db):
        if days is None or item.days_left(date.today()) <= days:
            result.append(software_to_api(item))
    result.sort(key=lambda x: x.get("days_left", 999999))
    for idx, item in enumerate(result, 1):
        item["number"] = idx
    return result



@app.get("/api/licenses")
def api_all_licenses(request: Request, section: str | None = None, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    """Совместимый API: возвращает записи обоих разделов или выбранного section=hardware/software."""
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]
    if section == "software":
        return [software_to_api(x) for x in software_query(db, q, status, responsible)]
    return combined_api_items(db)


@app.get("/api/licenses/expiring")
def api_expiring_licenses(request: Request, days: int = 30, section: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    today = date.today()
    if section == "hardware":
        return [hardware_to_api(x) for x in hardware_query(db) if x.days_left(today) <= days]
    if section == "software":
        return [software_to_api(x) for x in software_query(db) if x.days_left(today) <= days]
    return combined_api_items(db, days=days)


@app.get("/api/hardware-support")
def api_hardware_support(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [hardware_to_api(x) for x in hardware_query(db, q, status, responsible)]


@app.get("/api/hardware-support/{item_id}")
def api_hardware_support_item(request: Request, item_id: int, db: Session = Depends(get_db)):
    require_api_key(request)
    item = db.get(HardwareSupport, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Hardware support record not found")
    update_status(item)
    db.commit()
    return hardware_to_api(item)


@app.get("/api/software-licenses")
def api_software_licenses(request: Request, q: str | None = None, status: str | None = None, responsible: str | None = None, db: Session = Depends(get_db)):
    require_api_key(request)
    return [software_to_api(x) for x in software_query(db, q, status, responsible)]


@app.get("/api/software-licenses/{item_id}")
def api_software_license_item(request: Request, item_id: int, db: Session = Depends(get_db)):
    require_api_key(request)
    item = db.get(SoftwareLicense, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Software license record not found")
    update_status(item)
    db.commit()
    return software_to_api(item)

@app.get("/api/monitoring/summary")
def api_monitoring_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    hw = hardware_query(db)
    sw = software_query(db)
    return {"hardware_support": stats_for(hw), "software_licenses": stats_for(sw)}




@app.get("/api/zabbix/summary")
def api_zabbix_summary(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    """Плоский JSON для Zabbix HTTP agent и JSONPath."""
    hw = stats_for(hardware_query(db))
    sw = stats_for(software_query(db))
    return {
        "hardware_total": hw["total"],
        "hardware_warning": hw["warning"],
        "hardware_critical": hw["critical"],
        "hardware_urgent": hw["urgent"],
        "hardware_expired": hw["expired"],
        "software_total": sw["total"],
        "software_warning": sw["warning"],
        "software_critical": sw["critical"],
        "software_urgent": sw["urgent"],
        "software_expired": sw["expired"],
        "total_expired": hw["expired"] + sw["expired"],
        "total_urgent": hw["urgent"] + sw["urgent"],
        "total_critical": hw["critical"] + sw["critical"],
        "total_warning": hw["warning"] + sw["warning"],
    }

@app.get("/metrics", response_class=PlainTextResponse)
def metrics(request: Request, db: Session = Depends(get_db)):
    require_api_key(request)
    hw = stats_for(hardware_query(db))
    sw = stats_for(software_query(db))
    lines = []
    for section, data in {"hardware": hw, "software": sw}.items():
        for key, value in data.items():
            lines.append(f'license_monitor_{key}{{section="{section}"}} {value}')
    return "\n".join(lines) + "\n"


@app.get("/export.xlsx")
def export_xlsx(section: str = "hardware", db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    wb = Workbook()
    ws = wb.active
    today = date.today()
    if section == "software":
        ws.title = "software_licenses"
        headers = ["№", "Локация", "Код", "Кол-во", "Дата начала сертификата", "Дата окончания сертификата", "Номер сертификата", "Комментарий", "Номер договора", "Контрагент", "Ответственный", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(software_query(db), 1):
            ws.append([idx, item.location, item.code, item.quantity, item.cert_start_date, item.cert_end_date, item.certificate_number, item.comment, item.contract_number, item.contractor, item.responsible, item.days_left(today), item.status])
        filename = f"software_licenses_{today.isoformat()}.xlsx"
    else:
        ws.title = "hardware_support"
        headers = ["№", "ДЗО", "Серийный номер", "Модель оборудования", "Год поставки", "Текущее состояние ТП (дата окончания)", "Срок на который закупается ТП", "Договор", "Контрагент", "Ответственный", "Автопродление", "Комментарий", "Осталось дней", "Статус"]
        ws.append(headers)
        for idx, item in enumerate(hardware_query(db), 1):
            ws.append([idx, item.dzo, item.serial_number, item.equipment_model, item.delivery_year, item.support_end_date, item.purchase_period, item.contract_number, item.contractor, item.responsible, "да" if item.auto_renewal else "нет", item.comment, item.days_left(today), item.status])
        filename = f"hardware_support_{today.isoformat()}.xlsx"
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="E5E7EB")
    for column_cells in ws.columns:
        length = max(len(str(cell.value or "")) for cell in column_cells)
        ws.column_dimensions[get_column_letter(column_cells[0].column)].width = min(max(length + 2, 12), 45)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/import.xlsx")
async def import_xlsx(section: str = Form("hardware"), file: UploadFile = File(...), db: Session = Depends(get_db), current_user: User = Depends(require_role("manager"))):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Upload .xlsx file")
    wb = load_workbook(BytesIO(await file.read()), data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return RedirectResponse(url=f"/?section={section}", status_code=303)
    headers = [str(x).strip() if x is not None else "" for x in rows[0]]
    index = {name: i for i, name in enumerate(headers)}

    def val(row, name, default=None):
        i = index.get(name)
        return row[i] if i is not None and i < len(row) else default

    imported = 0
    for row in rows[1:]:
        if not row or not any(row):
            continue
        try:
            if section == "software":
                end = parse_date(val(row, "Дата окончания сертификата"))
                if not end:
                    continue
                item = SoftwareLicense(
                    location=str(val(row, "Локация") or "").strip() or None,
                    code=str(val(row, "Код", "-") or "-").strip(), quantity=parse_int(val(row, "Кол-во"), 1) or 1,
                    cert_start_date=parse_date(val(row, "Дата начала сертификата")), cert_end_date=end,
                    certificate_number=str(val(row, "Номер сертификата") or "").strip() or None,
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                    contract_number=str(val(row, "Номер договора") or "").strip() or None,
                    contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str(val(row, "Ответственный") or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
            else:
                end = parse_date(val(row, "Текущее состояние ТП (дата окончания)"))
                if not end:
                    continue
                item = HardwareSupport(
                    dzo=str(val(row, "ДЗО", "-") or "-").strip(), serial_number=str(val(row, "Серийный номер", "-") or "-").strip(),
                    equipment_model=str(val(row, "Модель оборудования", "-") or "-").strip(), delivery_year=parse_int(val(row, "Год поставки")),
                    support_end_date=end, purchase_period=str(val(row, "Срок на который закупается ТП") or "").strip() or None,
                    contract_number=str(val(row, "Договор") or "").strip() or None, contractor=str(val(row, "Контрагент") or "").strip() or None,
                    responsible=str(val(row, "Ответственный") or "").strip() or None, auto_renewal=parse_bool(val(row, "Автопродление")),
                    comment=str(val(row, "Комментарий") or "").strip() or None,
                )
                update_status(item)
                db.add(item)
                imported += 1
        except Exception:
            continue
    log_change(db, section, None, "import", f"Импортировано строк из Excel: {imported}", actor=current_user.username)
    db.commit()
    return RedirectResponse(url=f"/?section={section}", status_code=303)


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}
