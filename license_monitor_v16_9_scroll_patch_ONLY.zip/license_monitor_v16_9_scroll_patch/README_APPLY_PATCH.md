# License Monitor v16.9 scroll patch

Этот патч не содержит всю сборку целиком. Он нужен, если полная ссылка на архив не скачивается.

Что добавляет:
- верхний горизонтальный скролл для широких таблиц;
- синхронизацию верхнего и нижнего скролла;
- закреплённую шапку таблицы;
- закреплённую первую колонку;
- более ровное оформление кнопок импорта / очистки.

## Как применить

1. Открой на сервере файл CSS проекта, обычно:

```bash
nano /opt/license-monitor/static/style.css
```

2. Вставь содержимое файла `PATCH_style_css_append.css` в самый конец `style.css`.

3. Открой основной шаблон Data Protection. Обычно один из вариантов:

```bash
nano /opt/license-monitor/templates/data_protection.html
```

или:

```bash
nano /opt/license-monitor/templates/index.html
```

4. Найди контейнер таблицы Data Protection. Он обычно выглядит примерно так:

```html
<div class="table-wrap">
    <table ...
```

или:

```html
<div class="table-container">
    <table ...
```

5. Оберни таблицу так:

```html
<div class="scroll-sync-block">
  <div class="top-scroll" data-scroll-sync="data-protection">
    <div class="top-scroll-inner"></div>
  </div>

  <div class="table-scroll" data-scroll-sync="data-protection">
    <!-- тут старая таблица -->
  </div>
</div>
```

Если таблица уже была внутри `<div class="table-wrap">`, просто добавь классы:

```html
<div class="table-wrap table-scroll" data-scroll-sync="data-protection">
```

а перед ним вставь верхний скролл:

```html
<div class="top-scroll" data-scroll-sync="data-protection">
  <div class="top-scroll-inner"></div>
</div>
```

6. Перед закрывающим `</body>` вставь содержимое файла `PATCH_scroll_sync_script.html`.

7. Перезапусти сервис:

```bash
sudo systemctl restart license-monitor
```
