/* Конвертер частоты в инструментах: два равноправных поля (ГГц ↔ ТГц).
 * Используются десятичные приставки СИ: 1 ТГц = 1000 ГГц.
 * Расчёт только в браузере; функции экспортируются для Node-тестов.
 */
(function () {
  "use strict";

  function parseNumber(raw) {
    const cleaned = String(raw === null || raw === undefined ? "" : raw)
      .replace(/[\s\u00a0\u202f]/g, "")
      .replace(",", ".");
    if (cleaned === "") return null;
    if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(cleaned)) return NaN;
    const number = Number(cleaned);
    return Number.isFinite(number) ? number : NaN;
  }

  function convert(value, fromUnit) {
    if (!Number.isFinite(value) || value < 0) {
      throw new RangeError("Частота должна быть неотрицательным конечным числом");
    }
    if (fromUnit !== "GHz" && fromUnit !== "THz") {
      throw new RangeError("Неизвестная единица частоты");
    }
    const result = fromUnit === "GHz" ? value / 1000 : value * 1000;
    if (!Number.isFinite(result)) {
      throw new RangeError("Слишком большое значение для пересчёта");
    }
    return result;
  }

  // Убираем артефакты IEEE 754 (например 0,30000000000000004)
  // без принудительного округления маленьких частот до нуля.
  function normalize(value) {
    return Number(value.toPrecision(15));
  }

  function formatInput(value) {
    return String(normalize(value)).replace(".", ",");
  }

  function formatResult(value) {
    return new Intl.NumberFormat("ru-RU", {
      maximumSignificantDigits: 12
    }).format(normalize(value));
  }

  function initFrequencyConverter() {
    const ghzInput = document.getElementById("frequencyGHz");
    const thzInput = document.getElementById("frequencyTHz");
    const result = document.getElementById("frequencyResult");
    const error = document.getElementById("frequencyError");
    if (!ghzInput || !thzInput || !result || !error) return;

    function recalculate(fromUnit) {
      const source = fromUnit === "GHz" ? ghzInput : thzInput;
      const target = fromUnit === "GHz" ? thzInput : ghzInput;
      const value = parseNumber(source.value);

      error.textContent = "";
      error.hidden = true;
      if (value === null) {
        target.value = "";
        result.textContent = "—";
        return;
      }
      if (Number.isNaN(value) || value < 0) {
        target.value = "";
        result.textContent = "—";
        error.textContent = "Введите неотрицательное число (можно с точкой или запятой).";
        error.hidden = false;
        return;
      }

      try {
        const converted = convert(value, fromUnit);
        target.value = formatInput(converted);
        const sourceLabel = fromUnit === "GHz" ? "ГГц" : "ТГц";
        const targetLabel = fromUnit === "GHz" ? "ТГц" : "ГГц";
        result.textContent = `${formatResult(value)} ${sourceLabel} = ${formatResult(converted)} ${targetLabel}`;
      } catch (e) {
        target.value = "";
        result.textContent = "—";
        error.textContent = e.message || "Ошибка пересчёта";
        error.hidden = false;
      }
    }

    ghzInput.addEventListener("input", function () { recalculate("GHz"); });
    thzInput.addEventListener("input", function () { recalculate("THz"); });
    recalculate("GHz");
  }

  if (typeof module !== "undefined" && module.exports) {
    module.exports = { parseNumber, convert, normalize, formatInput, formatResult, initFrequencyConverter };
  }
  if (typeof document !== "undefined") {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initFrequencyConverter);
    } else {
      initFrequencyConverter();
    }
  }
})();
