# v16.43 replace files

Скопировать поверх текущих:
- app/templates/*.html -> /opt/license-monitor/app/templates/
- app/static/style.css -> /opt/license-monitor/app/static/style.css

Потом:
```bash
sudo chown -R license-monitor:license-monitor /opt/license-monitor
find /opt/license-monitor -name "*.pyc" -delete
sudo systemctl restart license-monitor
```
